import "dotenv/config";
import { PrismaBetterSqlite3 } from "@prisma/adapter-better-sqlite3";
import { PrismaClient } from "../src/generated/prisma/client";
import { calculatePriorities, ANALYSIS_RULE_VERSION, type ScoreInput, type SurveySubjectInput } from "../src/domain/analysis";
import { analyzeLearningTendencies, buildLearningSummary } from "../src/domain/learning-analysis";
import { surveyScores, type LearningSurveyProfile, type ScaleAnswers } from "../src/domain/learning-survey";
import { generateStudyPlan, PLAN_RULE_VERSION } from "../src/domain/study-plan";
import { addDays } from "../src/lib/format";
import type { SubjectKey } from "../src/domain/subjects";

const configuredUrl = process.env.DATABASE_URL ?? "file:./dev.db";
const adapter = new PrismaBetterSqlite3({ url: configuredUrl });
const prisma = new PrismaClient({ adapter });

type SampleStudent = {
  id: string;
  displayName: string;
  grade: "JUNIOR_HIGH_2" | "JUNIOR_HIGH_3";
  schoolName: string;
  targetSchool: string;
  tests: Array<{ name: string; takenOn: string; scores: Record<SubjectKey, number> }>;
  survey: {
    answeredOn: string;
    weekdayAvailableMinutes: number;
    weekendAvailableMinutes: number;
    concern: string;
    studyMinutes: Record<SubjectKey, number>;
    confidence: Record<SubjectKey, number>;
    currentWeekdayMinutes?: number;
    currentWeekendMinutes?: number;
    availableDays?: LearningSurveyProfile["availableDays"];
    selfEvaluation?: Record<SubjectKey, number>;
    studyFrequency?: Record<SubjectKey, number>;
  };
};

const samples: SampleStudent[] = [
  {
    id: "sample-akari",
    displayName: "あかり",
    grade: "JUNIOR_HIGH_3",
    schoolName: "いわき市立みらい中学校",
    targetSchool: "福島県立磐城高等学校",
    tests: [
      { name: "第1回 学力確認テスト", takenOn: "2026-05-18", scores: { JAPANESE: 72, MATH: 61, ENGLISH: 68, SCIENCE: 74, SOCIAL_STUDIES: 70 } },
      { name: "第2回 学力確認テスト", takenOn: "2026-06-22", scores: { JAPANESE: 76, MATH: 66, ENGLISH: 71, SCIENCE: 70, SOCIAL_STUDIES: 73 } },
      { name: "第3回 学力確認テスト", takenOn: "2026-07-20", scores: { JAPANESE: 78, MATH: 59, ENGLISH: 75, SCIENCE: 72, SOCIAL_STUDIES: 77 } },
    ],
    survey: {
      answeredOn: "2026-07-27",
      weekdayAvailableMinutes: 60,
      weekendAvailableMinutes: 120,
      concern: "数学の文章題で式を立てるところを、落ち着いて練習したいです。",
      studyMinutes: { JAPANESE: 90, MATH: 70, ENGLISH: 110, SCIENCE: 80, SOCIAL_STUDIES: 100 },
      confidence: { JAPANESE: 4, MATH: 2, ENGLISH: 4, SCIENCE: 3, SOCIAL_STUDIES: 4 },
    },
  },
  {
    id: "sample-haruto",
    displayName: "はると",
    grade: "JUNIOR_HIGH_2",
    schoolName: "いわき市立あおば中学校",
    targetSchool: "福島県立いわき光洋高等学校",
    tests: [
      { name: "春の実力テスト", takenOn: "2026-05-12", scores: { JAPANESE: 64, MATH: 75, ENGLISH: 58, SCIENCE: 69, SOCIAL_STUDIES: 62 } },
      { name: "初夏の実力テスト", takenOn: "2026-06-16", scores: { JAPANESE: 68, MATH: 78, ENGLISH: 63, SCIENCE: 72, SOCIAL_STUDIES: 66 } },
      { name: "夏の実力テスト", takenOn: "2026-07-14", scores: { JAPANESE: 70, MATH: 81, ENGLISH: 67, SCIENCE: 74, SOCIAL_STUDIES: 69 } },
    ],
    survey: {
      answeredOn: "2026-07-28",
      weekdayAvailableMinutes: 45,
      weekendAvailableMinutes: 90,
      concern: "英単語を毎日少しずつ覚える方法を見つけたいです。",
      studyMinutes: { JAPANESE: 60, MATH: 120, ENGLISH: 45, SCIENCE: 75, SOCIAL_STUDIES: 55 },
      confidence: { JAPANESE: 3, MATH: 5, ENGLISH: 2, SCIENCE: 4, SOCIAL_STUDIES: 3 },
    },
  },
  {
    id: "sample-hanako",
    displayName: "テスト花子",
    grade: "JUNIOR_HIGH_3",
    schoolName: "いわき市立テスト中学校",
    targetSchool: "テスト第一高等学校",
    tests: [
      { name: "確認テスト1", takenOn: "2026-05-15", scores: { JAPANESE: 65, MATH: 48, ENGLISH: 60, SCIENCE: 62, SOCIAL_STUDIES: 70 } },
      { name: "確認テスト2", takenOn: "2026-06-15", scores: { JAPANESE: 66, MATH: 42, ENGLISH: 62, SCIENCE: 64, SOCIAL_STUDIES: 72 } },
      { name: "確認テスト3", takenOn: "2026-07-15", scores: { JAPANESE: 67, MATH: 36, ENGLISH: 64, SCIENCE: 65, SOCIAL_STUDIES: 74 } },
    ],
    survey: {
      answeredOn: "2026-07-28",
      currentWeekdayMinutes: 10,
      currentWeekendMinutes: 20,
      weekdayAvailableMinutes: 30,
      weekendAvailableMinutes: 60,
      availableDays: ["MON", "TUE", "THU", "SAT"],
      concern: "数学は何から復習すればよいか分からず、自信がありません。",
      studyMinutes: { JAPANESE: 30, MATH: 20, ENGLISH: 30, SCIENCE: 25, SOCIAL_STUDIES: 50 },
      confidence: { JAPANESE: 3, MATH: 1, ENGLISH: 3, SCIENCE: 3, SOCIAL_STUDIES: 4 },
      selfEvaluation: { JAPANESE: 3, MATH: 1, ENGLISH: 3, SCIENCE: 3, SOCIAL_STUDIES: 5 },
      studyFrequency: { JAPANESE: 1, MATH: 1, ENGLISH: 1, SCIENCE: 1, SOCIAL_STUDIES: 2 },
    },
  },
];

async function seedStudent(sample: SampleStudent): Promise<void> {
  // WorkbookItem / WorkbookProblemResult intentionally restrict deletion of their
  // approved source problems, so remove the owning workbooks before the student.
  await prisma.workbook.deleteMany({ where: { studentId: sample.id } });
  await prisma.weeklyStudyPlan.deleteMany({ where: { studentId: sample.id } });
  await prisma.student.deleteMany({ where: { id: sample.id } });
  await prisma.student.create({
    data: {
      id: sample.id,
      displayName: sample.displayName,
      grade: sample.grade,
      schoolName: sample.schoolName,
      residenceArea: "いわき市",
      examYear: 2027,
      targetSchools: {
        create: {
          schoolName: sample.targetSchool,
          preferenceRank: 1,
          targetTotalScore: 190,
          note: "サンプルとして登録した志望校です。",
          instructorComment: "目標点は学習配分の目安として定期的に見直します。",
          subjectGoals: { create: [
            { subject: "JAPANESE", targetScore: 40 }, { subject: "MATH", targetScore: 40 }, { subject: "ENGLISH", targetScore: 40 },
            { subject: "SCIENCE", targetScore: 35 }, { subject: "SOCIAL_STUDIES", targetScore: 35 },
          ] },
        },
      },
    },
  });

  const tests = [];
  for (const test of sample.tests) {
    tests.push(await prisma.academicTest.create({
      data: {
        studentId: sample.id,
        name: test.name,
        takenOn: new Date(`${test.takenOn}T00:00:00+09:00`),
        scores: {
          create: Object.entries(test.scores).map(([subject, score]) => ({
            subject: subject as SubjectKey,
            score,
            maxScore: 100,
          })),
        },
      },
      include: { scores: true },
    }));
  }

  const motivationAnswers: ScaleAnswers = sample.id === "sample-akari"
    ? { targetSchool: 5, improveGrades: 5, selfStart: 3, followPlan: 5, faceWeakSubjects: 3 }
    : sample.id === "sample-hanako"
      ? { targetSchool: 5, improveGrades: 5, selfStart: 3, followPlan: 5, faceWeakSubjects: 2 }
    : { targetSchool: 4, improveGrades: 4, selfStart: 4, followPlan: 4, faceWeakSubjects: 3 };
  const confidenceAnswers: ScaleAnswers = sample.id === "sample-akari"
    ? { effortWorks: 3, achievement: 4, improveWeakness: 2, improveTest: 3, solveUnknown: 2 }
    : sample.id === "sample-hanako"
      ? { effortWorks: 2, achievement: 2, improveWeakness: 2, improveTest: 2, solveUnknown: 2 }
    : { effortWorks: 4, achievement: 4, improveWeakness: 3, improveTest: 4, solveUnknown: 3 };
  const studyMethodAnswers: ScaleAnswers = sample.id === "sample-akari"
    ? { extraStudy: 3, reviewMistakes: 2, readExplanations: 4, askQuestions: 2, planBeforeTests: 2, solveProblems: 3, timedPractice: 1, repeatProblems: 2 }
    : sample.id === "sample-hanako"
      ? { extraStudy: 2, reviewMistakes: 1, readExplanations: 3, askQuestions: 2, planBeforeTests: 2, solveProblems: 2, timedPractice: 1, repeatProblems: 1 }
    : { extraStudy: 4, reviewMistakes: 4, readExplanations: 4, askQuestions: 3, planBeforeTests: 3, solveProblems: 4, timedPractice: 2, repeatProblems: 3 };
  const concentrationAnswers: ScaleAnswers = sample.id === "sample-akari"
    ? { sustainFocus: 3, stopDevices: 2, quietPlace: 4, independentStart: 3, shortWhenTired: 4 }
    : { sustainFocus: 4, stopDevices: 3, quietPlace: 4, independentStart: 4, shortWhenTired: 4 };
  const derived = surveyScores({ motivationAnswers, confidenceAnswers, studyMethodAnswers, concentrationAnswers });
  const survey = await prisma.studySurvey.create({
    data: {
      studentId: sample.id,
      answeredOn: new Date(`${sample.survey.answeredOn}T00:00:00+09:00`),
      currentWeekdayMinutes: sample.survey.currentWeekdayMinutes ?? Math.floor(sample.survey.weekdayAvailableMinutes / 2),
      currentWeekendMinutes: sample.survey.currentWeekendMinutes ?? Math.floor(sample.survey.weekendAvailableMinutes / 2),
      weekdayAvailableMinutes: sample.survey.weekdayAvailableMinutes,
      weekendAvailableMinutes: sample.survey.weekendAvailableMinutes,
      concentrationMinutes: sample.id === "sample-hanako" ? 15 : sample.id === "sample-akari" ? 20 : 25,
      availableDaysPerWeek: sample.survey.availableDays?.length ?? (sample.id === "sample-akari" ? 5 : 6),
      availableDays: sample.survey.availableDays ?? ["MON", "TUE", "WED", "THU", "FRI", "SAT"],
      busyDays: sample.id === "sample-akari" ? ["TUE", "THU"] : ["WED"],
      preferredTimeOfDay: "EVENING",
      motivationAnswers,
      confidenceAnswers,
      studyMethodAnswers,
      concentrationAnswers,
      ...derived,
      concern: sample.survey.concern,
      recentAchievement: "短い時間でも机に向かえる日が増えました。",
      anxiousSubjectsUnits: sample.id === "sample-akari" ? "数学の文章題と一次方程式" : "英語の単語と基本文",
      preferredStudyMethod: "問題を少しずつ解き、すぐ答え合わせをしたいです。",
      subjects: {
        create: Object.keys(sample.survey.studyMinutes).map((subject) => ({
          subject: subject as SubjectKey,
          weeklyStudyMinutes: sample.survey.studyMinutes[subject as SubjectKey],
          confidenceLevel: sample.survey.confidence[subject as SubjectKey],
          selfEvaluationScore: sample.survey.selfEvaluation?.[subject as SubjectKey] ?? sample.survey.confidence[subject as SubjectKey],
          studyFrequencyPerWeek: sample.survey.studyFrequency?.[subject as SubjectKey] ?? 2,
          preferenceScore: Math.max(1, sample.survey.confidence[subject as SubjectKey]),
          difficultyScore: 6 - sample.survey.confidence[subject as SubjectKey],
          easeOfStartingScore: Math.max(1, sample.survey.confidence[subject as SubjectKey] - 1),
          knowsWhatToStudyScore: subject === "MATH" || subject === "ENGLISH" ? 2 : 4,
        })),
      },
    },
    include: { subjects: true },
  });

  const problemSeed = sample.id === "sample-hanako" ? [
    { subject: "MATH" as const, area: "数と式", unit: "一次方程式", majorNumber: "1", minorNumber: "(1)", questionText: "3x+2=14 を解きなさい。", isCorrect: false, mistakeTypes: ["CALCULATION"], isReviewTarget: true, reviewDays: 1 },
    { subject: "MATH" as const, area: "関数", unit: "一次関数", majorNumber: "2", minorNumber: "(1)", questionText: "一次関数 y=2x+1 について、x=3のときのyを求めなさい。", isCorrect: false, mistakeTypes: ["CALCULATION"], isReviewTarget: true, reviewDays: 1 },
    { subject: "MATH" as const, area: "関数", unit: "一次関数", majorNumber: "2", minorNumber: "(2)", questionText: "2点 (0,3)、(2,7) を通る直線の式を求めなさい。", isCorrect: false, mistakeTypes: ["MISREAD"], isReviewTarget: true, reviewDays: 3 },
    { subject: "MATH" as const, area: "関数", unit: "一次関数", majorNumber: "2", minorNumber: "(3)", questionText: "基本料金200円、1kmごとに80円かかるとき、距離x kmと料金y円の関係を式で表しなさい。", isCorrect: false, mistakeTypes: ["METHOD"], isReviewTarget: true, reviewDays: 3 },
    { subject: "SOCIAL_STUDIES" as const, area: "歴史", unit: "近代日本", majorNumber: "3", minorNumber: "(1)", questionText: "近代日本の出来事を年代順に並べなさい。", isCorrect: true, mistakeTypes: [], isReviewTarget: false, reviewDays: 0 },
    { subject: "ENGLISH" as const, area: "読解", unit: "長文読解", majorNumber: "4", minorNumber: "(3)", questionText: "英文を読み、内容に合う選択肢を選びなさい。", isCorrect: false, mistakeTypes: ["TIME"], isReviewTarget: true, reviewDays: 7 },
  ] : [];
  const problems = [];
  for (const item of problemSeed) {
    const problem = await prisma.problemProfile.create({ data: {
      studentId: sample.id, academicTestId: tests[2].id, testName: tests[2].name, attemptedOn: tests[2].takenOn,
      subject: item.subject, majorNumber: item.majorNumber, minorNumber: item.minorNumber, area: item.area, unit: item.unit,
      questionFormat: item.subject === "ENGLISH" ? "選択・記述" : "短答", difficulty: "BASIC", points: 5,
      studentAnswer: item.isCorrect ? "正答例" : "誤答例", correctAnswer: "正答例", isCorrect: item.isCorrect,
      answerSeconds: item.subject === "ENGLISH" ? 420 : 180, isUnanswered: false, mistakeTypes: item.mistakeTypes,
      instructorComment: item.isCorrect ? "安定して解けています。" : "途中の考え方を確認しましょう。", isReviewTarget: item.isReviewTarget,
      questionText: item.questionText,
    } });
    problems.push(problem);
    if (item.isReviewTarget) await prisma.reviewProfile.create({ data: { studentId: sample.id, problemProfileId: problem.id, status: "SCHEDULED", nextReviewOn: addDays(problem.attemptedOn, item.reviewDays) } });
  }

  const currentScores: ScoreInput[] = tests[2].scores.map((item) => ({
    subject: item.subject as SubjectKey,
    score: item.score,
    maxScore: item.maxScore,
  }));
  const previousScores: ScoreInput[] = tests[1].scores.map((item) => ({
    subject: item.subject as SubjectKey,
    score: item.score,
    maxScore: item.maxScore,
  }));
  const surveySubjects: SurveySubjectInput[] = survey.subjects.map((item) => ({
    subject: item.subject as SubjectKey,
    weeklyStudyMinutes: item.weeklyStudyMinutes,
    confidenceLevel: item.confidenceLevel,
    selfEvaluationScore: item.selfEvaluationScore,
    studyFrequencyPerWeek: item.studyFrequencyPerWeek,
    preferenceScore: item.preferenceScore,
    difficultyScore: item.difficultyScore,
    easeOfStartingScore: item.easeOfStartingScore,
    knowsWhatToStudyScore: item.knowsWhatToStudyScore,
  }));
  const recentScores = [...tests].reverse().map((test) => test.scores.map((item) => ({ subject: item.subject as SubjectKey, score: item.score, maxScore: item.maxScore })));
  const priorities = calculatePriorities({ currentScores, previousScores, recentScores, surveySubjects });
  const profile: LearningSurveyProfile = {
    currentWeekdayMinutes: survey.currentWeekdayMinutes,
    currentWeekendMinutes: survey.currentWeekendMinutes,
    weekdayAvailableMinutes: survey.weekdayAvailableMinutes,
    weekendAvailableMinutes: survey.weekendAvailableMinutes,
    concentrationMinutes: survey.concentrationMinutes,
    availableDaysPerWeek: survey.availableDaysPerWeek,
    availableDays: Array.isArray(survey.availableDays) ? survey.availableDays as LearningSurveyProfile["availableDays"] : [],
    busyDays: Array.isArray(survey.busyDays) ? survey.busyDays as LearningSurveyProfile["busyDays"] : [],
    preferredTimeOfDay: survey.preferredTimeOfDay,
    anxiousSubjectsUnits: survey.anxiousSubjectsUnits,
    motivationAnswers, confidenceAnswers, studyMethodAnswers, concentrationAnswers,
    ...derived,
    subjects: surveySubjects.map((item) => ({
      ...item,
      selfEvaluationScore: item.selfEvaluationScore ?? 3,
      studyFrequencyPerWeek: item.studyFrequencyPerWeek ?? 0,
      preferenceScore: item.preferenceScore ?? 3,
      difficultyScore: item.difficultyScore ?? 3,
      easeOfStartingScore: item.easeOfStartingScore ?? 3,
      knowsWhatToStudyScore: item.knowsWhatToStudyScore ?? 3,
    })),
  };
  const tendencies = analyzeLearningTendencies(profile, { currentScores, previousScores, recentScores, surveySubjects });
  const summary = buildLearningSummary(profile, priorities, tendencies);
  const unitBySubject: Partial<Record<SubjectKey, string>> = sample.id === "sample-hanako" ? { MATH: "一次方程式", ENGLISH: "長文読解" } : {};
  const analysis = await prisma.analysisResult.create({
    data: {
      studentId: sample.id,
      academicTestId: tests[2].id,
      previousAcademicTestId: tests[1].id,
      studySurveyId: survey.id,
      status: "COMPLETE",
      ruleVersion: ANALYSIS_RULE_VERSION,
      inputSnapshot: { schemaVersion: 4, source: "sample-seed", academicTestIds: tests.map((test) => test.id), academicTests: [...tests].reverse().map((test) => ({ id: test.id, updatedAt: test.updatedAt.toISOString() })), studySurveyId: survey.id, testUpdatedAt: tests[2].updatedAt.toISOString(), surveyUpdatedAt: survey.updatedAt.toISOString(), problemProfileIds: problems.map((problem) => problem.id) },
      summarySnapshot: { ...(summary ?? {}), priorityUnits: unitBySubject },
      subjectAnalyses: {
        create: priorities.map((item) => ({
          subject: item.subject,
          priorityScore: item.priorityScore,
          priorityRank: item.priorityRank,
          latestScoreRate: item.latestScoreRate,
          scoreRateDelta: item.scoreRateDelta,
          recentScoreRates: item.recentScoreRates,
          selfEvaluationScore: item.selfEvaluationScore,
          confidenceLevel: item.confidenceLevel,
          recognitionLabel: item.recognitionLabel,
          analysisComment: item.analysisComment,
          priorityUnit: unitBySubject[item.subject] ?? (item.priorityRank <= 2 ? survey.anxiousSubjectsUnits : null),
          reasonsSnapshot: item.reasons,
        })),
      },
      learningTendencies: {
        create: tendencies.map((item) => ({
          tendencyType: item.tendencyType,
          score: item.score,
          evidence: item.evidence,
          recommendation: { statement: item.statement, items: item.recommendations },
        })),
      },
    },
  });

  const weekStartOn = new Date("2026-08-03T00:00:00+09:00");
  const draft = generateStudyPlan({
    priorities,
    survey: profile,
    tendencies,
    priorityUnits: unitBySubject,
    dueReviews: problemSeed.filter((item) => item.isReviewTarget).map((item) => ({ subject: item.subject, unit: item.unit })),
  });
  const weeklyPlan = await prisma.weeklyStudyPlan.create({
    data: {
      studentId: sample.id,
      analysisResultId: analysis.id,
      weekStartOn,
      version: 1,
      status: "CONFIRMED",
      availableMinutesSnapshot: draft.availableMinutes,
      plannedMinutes: draft.plannedMinutes,
      ruleVersion: PLAN_RULE_VERSION,
      weeklyGoal: draft.weeklyGoal,
      recommendedDays: draft.recommendedDays,
      recommendedSessionMinutes: draft.recommendedSessionMinutes,
      generatedBy: "RULE",
      confirmedAt: new Date(),
      items: {
        create: draft.items.map((item) => ({
          plannedOn: addDays(weekStartOn, item.dayOffset),
          sequence: item.sequence,
          subject: item.subject,
          durationMinutes: item.durationMinutes,
          guidance: item.guidance,
          unit: item.unit,
          purpose: item.purpose,
          activity: item.activity,
          problemCount: item.problemCount,
          difficulty: item.difficulty,
          studyMethod: item.studyMethod,
          completionCriteria: item.completionCriteria,
          reason: item.reason,
        })),
      },
    },
    include: { items: true },
  });

  if (sample.id === "sample-hanako") {
    const linearSources = problems.filter((problem) => problem.unit === "一次関数");
    const settings = { requestedCounts: { BASIC: 3, SIMILAR: 3, STANDARD: 2, EXAM_STYLE: 1, ADVANCED: 0 }, studyPurpose: ["解法の定着", "計算ミスの改善", "復習"], sessionMinutes: 15, totalProblems: 9, difficultyLimit: "STANDARD", includeVisuals: false, includeWritten: true, useTimeLimit: true, includeHints: true, includeDetailedExplanations: true, includeAnswerSheet: true };
    const generation = await prisma.problemGenerationSession.create({ data: {
      studentId: sample.id, academicTestId: tests[2].id, weeklyStudyPlanId: weeklyPlan.id, subject: "MATH", grade: sample.grade,
      unit: "一次関数", schemaVersion: "1.0", studentAnonymousId: "anon_seed_hanako_linear", generationToken: "seed-generation-token-hanako-linear-v1",
      status: "CONFIRMED", sourceProblemIds: linearSources.map((problem) => problem.id), studyPlanItemIds: weeklyPlan.items?.map?.((item) => item.id) ?? [],
      generatedPrompt: "開発用サンプル。氏名を含まない一次関数の類似問題生成依頼です。", requestedSettings: settings,
      confirmedAt: new Date(), confirmedBy: "LOCAL_USER",
    } });
    const sampleGenerated = [
      ["linear-basic-1","BASIC","一次関数 y=3x+2 で、x=2のときのyを求めなさい。","8",3],
      ["linear-basic-2","BASIC","一次関数 y=-2x+5 で、x=1のときのyを求めなさい。","3",3],
      ["linear-basic-3","BASIC","傾きが4、切片が-1の一次関数の式を書きなさい。","y=4x-1",4],
      ["linear-similar-1","SIMILAR","2点 (0,1)、(3,7) を通る直線の式を求めなさい。","y=2x+1",5],
      ["linear-similar-2","SIMILAR","2点 (1,4)、(3,8) を通る直線の式を求めなさい。","y=2x+2",5],
      ["linear-similar-3","SIMILAR","基本料金300円、1kmごとに70円かかるとき、距離x kmと料金y円の関係を式で表しなさい。","y=70x+300",5],
      ["linear-standard-1","STANDARD","一次関数 y=ax+3 が点 (2,11) を通るとき、aを求めなさい。","4",6],
      ["linear-standard-2","STANDARD","直線 y=2x-1 と y=-x+8 の交点を求めなさい。","(3,5)",7],
      ["linear-exam-1","EXAM_STYLE","水槽に毎分4Lずつ水を入れる。入れ始めに6L入っていたとき、x分後の水量yLを式で表し、10分後の水量を求めなさい。","y=4x+6、46L",8],
    ] as const;
    const generatedIds: string[] = [];
    for (let index = 0; index < sampleGenerated.length; index += 1) {
      const [problemId, level, questionText, correctAnswer, estimatedMinutes] = sampleGenerated[index];
      const source = linearSources[index % linearSources.length];
      const generated = await prisma.generatedProblem.create({ data: {
        sessionId: generation.id, problemId, level, field: "関数", unit: "一次関数", questionType: questionText.includes("式を書") || questionText.includes("表し") ? "WRITTEN_RESPONSE" : "SHORT_ANSWER",
        difficulty: level === "BASIC" ? "BASIC" : level === "EXAM_STYLE" ? "ADVANCED" : "STANDARD", questionText, choices: [], hasVisual: false,
        points: level === "EXAM_STYLE" ? 8 : 5, estimatedMinutes, hint: "傾きと切片、または2点の変化量を確認しましょう。", correctAnswer,
        alternativeAnswers: [], solutionSteps: ["変化の割合（傾き）を確認する", "切片または通る点を代入する", "式と答えを見直す"],
        explanation: "一次関数 y=ax+b の傾きaと切片bを、与えられた条件から順に決めます。", scoringCriteria: questionText.includes("式を書") || questionText.includes("表し") ? ["傾きが正しい", "切片が正しい"] : [],
        requiredKnowledge: ["一次関数", "傾き", "切片"], commonMistakes: ["傾きの計算ミス", "切片の読み違い"],
        sourceSimilarity: { commonKnowledge: ["一次関数"], commonMethod: ["傾きと切片を求める"], changedConditions: ["数値または場面を変更"], difficultyDifference: level === "BASIC" ? "元問題より基礎的" : "同程度または段階的に発展" },
        validationNotes: [], confidence: 92, needsHumanReview: false, programCheckStatus: "NEEDS_REVIEW", programCheckNotes: ["開発サンプルは人が確認済み"],
        reviewStatus: "CONFIRMED", approvalStatus: "APPROVED", approvedAt: new Date(), approvedBy: "LOCAL_USER", reviewedAt: new Date(), reviewedBy: "LOCAL_USER",
        sources: { create: { problemProfileId: source.id } },
      } });
      generatedIds.push(generated.id);
    }
    await prisma.workbook.create({ data: {
      studentId: sample.id, name: "一次関数 個別復習問題集", subject: "MATH", learningPurpose: "前回誤答→基礎確認→類似問題→定着確認", timeLimitMinutes: 45,
      includeAnswers: true, includeExplanations: true, includeHints: true, includeReflection: true, showStudentName: false,
      items: { create: generatedIds.map((generatedProblemId, index) => ({ generatedProblemId, sortOrder: index + 1 })) },
    } });
  }
}

async function main(): Promise<void> {
  for (const sample of samples) await seedStudent(sample);
  console.log(`サンプル生徒 ${samples.length} 名を登録しました。`);
}

main()
  .then(() => prisma.$disconnect())
  .catch(async (error: unknown) => {
    console.error(error);
    await prisma.$disconnect();
    process.exit(1);
  });
