-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_AnalysisResult" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "studentId" TEXT NOT NULL,
    "academicTestId" TEXT,
    "previousAcademicTestId" TEXT,
    "studySurveyId" TEXT,
    "status" TEXT NOT NULL,
    "ruleVersion" TEXT NOT NULL,
    "inputSnapshot" JSONB NOT NULL,
    "summarySnapshot" JSONB NOT NULL DEFAULT '{}',
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "AnalysisResult_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES "Student" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "AnalysisResult_academicTestId_fkey" FOREIGN KEY ("academicTestId") REFERENCES "AcademicTest" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "AnalysisResult_previousAcademicTestId_fkey" FOREIGN KEY ("previousAcademicTestId") REFERENCES "AcademicTest" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "AnalysisResult_studySurveyId_fkey" FOREIGN KEY ("studySurveyId") REFERENCES "StudySurvey" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);
INSERT INTO "new_AnalysisResult" ("academicTestId", "createdAt", "id", "inputSnapshot", "previousAcademicTestId", "ruleVersion", "status", "studentId", "studySurveyId", "summarySnapshot") SELECT "academicTestId", "createdAt", "id", "inputSnapshot", "previousAcademicTestId", "ruleVersion", "status", "studentId", "studySurveyId", "summarySnapshot" FROM "AnalysisResult";
DROP TABLE "AnalysisResult";
ALTER TABLE "new_AnalysisResult" RENAME TO "AnalysisResult";
CREATE INDEX "AnalysisResult_studentId_createdAt_idx" ON "AnalysisResult"("studentId", "createdAt");
CREATE TABLE "new_StudyRecord" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "studyPlanItemId" TEXT NOT NULL,
    "completed" BOOLEAN NOT NULL DEFAULT false,
    "actualMinutes" INTEGER NOT NULL DEFAULT 0,
    "attemptedCount" INTEGER NOT NULL DEFAULT 0,
    "correctCount" INTEGER NOT NULL DEFAULT 0,
    "difficultyRating" INTEGER,
    "concentrationRating" INTEGER,
    "retryPreference" BOOLEAN,
    "mistakeTypes" JSONB NOT NULL DEFAULT '[]',
    "studentComment" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "StudyRecord_studyPlanItemId_fkey" FOREIGN KEY ("studyPlanItemId") REFERENCES "StudyPlanItem" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO "new_StudyRecord" ("actualMinutes", "attemptedCount", "completed", "concentrationRating", "correctCount", "createdAt", "difficultyRating", "id", "mistakeTypes", "retryPreference", "studentComment", "studyPlanItemId", "updatedAt") SELECT "actualMinutes", "attemptedCount", "completed", "concentrationRating", "correctCount", "createdAt", "difficultyRating", "id", "mistakeTypes", "retryPreference", "studentComment", "studyPlanItemId", "updatedAt" FROM "StudyRecord";
DROP TABLE "StudyRecord";
ALTER TABLE "new_StudyRecord" RENAME TO "StudyRecord";
CREATE UNIQUE INDEX "StudyRecord_studyPlanItemId_key" ON "StudyRecord"("studyPlanItemId");
CREATE INDEX "StudyRecord_studyPlanItemId_idx" ON "StudyRecord"("studyPlanItemId");
CREATE TABLE "new_StudySurvey" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "studentId" TEXT NOT NULL,
    "answeredOn" DATETIME NOT NULL,
    "weekdayAvailableMinutes" INTEGER NOT NULL,
    "weekendAvailableMinutes" INTEGER NOT NULL,
    "concentrationMinutes" INTEGER NOT NULL DEFAULT 15,
    "availableDaysPerWeek" INTEGER NOT NULL DEFAULT 3,
    "busyDays" JSONB NOT NULL DEFAULT '[]',
    "preferredTimeOfDay" TEXT NOT NULL DEFAULT 'EVENING',
    "motivationScore" REAL NOT NULL DEFAULT 3,
    "confidenceScore" REAL NOT NULL DEFAULT 3,
    "studyHabitScore" REAL NOT NULL DEFAULT 3,
    "reviewHabitScore" REAL NOT NULL DEFAULT 3,
    "concentrationScore" REAL NOT NULL DEFAULT 3,
    "environmentScore" REAL NOT NULL DEFAULT 3,
    "motivationAnswers" JSONB NOT NULL DEFAULT '{}',
    "confidenceAnswers" JSONB NOT NULL DEFAULT '{}',
    "studyMethodAnswers" JSONB NOT NULL DEFAULT '{}',
    "concentrationAnswers" JSONB NOT NULL DEFAULT '{}',
    "concern" TEXT,
    "recentAchievement" TEXT,
    "anxiousSubjectsUnits" TEXT,
    "preferredStudyMethod" TEXT,
    "familyConsideration" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "StudySurvey_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES "Student" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO "new_StudySurvey" ("answeredOn", "anxiousSubjectsUnits", "availableDaysPerWeek", "busyDays", "concentrationAnswers", "concentrationMinutes", "concentrationScore", "concern", "confidenceAnswers", "confidenceScore", "createdAt", "environmentScore", "familyConsideration", "id", "motivationAnswers", "motivationScore", "preferredStudyMethod", "preferredTimeOfDay", "recentAchievement", "reviewHabitScore", "studentId", "studyHabitScore", "studyMethodAnswers", "updatedAt", "weekdayAvailableMinutes", "weekendAvailableMinutes") SELECT "answeredOn", "anxiousSubjectsUnits", "availableDaysPerWeek", "busyDays", "concentrationAnswers", "concentrationMinutes", "concentrationScore", "concern", "confidenceAnswers", "confidenceScore", "createdAt", "environmentScore", "familyConsideration", "id", "motivationAnswers", "motivationScore", "preferredStudyMethod", "preferredTimeOfDay", "recentAchievement", "reviewHabitScore", "studentId", "studyHabitScore", "studyMethodAnswers", "updatedAt", "weekdayAvailableMinutes", "weekendAvailableMinutes" FROM "StudySurvey";
DROP TABLE "StudySurvey";
ALTER TABLE "new_StudySurvey" RENAME TO "StudySurvey";
CREATE INDEX "StudySurvey_studentId_answeredOn_idx" ON "StudySurvey"("studentId", "answeredOn");
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;
