-- Preserve the meaning of existing survey answers when introducing the new fields.
UPDATE "StudySurvey"
SET "availableDays" = '["MON","TUE","WED","THU","FRI","SAT","SUN"]'
WHERE json_array_length("availableDays") = 0;

UPDATE "StudySurveySubject"
SET "selfEvaluationScore" = 6 - "difficultyScore";
