-- CreateTable
CREATE TABLE "Student" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "displayName" TEXT NOT NULL,
    "grade" TEXT NOT NULL,
    "schoolName" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);

-- CreateTable
CREATE TABLE "TargetSchool" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "studentId" TEXT NOT NULL,
    "schoolName" TEXT NOT NULL,
    "preferenceRank" INTEGER NOT NULL,
    "targetTotalScore" INTEGER,
    "note" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "TargetSchool_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES "Student" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "AcademicTest" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "studentId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "takenOn" DATETIME NOT NULL,
    "note" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "AcademicTest_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES "Student" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "AcademicTestScore" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "academicTestId" TEXT NOT NULL,
    "subject" TEXT NOT NULL,
    "score" INTEGER NOT NULL,
    "maxScore" INTEGER NOT NULL,
    CONSTRAINT "AcademicTestScore_academicTestId_fkey" FOREIGN KEY ("academicTestId") REFERENCES "AcademicTest" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "StudySurvey" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "studentId" TEXT NOT NULL,
    "answeredOn" DATETIME NOT NULL,
    "weekdayAvailableMinutes" INTEGER NOT NULL,
    "weekendAvailableMinutes" INTEGER NOT NULL,
    "concern" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "StudySurvey_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES "Student" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "StudySurveySubject" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "studySurveyId" TEXT NOT NULL,
    "subject" TEXT NOT NULL,
    "weeklyStudyMinutes" INTEGER NOT NULL,
    "confidenceLevel" INTEGER NOT NULL,
    CONSTRAINT "StudySurveySubject_studySurveyId_fkey" FOREIGN KEY ("studySurveyId") REFERENCES "StudySurvey" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "AnalysisResult" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "studentId" TEXT NOT NULL,
    "academicTestId" TEXT,
    "previousAcademicTestId" TEXT,
    "studySurveyId" TEXT,
    "status" TEXT NOT NULL,
    "ruleVersion" TEXT NOT NULL,
    "inputSnapshot" JSONB NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "AnalysisResult_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES "Student" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "AnalysisResult_academicTestId_fkey" FOREIGN KEY ("academicTestId") REFERENCES "AcademicTest" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "AnalysisResult_previousAcademicTestId_fkey" FOREIGN KEY ("previousAcademicTestId") REFERENCES "AcademicTest" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "AnalysisResult_studySurveyId_fkey" FOREIGN KEY ("studySurveyId") REFERENCES "StudySurvey" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "SubjectAnalysis" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "analysisResultId" TEXT NOT NULL,
    "subject" TEXT NOT NULL,
    "priorityScore" INTEGER NOT NULL,
    "priorityRank" INTEGER NOT NULL,
    "latestScoreRate" REAL,
    "scoreRateDelta" REAL,
    "reasonsSnapshot" JSONB NOT NULL,
    CONSTRAINT "SubjectAnalysis_analysisResultId_fkey" FOREIGN KEY ("analysisResultId") REFERENCES "AnalysisResult" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "WeeklyStudyPlan" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "studentId" TEXT NOT NULL,
    "analysisResultId" TEXT NOT NULL,
    "weekStartOn" DATETIME NOT NULL,
    "version" INTEGER NOT NULL,
    "status" TEXT NOT NULL,
    "availableMinutesSnapshot" INTEGER NOT NULL,
    "plannedMinutes" INTEGER NOT NULL,
    "ruleVersion" TEXT NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "WeeklyStudyPlan_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES "Student" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "WeeklyStudyPlan_analysisResultId_fkey" FOREIGN KEY ("analysisResultId") REFERENCES "AnalysisResult" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "StudyPlanItem" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "weeklyStudyPlanId" TEXT NOT NULL,
    "plannedOn" DATETIME NOT NULL,
    "sequence" INTEGER NOT NULL,
    "subject" TEXT NOT NULL,
    "durationMinutes" INTEGER NOT NULL,
    "guidance" TEXT NOT NULL,
    CONSTRAINT "StudyPlanItem_weeklyStudyPlanId_fkey" FOREIGN KEY ("weeklyStudyPlanId") REFERENCES "WeeklyStudyPlan" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateIndex
CREATE INDEX "TargetSchool_studentId_idx" ON "TargetSchool"("studentId");

-- CreateIndex
CREATE UNIQUE INDEX "TargetSchool_studentId_preferenceRank_key" ON "TargetSchool"("studentId", "preferenceRank");

-- CreateIndex
CREATE INDEX "AcademicTest_studentId_takenOn_idx" ON "AcademicTest"("studentId", "takenOn");

-- CreateIndex
CREATE INDEX "AcademicTestScore_academicTestId_idx" ON "AcademicTestScore"("academicTestId");

-- CreateIndex
CREATE UNIQUE INDEX "AcademicTestScore_academicTestId_subject_key" ON "AcademicTestScore"("academicTestId", "subject");

-- CreateIndex
CREATE INDEX "StudySurvey_studentId_answeredOn_idx" ON "StudySurvey"("studentId", "answeredOn");

-- CreateIndex
CREATE INDEX "StudySurveySubject_studySurveyId_idx" ON "StudySurveySubject"("studySurveyId");

-- CreateIndex
CREATE UNIQUE INDEX "StudySurveySubject_studySurveyId_subject_key" ON "StudySurveySubject"("studySurveyId", "subject");

-- CreateIndex
CREATE INDEX "AnalysisResult_studentId_createdAt_idx" ON "AnalysisResult"("studentId", "createdAt");

-- CreateIndex
CREATE INDEX "SubjectAnalysis_analysisResultId_idx" ON "SubjectAnalysis"("analysisResultId");

-- CreateIndex
CREATE UNIQUE INDEX "SubjectAnalysis_analysisResultId_subject_key" ON "SubjectAnalysis"("analysisResultId", "subject");

-- CreateIndex
CREATE UNIQUE INDEX "SubjectAnalysis_analysisResultId_priorityRank_key" ON "SubjectAnalysis"("analysisResultId", "priorityRank");

-- CreateIndex
CREATE INDEX "WeeklyStudyPlan_studentId_weekStartOn_status_idx" ON "WeeklyStudyPlan"("studentId", "weekStartOn", "status");

-- CreateIndex
CREATE UNIQUE INDEX "WeeklyStudyPlan_studentId_weekStartOn_version_key" ON "WeeklyStudyPlan"("studentId", "weekStartOn", "version");

-- CreateIndex
CREATE INDEX "StudyPlanItem_weeklyStudyPlanId_idx" ON "StudyPlanItem"("weeklyStudyPlanId");

-- CreateIndex
CREATE UNIQUE INDEX "StudyPlanItem_weeklyStudyPlanId_plannedOn_sequence_key" ON "StudyPlanItem"("weeklyStudyPlanId", "plannedOn", "sequence");
