-- CreateTable
CREATE TABLE "LearningTendency" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "analysisResultId" TEXT NOT NULL,
    "tendencyType" TEXT NOT NULL,
    "score" INTEGER NOT NULL,
    "evidence" JSONB NOT NULL,
    "recommendation" JSONB NOT NULL,
    "analyzedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "LearningTendency_analysisResultId_fkey" FOREIGN KEY ("analysisResultId") REFERENCES "AnalysisResult" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "StudyRecord" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "studyPlanItemId" TEXT NOT NULL,
    "completed" BOOLEAN NOT NULL DEFAULT false,
    "actualMinutes" INTEGER NOT NULL DEFAULT 0,
    "attemptedCount" INTEGER NOT NULL DEFAULT 0,
    "correctCount" INTEGER NOT NULL DEFAULT 0,
    "difficultyRating" INTEGER,
    "concentrationRating" INTEGER,
    "retryPreference" BOOLEAN,
    "mistakeTypes" JSONB NOT NULL DEFAULT '[]',
    "studentComment" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "StudyRecord_studyPlanItemId_fkey" FOREIGN KEY ("studyPlanItemId") REFERENCES "StudyPlanItem" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_AnalysisResult" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "studentId" TEXT NOT NULL,
    "academicTestId" TEXT,
    "previousAcademicTestId" TEXT,
    "studySurveyId" TEXT,
    "status" TEXT NOT NULL,
    "ruleVersion" TEXT NOT NULL,
    "inputSnapshot" JSONB NOT NULL,
    "summarySnapshot" JSONB NOT NULL DEFAULT '{}',
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "AnalysisResult_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES "Student" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "AnalysisResult_academicTestId_fkey" FOREIGN KEY ("academicTestId") REFERENCES "AcademicTest" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "AnalysisResult_previousAcademicTestId_fkey" FOREIGN KEY ("previousAcademicTestId") REFERENCES "AcademicTest" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "AnalysisResult_studySurveyId_fkey" FOREIGN KEY ("studySurveyId") REFERENCES "StudySurvey" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);
INSERT INTO "new_AnalysisResult" ("academicTestId", "createdAt", "id", "inputSnapshot", "previousAcademicTestId", "ruleVersion", "status", "studentId", "studySurveyId") SELECT "academicTestId", "createdAt", "id", "inputSnapshot", "previousAcademicTestId", "ruleVersion", "status", "studentId", "studySurveyId" FROM "AnalysisResult";
DROP TABLE "AnalysisResult";
ALTER TABLE "new_AnalysisResult" RENAME TO "AnalysisResult";
CREATE INDEX "AnalysisResult_studentId_createdAt_idx" ON "AnalysisResult"("studentId", "createdAt");
CREATE TABLE "new_StudyPlanItem" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "weeklyStudyPlanId" TEXT NOT NULL,
    "plannedOn" DATETIME NOT NULL,
    "sequence" INTEGER NOT NULL,
    "subject" TEXT NOT NULL,
    "durationMinutes" INTEGER NOT NULL,
    "guidance" TEXT NOT NULL,
    "unit" TEXT NOT NULL DEFAULT '基礎・前回の誤答',
    "purpose" TEXT NOT NULL DEFAULT '',
    "activity" TEXT NOT NULL DEFAULT '',
    "problemCount" INTEGER NOT NULL DEFAULT 5,
    "difficulty" TEXT NOT NULL DEFAULT 'BASIC',
    "studyMethod" TEXT NOT NULL DEFAULT '',
    "completionCriteria" TEXT NOT NULL DEFAULT '',
    "reason" TEXT NOT NULL DEFAULT '',
    CONSTRAINT "StudyPlanItem_weeklyStudyPlanId_fkey" FOREIGN KEY ("weeklyStudyPlanId") REFERENCES "WeeklyStudyPlan" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO "new_StudyPlanItem" ("durationMinutes", "guidance", "id", "plannedOn", "sequence", "subject", "weeklyStudyPlanId") SELECT "durationMinutes", "guidance", "id", "plannedOn", "sequence", "subject", "weeklyStudyPlanId" FROM "StudyPlanItem";
DROP TABLE "StudyPlanItem";
ALTER TABLE "new_StudyPlanItem" RENAME TO "StudyPlanItem";
CREATE INDEX "StudyPlanItem_weeklyStudyPlanId_idx" ON "StudyPlanItem"("weeklyStudyPlanId");
CREATE UNIQUE INDEX "StudyPlanItem_weeklyStudyPlanId_plannedOn_sequence_key" ON "StudyPlanItem"("weeklyStudyPlanId", "plannedOn", "sequence");
CREATE TABLE "new_StudySurvey" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "studentId" TEXT NOT NULL,
    "answeredOn" DATETIME NOT NULL,
    "weekdayAvailableMinutes" INTEGER NOT NULL,
    "weekendAvailableMinutes" INTEGER NOT NULL,
    "concentrationMinutes" INTEGER NOT NULL DEFAULT 15,
    "availableDaysPerWeek" INTEGER NOT NULL DEFAULT 3,
    "busyDays" JSONB NOT NULL DEFAULT '[]',
    "preferredTimeOfDay" TEXT NOT NULL DEFAULT 'EVENING',
    "motivationScore" REAL NOT NULL DEFAULT 3,
    "confidenceScore" REAL NOT NULL DEFAULT 3,
    "studyHabitScore" REAL NOT NULL DEFAULT 3,
    "reviewHabitScore" REAL NOT NULL DEFAULT 3,
    "concentrationScore" REAL NOT NULL DEFAULT 3,
    "environmentScore" REAL NOT NULL DEFAULT 3,
    "motivationAnswers" JSONB NOT NULL DEFAULT '{}',
    "confidenceAnswers" JSONB NOT NULL DEFAULT '{}',
    "studyMethodAnswers" JSONB NOT NULL DEFAULT '{}',
    "concentrationAnswers" JSONB NOT NULL DEFAULT '{}',
    "concern" TEXT,
    "recentAchievement" TEXT,
    "anxiousSubjectsUnits" TEXT,
    "preferredStudyMethod" TEXT,
    "familyConsideration" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "StudySurvey_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES "Student" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO "new_StudySurvey" ("answeredOn", "concern", "createdAt", "id", "studentId", "updatedAt", "weekdayAvailableMinutes", "weekendAvailableMinutes") SELECT "answeredOn", "concern", "createdAt", "id", "studentId", "updatedAt", "weekdayAvailableMinutes", "weekendAvailableMinutes" FROM "StudySurvey";
DROP TABLE "StudySurvey";
ALTER TABLE "new_StudySurvey" RENAME TO "StudySurvey";
CREATE INDEX "StudySurvey_studentId_answeredOn_idx" ON "StudySurvey"("studentId", "answeredOn");
CREATE TABLE "new_StudySurveySubject" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "studySurveyId" TEXT NOT NULL,
    "subject" TEXT NOT NULL,
    "weeklyStudyMinutes" INTEGER NOT NULL,
    "confidenceLevel" INTEGER NOT NULL,
    "preferenceScore" INTEGER NOT NULL DEFAULT 3,
    "difficultyScore" INTEGER NOT NULL DEFAULT 3,
    "easeOfStartingScore" INTEGER NOT NULL DEFAULT 3,
    "knowsWhatToStudyScore" INTEGER NOT NULL DEFAULT 3,
    CONSTRAINT "StudySurveySubject_studySurveyId_fkey" FOREIGN KEY ("studySurveyId") REFERENCES "StudySurvey" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO "new_StudySurveySubject" ("confidenceLevel", "id", "studySurveyId", "subject", "weeklyStudyMinutes") SELECT "confidenceLevel", "id", "studySurveyId", "subject", "weeklyStudyMinutes" FROM "StudySurveySubject";
DROP TABLE "StudySurveySubject";
ALTER TABLE "new_StudySurveySubject" RENAME TO "StudySurveySubject";
CREATE INDEX "StudySurveySubject_studySurveyId_idx" ON "StudySurveySubject"("studySurveyId");
CREATE UNIQUE INDEX "StudySurveySubject_studySurveyId_subject_key" ON "StudySurveySubject"("studySurveyId", "subject");
CREATE TABLE "new_WeeklyStudyPlan" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "studentId" TEXT NOT NULL,
    "analysisResultId" TEXT NOT NULL,
    "weekStartOn" DATETIME NOT NULL,
    "version" INTEGER NOT NULL,
    "status" TEXT NOT NULL,
    "availableMinutesSnapshot" INTEGER NOT NULL,
    "plannedMinutes" INTEGER NOT NULL,
    "ruleVersion" TEXT NOT NULL,
    "weeklyGoal" TEXT NOT NULL DEFAULT '',
    "recommendedDays" INTEGER NOT NULL DEFAULT 3,
    "recommendedSessionMinutes" INTEGER NOT NULL DEFAULT 15,
    "generatedBy" TEXT NOT NULL DEFAULT 'RULE',
    "confirmedAt" DATETIME,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "WeeklyStudyPlan_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES "Student" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "WeeklyStudyPlan_analysisResultId_fkey" FOREIGN KEY ("analysisResultId") REFERENCES "AnalysisResult" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
INSERT INTO "new_WeeklyStudyPlan" ("analysisResultId", "availableMinutesSnapshot", "createdAt", "id", "plannedMinutes", "ruleVersion", "status", "studentId", "version", "weekStartOn") SELECT "analysisResultId", "availableMinutesSnapshot", "createdAt", "id", "plannedMinutes", "ruleVersion", "status", "studentId", "version", "weekStartOn" FROM "WeeklyStudyPlan";
DROP TABLE "WeeklyStudyPlan";
ALTER TABLE "new_WeeklyStudyPlan" RENAME TO "WeeklyStudyPlan";
CREATE INDEX "WeeklyStudyPlan_studentId_weekStartOn_status_idx" ON "WeeklyStudyPlan"("studentId", "weekStartOn", "status");
CREATE UNIQUE INDEX "WeeklyStudyPlan_studentId_weekStartOn_version_key" ON "WeeklyStudyPlan"("studentId", "weekStartOn", "version");
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;

-- CreateIndex
CREATE INDEX "LearningTendency_analysisResultId_idx" ON "LearningTendency"("analysisResultId");

-- CreateIndex
CREATE UNIQUE INDEX "LearningTendency_analysisResultId_tendencyType_key" ON "LearningTendency"("analysisResultId", "tendencyType");

-- CreateIndex
CREATE UNIQUE INDEX "StudyRecord_studyPlanItemId_key" ON "StudyRecord"("studyPlanItemId");

-- CreateIndex
CREATE INDEX "StudyRecord_studyPlanItemId_idx" ON "StudyRecord"("studyPlanItemId");
