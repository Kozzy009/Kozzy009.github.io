-- CreateTable
CREATE TABLE "UploadedFile" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "studentId" TEXT NOT NULL,
    "academicTestId" TEXT NOT NULL,
    "importSessionId" TEXT,
    "fileType" TEXT NOT NULL,
    "subject" TEXT NOT NULL,
    "schoolGrade" TEXT,
    "academicYear" INTEGER,
    "originalFileName" TEXT NOT NULL,
    "storedFileName" TEXT NOT NULL,
    "storagePath" TEXT NOT NULL,
    "mimeType" TEXT NOT NULL,
    "extension" TEXT NOT NULL,
    "sizeBytes" INTEGER NOT NULL,
    "fileHash" TEXT NOT NULL,
    "pageCount" INTEGER,
    "uploadedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "uploadedBy" TEXT NOT NULL DEFAULT 'LOCAL_USER',
    "processingStatus" TEXT NOT NULL DEFAULT 'UPLOADED',
    "confirmationStatus" TEXT NOT NULL DEFAULT 'UNCONFIRMED',
    "errorMessage" TEXT,
    "notes" TEXT,
    CONSTRAINT "UploadedFile_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES "Student" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "UploadedFile_academicTestId_fkey" FOREIGN KEY ("academicTestId") REFERENCES "AcademicTest" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "UploadedFile_importSessionId_fkey" FOREIGN KEY ("importSessionId") REFERENCES "ImportSession" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "OcrJob" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "uploadedFileId" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'QUEUED',
    "provider" TEXT NOT NULL,
    "startedAt" DATETIME,
    "completedAt" DATETIME,
    "errorMessage" TEXT,
    "modelName" TEXT,
    "rawResponse" JSONB,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "OcrJob_uploadedFileId_fkey" FOREIGN KEY ("uploadedFileId") REFERENCES "UploadedFile" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "OcrPageResult" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "ocrJobId" TEXT NOT NULL,
    "pageNumber" INTEGER NOT NULL,
    "rawText" TEXT NOT NULL,
    "confidence" REAL,
    "imageWidth" INTEGER,
    "imageHeight" INTEGER,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "OcrPageResult_ocrJobId_fkey" FOREIGN KEY ("ocrJobId") REFERENCES "OcrJob" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "OcrExtractedItem" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "ocrJobId" TEXT NOT NULL,
    "pageNumber" INTEGER NOT NULL,
    "itemType" TEXT NOT NULL,
    "fieldName" TEXT NOT NULL,
    "rawValue" TEXT,
    "normalizedValue" TEXT,
    "confidence" REAL,
    "boundingBox" JSONB,
    "reviewStatus" TEXT NOT NULL DEFAULT 'UNREVIEWED',
    "correctedValue" TEXT,
    "reviewedAt" DATETIME,
    "reviewedBy" TEXT,
    CONSTRAINT "OcrExtractedItem_ocrJobId_fkey" FOREIGN KEY ("ocrJobId") REFERENCES "OcrJob" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "ImportSession" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "studentId" TEXT NOT NULL,
    "academicTestId" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'DRAFT',
    "startedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "confirmedAt" DATETIME,
    "cancelledAt" DATETIME,
    "notes" TEXT,
    "confirmedBy" TEXT,
    CONSTRAINT "ImportSession_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES "Student" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "ImportSession_academicTestId_fkey" FOREIGN KEY ("academicTestId") REFERENCES "AcademicTest" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "ImportCandidateQuestion" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "importSessionId" TEXT NOT NULL,
    "subject" TEXT NOT NULL,
    "majorQuestionNumber" TEXT NOT NULL,
    "minorQuestionNumber" TEXT,
    "questionText" TEXT,
    "answerText" TEXT,
    "correctAnswer" TEXT,
    "score" INTEGER,
    "unit" TEXT,
    "field" TEXT,
    "questionType" TEXT,
    "difficulty" TEXT,
    "confidence" REAL,
    "pageNumber" INTEGER,
    "hasFigure" BOOLEAN NOT NULL DEFAULT false,
    "sourceFileIds" JSONB NOT NULL DEFAULT '[]',
    "matchStatus" TEXT NOT NULL DEFAULT 'MATCHED',
    "gradingStatus" TEXT NOT NULL DEFAULT 'NEEDS_REVIEW',
    "reviewStatus" TEXT NOT NULL DEFAULT 'UNREVIEWED',
    "correctionNotes" TEXT,
    "reviewedAt" DATETIME,
    "reviewedBy" TEXT,
    CONSTRAINT "ImportCandidateQuestion_importSessionId_fkey" FOREIGN KEY ("importSessionId") REFERENCES "ImportSession" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "AuditLog" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "studentId" TEXT,
    "action" TEXT NOT NULL,
    "entityType" TEXT NOT NULL,
    "entityId" TEXT,
    "actor" TEXT NOT NULL DEFAULT 'LOCAL_USER',
    "metadata" JSONB NOT NULL DEFAULT '{}',
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "AuditLog_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES "Student" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);

-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_AnalysisResult" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "studentId" TEXT NOT NULL,
    "academicTestId" TEXT,
    "previousAcademicTestId" TEXT,
    "studySurveyId" TEXT,
    "status" TEXT NOT NULL,
    "ruleVersion" TEXT NOT NULL,
    "inputSnapshot" JSONB NOT NULL,
    "summarySnapshot" JSONB NOT NULL DEFAULT '{}',
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "AnalysisResult_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES "Student" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "AnalysisResult_academicTestId_fkey" FOREIGN KEY ("academicTestId") REFERENCES "AcademicTest" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "AnalysisResult_previousAcademicTestId_fkey" FOREIGN KEY ("previousAcademicTestId") REFERENCES "AcademicTest" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "AnalysisResult_studySurveyId_fkey" FOREIGN KEY ("studySurveyId") REFERENCES "StudySurvey" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);
INSERT INTO "new_AnalysisResult" ("academicTestId", "createdAt", "id", "inputSnapshot", "previousAcademicTestId", "ruleVersion", "status", "studentId", "studySurveyId", "summarySnapshot") SELECT "academicTestId", "createdAt", "id", "inputSnapshot", "previousAcademicTestId", "ruleVersion", "status", "studentId", "studySurveyId", "summarySnapshot" FROM "AnalysisResult";
DROP TABLE "AnalysisResult";
ALTER TABLE "new_AnalysisResult" RENAME TO "AnalysisResult";
CREATE INDEX "AnalysisResult_studentId_createdAt_idx" ON "AnalysisResult"("studentId", "createdAt");
CREATE TABLE "new_ProblemProfile" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "studentId" TEXT NOT NULL,
    "academicTestId" TEXT,
    "testName" TEXT NOT NULL,
    "attemptedOn" DATETIME NOT NULL,
    "subject" TEXT NOT NULL,
    "majorNumber" TEXT NOT NULL,
    "minorNumber" TEXT,
    "area" TEXT NOT NULL,
    "unit" TEXT NOT NULL,
    "questionFormat" TEXT NOT NULL,
    "difficulty" TEXT NOT NULL,
    "points" INTEGER NOT NULL,
    "studentAnswer" TEXT,
    "correctAnswer" TEXT,
    "isCorrect" BOOLEAN NOT NULL,
    "answerSeconds" INTEGER,
    "isUnanswered" BOOLEAN NOT NULL DEFAULT false,
    "mistakeTypes" JSONB NOT NULL DEFAULT '[]',
    "instructorComment" TEXT,
    "isReviewTarget" BOOLEAN NOT NULL DEFAULT false,
    "questionText" TEXT,
    "sourceUploadedFileId" TEXT,
    "importCandidateId" TEXT,
    "reviewedBy" TEXT,
    "reviewedAt" DATETIME,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "ProblemProfile_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES "Student" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "ProblemProfile_academicTestId_fkey" FOREIGN KEY ("academicTestId") REFERENCES "AcademicTest" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "ProblemProfile_sourceUploadedFileId_fkey" FOREIGN KEY ("sourceUploadedFileId") REFERENCES "UploadedFile" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "ProblemProfile_importCandidateId_fkey" FOREIGN KEY ("importCandidateId") REFERENCES "ImportCandidateQuestion" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);
INSERT INTO "new_ProblemProfile" ("academicTestId", "answerSeconds", "area", "attemptedOn", "correctAnswer", "createdAt", "difficulty", "id", "instructorComment", "isCorrect", "isReviewTarget", "isUnanswered", "majorNumber", "minorNumber", "mistakeTypes", "points", "questionFormat", "studentAnswer", "studentId", "subject", "testName", "unit", "updatedAt") SELECT "academicTestId", "answerSeconds", "area", "attemptedOn", "correctAnswer", "createdAt", "difficulty", "id", "instructorComment", "isCorrect", "isReviewTarget", "isUnanswered", "majorNumber", "minorNumber", "mistakeTypes", "points", "questionFormat", "studentAnswer", "studentId", "subject", "testName", "unit", "updatedAt" FROM "ProblemProfile";
DROP TABLE "ProblemProfile";
ALTER TABLE "new_ProblemProfile" RENAME TO "ProblemProfile";
CREATE UNIQUE INDEX "ProblemProfile_importCandidateId_key" ON "ProblemProfile"("importCandidateId");
CREATE INDEX "ProblemProfile_studentId_attemptedOn_idx" ON "ProblemProfile"("studentId", "attemptedOn");
CREATE INDEX "ProblemProfile_studentId_subject_unit_idx" ON "ProblemProfile"("studentId", "subject", "unit");
CREATE TABLE "new_StudyRecord" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "studyPlanItemId" TEXT NOT NULL,
    "completed" BOOLEAN NOT NULL DEFAULT false,
    "actualMinutes" INTEGER NOT NULL DEFAULT 0,
    "attemptedCount" INTEGER NOT NULL DEFAULT 0,
    "correctCount" INTEGER NOT NULL DEFAULT 0,
    "difficultyRating" INTEGER,
    "concentrationRating" INTEGER,
    "retryPreference" BOOLEAN,
    "mistakeTypes" JSONB NOT NULL DEFAULT '[]',
    "studentComment" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "StudyRecord_studyPlanItemId_fkey" FOREIGN KEY ("studyPlanItemId") REFERENCES "StudyPlanItem" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO "new_StudyRecord" ("actualMinutes", "attemptedCount", "completed", "concentrationRating", "correctCount", "createdAt", "difficultyRating", "id", "mistakeTypes", "retryPreference", "studentComment", "studyPlanItemId", "updatedAt") SELECT "actualMinutes", "attemptedCount", "completed", "concentrationRating", "correctCount", "createdAt", "difficultyRating", "id", "mistakeTypes", "retryPreference", "studentComment", "studyPlanItemId", "updatedAt" FROM "StudyRecord";
DROP TABLE "StudyRecord";
ALTER TABLE "new_StudyRecord" RENAME TO "StudyRecord";
CREATE UNIQUE INDEX "StudyRecord_studyPlanItemId_key" ON "StudyRecord"("studyPlanItemId");
CREATE INDEX "StudyRecord_studyPlanItemId_idx" ON "StudyRecord"("studyPlanItemId");
CREATE TABLE "new_StudySurvey" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "studentId" TEXT NOT NULL,
    "answeredOn" DATETIME NOT NULL,
    "weekdayAvailableMinutes" INTEGER NOT NULL,
    "weekendAvailableMinutes" INTEGER NOT NULL,
    "currentWeekdayMinutes" INTEGER NOT NULL DEFAULT 0,
    "currentWeekendMinutes" INTEGER NOT NULL DEFAULT 0,
    "concentrationMinutes" INTEGER NOT NULL DEFAULT 15,
    "availableDaysPerWeek" INTEGER NOT NULL DEFAULT 3,
    "availableDays" JSONB NOT NULL DEFAULT '[]',
    "busyDays" JSONB NOT NULL DEFAULT '[]',
    "preferredTimeOfDay" TEXT NOT NULL DEFAULT 'EVENING',
    "motivationScore" REAL NOT NULL DEFAULT 3,
    "confidenceScore" REAL NOT NULL DEFAULT 3,
    "studyHabitScore" REAL NOT NULL DEFAULT 3,
    "reviewHabitScore" REAL NOT NULL DEFAULT 3,
    "concentrationScore" REAL NOT NULL DEFAULT 3,
    "environmentScore" REAL NOT NULL DEFAULT 3,
    "motivationAnswers" JSONB NOT NULL DEFAULT '{}',
    "confidenceAnswers" JSONB NOT NULL DEFAULT '{}',
    "studyMethodAnswers" JSONB NOT NULL DEFAULT '{}',
    "concentrationAnswers" JSONB NOT NULL DEFAULT '{}',
    "concern" TEXT,
    "recentAchievement" TEXT,
    "anxiousSubjectsUnits" TEXT,
    "preferredStudyMethod" TEXT,
    "familyConsideration" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "StudySurvey_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES "Student" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO "new_StudySurvey" ("answeredOn", "anxiousSubjectsUnits", "availableDays", "availableDaysPerWeek", "busyDays", "concentrationAnswers", "concentrationMinutes", "concentrationScore", "concern", "confidenceAnswers", "confidenceScore", "createdAt", "currentWeekdayMinutes", "currentWeekendMinutes", "environmentScore", "familyConsideration", "id", "motivationAnswers", "motivationScore", "preferredStudyMethod", "preferredTimeOfDay", "recentAchievement", "reviewHabitScore", "studentId", "studyHabitScore", "studyMethodAnswers", "updatedAt", "weekdayAvailableMinutes", "weekendAvailableMinutes") SELECT "answeredOn", "anxiousSubjectsUnits", "availableDays", "availableDaysPerWeek", "busyDays", "concentrationAnswers", "concentrationMinutes", "concentrationScore", "concern", "confidenceAnswers", "confidenceScore", "createdAt", "currentWeekdayMinutes", "currentWeekendMinutes", "environmentScore", "familyConsideration", "id", "motivationAnswers", "motivationScore", "preferredStudyMethod", "preferredTimeOfDay", "recentAchievement", "reviewHabitScore", "studentId", "studyHabitScore", "studyMethodAnswers", "updatedAt", "weekdayAvailableMinutes", "weekendAvailableMinutes" FROM "StudySurvey";
DROP TABLE "StudySurvey";
ALTER TABLE "new_StudySurvey" RENAME TO "StudySurvey";
CREATE INDEX "StudySurvey_studentId_answeredOn_idx" ON "StudySurvey"("studentId", "answeredOn");
CREATE TABLE "new_SubjectAnalysis" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "analysisResultId" TEXT NOT NULL,
    "subject" TEXT NOT NULL,
    "priorityScore" INTEGER NOT NULL,
    "priorityRank" INTEGER NOT NULL,
    "latestScoreRate" REAL,
    "scoreRateDelta" REAL,
    "recentScoreRates" JSONB NOT NULL DEFAULT '[]',
    "selfEvaluationScore" INTEGER,
    "confidenceLevel" INTEGER,
    "recognitionLabel" TEXT NOT NULL DEFAULT '',
    "analysisComment" TEXT NOT NULL DEFAULT '',
    "priorityUnit" TEXT,
    "reasonsSnapshot" JSONB NOT NULL,
    CONSTRAINT "SubjectAnalysis_analysisResultId_fkey" FOREIGN KEY ("analysisResultId") REFERENCES "AnalysisResult" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO "new_SubjectAnalysis" ("analysisComment", "analysisResultId", "confidenceLevel", "id", "latestScoreRate", "priorityRank", "priorityScore", "priorityUnit", "reasonsSnapshot", "recentScoreRates", "recognitionLabel", "scoreRateDelta", "selfEvaluationScore", "subject") SELECT "analysisComment", "analysisResultId", "confidenceLevel", "id", "latestScoreRate", "priorityRank", "priorityScore", "priorityUnit", "reasonsSnapshot", "recentScoreRates", "recognitionLabel", "scoreRateDelta", "selfEvaluationScore", "subject" FROM "SubjectAnalysis";
DROP TABLE "SubjectAnalysis";
ALTER TABLE "new_SubjectAnalysis" RENAME TO "SubjectAnalysis";
CREATE INDEX "SubjectAnalysis_analysisResultId_idx" ON "SubjectAnalysis"("analysisResultId");
CREATE UNIQUE INDEX "SubjectAnalysis_analysisResultId_subject_key" ON "SubjectAnalysis"("analysisResultId", "subject");
CREATE UNIQUE INDEX "SubjectAnalysis_analysisResultId_priorityRank_key" ON "SubjectAnalysis"("analysisResultId", "priorityRank");
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;

-- CreateIndex
CREATE INDEX "UploadedFile_studentId_academicTestId_uploadedAt_idx" ON "UploadedFile"("studentId", "academicTestId", "uploadedAt");

-- CreateIndex
CREATE INDEX "UploadedFile_processingStatus_confirmationStatus_idx" ON "UploadedFile"("processingStatus", "confirmationStatus");

-- CreateIndex
CREATE UNIQUE INDEX "UploadedFile_studentId_academicTestId_fileHash_key" ON "UploadedFile"("studentId", "academicTestId", "fileHash");

-- CreateIndex
CREATE INDEX "OcrJob_uploadedFileId_createdAt_idx" ON "OcrJob"("uploadedFileId", "createdAt");

-- CreateIndex
CREATE INDEX "OcrJob_status_idx" ON "OcrJob"("status");

-- CreateIndex
CREATE INDEX "OcrPageResult_ocrJobId_idx" ON "OcrPageResult"("ocrJobId");

-- CreateIndex
CREATE UNIQUE INDEX "OcrPageResult_ocrJobId_pageNumber_key" ON "OcrPageResult"("ocrJobId", "pageNumber");

-- CreateIndex
CREATE INDEX "OcrExtractedItem_ocrJobId_pageNumber_idx" ON "OcrExtractedItem"("ocrJobId", "pageNumber");

-- CreateIndex
CREATE INDEX "OcrExtractedItem_reviewStatus_idx" ON "OcrExtractedItem"("reviewStatus");

-- CreateIndex
CREATE INDEX "ImportSession_studentId_academicTestId_startedAt_idx" ON "ImportSession"("studentId", "academicTestId", "startedAt");

-- CreateIndex
CREATE INDEX "ImportSession_status_idx" ON "ImportSession"("status");

-- CreateIndex
CREATE INDEX "ImportCandidateQuestion_importSessionId_subject_majorQuestionNumber_minorQuestionNumber_idx" ON "ImportCandidateQuestion"("importSessionId", "subject", "majorQuestionNumber", "minorQuestionNumber");

-- CreateIndex
CREATE INDEX "ImportCandidateQuestion_reviewStatus_idx" ON "ImportCandidateQuestion"("reviewStatus");

-- CreateIndex
CREATE INDEX "AuditLog_studentId_createdAt_idx" ON "AuditLog"("studentId", "createdAt");

-- CreateIndex
CREATE INDEX "AuditLog_action_createdAt_idx" ON "AuditLog"("action", "createdAt");
