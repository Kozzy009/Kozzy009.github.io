-- CreateTable
CREATE TABLE "ManualAiImportSession" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "studentId" TEXT NOT NULL,
    "academicTestId" TEXT NOT NULL,
    "subject" TEXT NOT NULL,
    "grade" TEXT NOT NULL,
    "schemaVersion" TEXT NOT NULL,
    "studentAnonymousId" TEXT NOT NULL,
    "importToken" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'DRAFT',
    "selectedFileIds" JSONB NOT NULL DEFAULT '[]',
    "materialTypes" JSONB NOT NULL DEFAULT '[]',
    "generatedPrompt" TEXT NOT NULL,
    "rawJson" TEXT,
    "validationErrors" JSONB NOT NULL DEFAULT '[]',
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "resultReceivedAt" DATETIME,
    "confirmedAt" DATETIME,
    "importedAt" DATETIME,
    "cancelledAt" DATETIME,
    "confirmedBy" TEXT,
    CONSTRAINT "ManualAiImportSession_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES "Student" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "ManualAiImportSession_academicTestId_fkey" FOREIGN KEY ("academicTestId") REFERENCES "AcademicTest" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "ManualAiImportQuestion" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "sessionId" TEXT NOT NULL,
    "majorQuestionNumber" TEXT NOT NULL,
    "minorQuestionNumber" TEXT,
    "pageNumber" INTEGER NOT NULL,
    "questionText" TEXT NOT NULL,
    "hasVisual" BOOLEAN NOT NULL DEFAULT false,
    "visualType" TEXT,
    "field" TEXT NOT NULL,
    "unit" TEXT NOT NULL,
    "subUnit" TEXT,
    "questionType" TEXT NOT NULL,
    "difficulty" TEXT NOT NULL,
    "points" INTEGER,
    "studentAnswer" TEXT,
    "correctAnswer" TEXT,
    "judgment" TEXT NOT NULL,
    "isBlank" BOOLEAN NOT NULL DEFAULT false,
    "mistakeTypes" JSONB NOT NULL DEFAULT '[]',
    "requiredKnowledge" JSONB NOT NULL DEFAULT '[]',
    "solutionSummary" TEXT NOT NULL,
    "recommendedReview" TEXT NOT NULL,
    "confidence" INTEGER NOT NULL,
    "needsHumanReview" BOOLEAN NOT NULL DEFAULT false,
    "reviewReason" TEXT,
    "reviewStatus" TEXT NOT NULL DEFAULT 'UNREVIEWED',
    "correctedData" JSONB,
    "reviewedAt" DATETIME,
    "reviewedBy" TEXT,
    CONSTRAINT "ManualAiImportQuestion_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES "ManualAiImportSession" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "ManualAiImportSummary" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "sessionId" TEXT NOT NULL,
    "unitSummary" JSONB NOT NULL,
    "overallAnalysis" JSONB NOT NULL,
    "reviewStatus" TEXT NOT NULL DEFAULT 'UNREVIEWED',
    "correctedData" JSONB,
    "reviewedAt" DATETIME,
    "reviewedBy" TEXT,
    CONSTRAINT "ManualAiImportSummary_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES "ManualAiImportSession" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_AnalysisResult" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "studentId" TEXT NOT NULL,
    "academicTestId" TEXT,
    "previousAcademicTestId" TEXT,
    "studySurveyId" TEXT,
    "status" TEXT NOT NULL,
    "ruleVersion" TEXT NOT NULL,
    "inputSnapshot" JSONB NOT NULL,
    "summarySnapshot" JSONB NOT NULL DEFAULT '{}',
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "AnalysisResult_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES "Student" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "AnalysisResult_academicTestId_fkey" FOREIGN KEY ("academicTestId") REFERENCES "AcademicTest" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "AnalysisResult_previousAcademicTestId_fkey" FOREIGN KEY ("previousAcademicTestId") REFERENCES "AcademicTest" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "AnalysisResult_studySurveyId_fkey" FOREIGN KEY ("studySurveyId") REFERENCES "StudySurvey" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);
INSERT INTO "new_AnalysisResult" ("academicTestId", "createdAt", "id", "inputSnapshot", "previousAcademicTestId", "ruleVersion", "status", "studentId", "studySurveyId", "summarySnapshot") SELECT "academicTestId", "createdAt", "id", "inputSnapshot", "previousAcademicTestId", "ruleVersion", "status", "studentId", "studySurveyId", "summarySnapshot" FROM "AnalysisResult";
DROP TABLE "AnalysisResult";
ALTER TABLE "new_AnalysisResult" RENAME TO "AnalysisResult";
CREATE INDEX "AnalysisResult_studentId_createdAt_idx" ON "AnalysisResult"("studentId", "createdAt");
CREATE TABLE "new_AuditLog" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "studentId" TEXT,
    "action" TEXT NOT NULL,
    "entityType" TEXT NOT NULL,
    "entityId" TEXT,
    "actor" TEXT NOT NULL DEFAULT 'LOCAL_USER',
    "metadata" JSONB NOT NULL DEFAULT '{}',
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "AuditLog_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES "Student" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);
INSERT INTO "new_AuditLog" ("action", "actor", "createdAt", "entityId", "entityType", "id", "metadata", "studentId") SELECT "action", "actor", "createdAt", "entityId", "entityType", "id", "metadata", "studentId" FROM "AuditLog";
DROP TABLE "AuditLog";
ALTER TABLE "new_AuditLog" RENAME TO "AuditLog";
CREATE INDEX "AuditLog_studentId_createdAt_idx" ON "AuditLog"("studentId", "createdAt");
CREATE INDEX "AuditLog_action_createdAt_idx" ON "AuditLog"("action", "createdAt");
CREATE TABLE "new_ImportCandidateQuestion" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "importSessionId" TEXT NOT NULL,
    "subject" TEXT NOT NULL,
    "majorQuestionNumber" TEXT NOT NULL,
    "minorQuestionNumber" TEXT,
    "questionText" TEXT,
    "answerText" TEXT,
    "correctAnswer" TEXT,
    "score" INTEGER,
    "unit" TEXT,
    "field" TEXT,
    "questionType" TEXT,
    "difficulty" TEXT,
    "confidence" REAL,
    "pageNumber" INTEGER,
    "hasFigure" BOOLEAN NOT NULL DEFAULT false,
    "sourceFileIds" JSONB NOT NULL DEFAULT '[]',
    "matchStatus" TEXT NOT NULL DEFAULT 'MATCHED',
    "gradingStatus" TEXT NOT NULL DEFAULT 'NEEDS_REVIEW',
    "reviewStatus" TEXT NOT NULL DEFAULT 'UNREVIEWED',
    "correctionNotes" TEXT,
    "reviewedAt" DATETIME,
    "reviewedBy" TEXT,
    CONSTRAINT "ImportCandidateQuestion_importSessionId_fkey" FOREIGN KEY ("importSessionId") REFERENCES "ImportSession" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO "new_ImportCandidateQuestion" ("answerText", "confidence", "correctAnswer", "correctionNotes", "difficulty", "field", "gradingStatus", "hasFigure", "id", "importSessionId", "majorQuestionNumber", "matchStatus", "minorQuestionNumber", "pageNumber", "questionText", "questionType", "reviewStatus", "reviewedAt", "reviewedBy", "score", "sourceFileIds", "subject", "unit") SELECT "answerText", "confidence", "correctAnswer", "correctionNotes", "difficulty", "field", "gradingStatus", "hasFigure", "id", "importSessionId", "majorQuestionNumber", "matchStatus", "minorQuestionNumber", "pageNumber", "questionText", "questionType", "reviewStatus", "reviewedAt", "reviewedBy", "score", "sourceFileIds", "subject", "unit" FROM "ImportCandidateQuestion";
DROP TABLE "ImportCandidateQuestion";
ALTER TABLE "new_ImportCandidateQuestion" RENAME TO "ImportCandidateQuestion";
CREATE INDEX "ImportCandidateQuestion_importSessionId_subject_majorQuestionNumber_minorQuestionNumber_idx" ON "ImportCandidateQuestion"("importSessionId", "subject", "majorQuestionNumber", "minorQuestionNumber");
CREATE INDEX "ImportCandidateQuestion_reviewStatus_idx" ON "ImportCandidateQuestion"("reviewStatus");
CREATE TABLE "new_ProblemProfile" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "studentId" TEXT NOT NULL,
    "academicTestId" TEXT,
    "testName" TEXT NOT NULL,
    "attemptedOn" DATETIME NOT NULL,
    "subject" TEXT NOT NULL,
    "majorNumber" TEXT NOT NULL,
    "minorNumber" TEXT,
    "area" TEXT NOT NULL,
    "unit" TEXT NOT NULL,
    "questionFormat" TEXT NOT NULL,
    "difficulty" TEXT NOT NULL,
    "points" INTEGER NOT NULL,
    "studentAnswer" TEXT,
    "correctAnswer" TEXT,
    "isCorrect" BOOLEAN NOT NULL,
    "answerSeconds" INTEGER,
    "isUnanswered" BOOLEAN NOT NULL DEFAULT false,
    "mistakeTypes" JSONB NOT NULL DEFAULT '[]',
    "instructorComment" TEXT,
    "isReviewTarget" BOOLEAN NOT NULL DEFAULT false,
    "questionText" TEXT,
    "sourceUploadedFileId" TEXT,
    "importCandidateId" TEXT,
    "manualAiImportQuestionId" TEXT,
    "reviewedBy" TEXT,
    "reviewedAt" DATETIME,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "ProblemProfile_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES "Student" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "ProblemProfile_academicTestId_fkey" FOREIGN KEY ("academicTestId") REFERENCES "AcademicTest" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "ProblemProfile_sourceUploadedFileId_fkey" FOREIGN KEY ("sourceUploadedFileId") REFERENCES "UploadedFile" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "ProblemProfile_importCandidateId_fkey" FOREIGN KEY ("importCandidateId") REFERENCES "ImportCandidateQuestion" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "ProblemProfile_manualAiImportQuestionId_fkey" FOREIGN KEY ("manualAiImportQuestionId") REFERENCES "ManualAiImportQuestion" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);
INSERT INTO "new_ProblemProfile" ("academicTestId", "answerSeconds", "area", "attemptedOn", "correctAnswer", "createdAt", "difficulty", "id", "importCandidateId", "instructorComment", "isCorrect", "isReviewTarget", "isUnanswered", "majorNumber", "minorNumber", "mistakeTypes", "points", "questionFormat", "questionText", "reviewedAt", "reviewedBy", "sourceUploadedFileId", "studentAnswer", "studentId", "subject", "testName", "unit", "updatedAt") SELECT "academicTestId", "answerSeconds", "area", "attemptedOn", "correctAnswer", "createdAt", "difficulty", "id", "importCandidateId", "instructorComment", "isCorrect", "isReviewTarget", "isUnanswered", "majorNumber", "minorNumber", "mistakeTypes", "points", "questionFormat", "questionText", "reviewedAt", "reviewedBy", "sourceUploadedFileId", "studentAnswer", "studentId", "subject", "testName", "unit", "updatedAt" FROM "ProblemProfile";
DROP TABLE "ProblemProfile";
ALTER TABLE "new_ProblemProfile" RENAME TO "ProblemProfile";
CREATE UNIQUE INDEX "ProblemProfile_importCandidateId_key" ON "ProblemProfile"("importCandidateId");
CREATE UNIQUE INDEX "ProblemProfile_manualAiImportQuestionId_key" ON "ProblemProfile"("manualAiImportQuestionId");
CREATE INDEX "ProblemProfile_studentId_attemptedOn_idx" ON "ProblemProfile"("studentId", "attemptedOn");
CREATE INDEX "ProblemProfile_studentId_subject_unit_idx" ON "ProblemProfile"("studentId", "subject", "unit");
CREATE TABLE "new_StudyRecord" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "studyPlanItemId" TEXT NOT NULL,
    "completed" BOOLEAN NOT NULL DEFAULT false,
    "actualMinutes" INTEGER NOT NULL DEFAULT 0,
    "attemptedCount" INTEGER NOT NULL DEFAULT 0,
    "correctCount" INTEGER NOT NULL DEFAULT 0,
    "difficultyRating" INTEGER,
    "concentrationRating" INTEGER,
    "retryPreference" BOOLEAN,
    "mistakeTypes" JSONB NOT NULL DEFAULT '[]',
    "studentComment" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "StudyRecord_studyPlanItemId_fkey" FOREIGN KEY ("studyPlanItemId") REFERENCES "StudyPlanItem" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO "new_StudyRecord" ("actualMinutes", "attemptedCount", "completed", "concentrationRating", "correctCount", "createdAt", "difficultyRating", "id", "mistakeTypes", "retryPreference", "studentComment", "studyPlanItemId", "updatedAt") SELECT "actualMinutes", "attemptedCount", "completed", "concentrationRating", "correctCount", "createdAt", "difficultyRating", "id", "mistakeTypes", "retryPreference", "studentComment", "studyPlanItemId", "updatedAt" FROM "StudyRecord";
DROP TABLE "StudyRecord";
ALTER TABLE "new_StudyRecord" RENAME TO "StudyRecord";
CREATE UNIQUE INDEX "StudyRecord_studyPlanItemId_key" ON "StudyRecord"("studyPlanItemId");
CREATE INDEX "StudyRecord_studyPlanItemId_idx" ON "StudyRecord"("studyPlanItemId");
CREATE TABLE "new_StudySurvey" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "studentId" TEXT NOT NULL,
    "answeredOn" DATETIME NOT NULL,
    "weekdayAvailableMinutes" INTEGER NOT NULL,
    "weekendAvailableMinutes" INTEGER NOT NULL,
    "currentWeekdayMinutes" INTEGER NOT NULL DEFAULT 0,
    "currentWeekendMinutes" INTEGER NOT NULL DEFAULT 0,
    "concentrationMinutes" INTEGER NOT NULL DEFAULT 15,
    "availableDaysPerWeek" INTEGER NOT NULL DEFAULT 3,
    "availableDays" JSONB NOT NULL DEFAULT '[]',
    "busyDays" JSONB NOT NULL DEFAULT '[]',
    "preferredTimeOfDay" TEXT NOT NULL DEFAULT 'EVENING',
    "motivationScore" REAL NOT NULL DEFAULT 3,
    "confidenceScore" REAL NOT NULL DEFAULT 3,
    "studyHabitScore" REAL NOT NULL DEFAULT 3,
    "reviewHabitScore" REAL NOT NULL DEFAULT 3,
    "concentrationScore" REAL NOT NULL DEFAULT 3,
    "environmentScore" REAL NOT NULL DEFAULT 3,
    "motivationAnswers" JSONB NOT NULL DEFAULT '{}',
    "confidenceAnswers" JSONB NOT NULL DEFAULT '{}',
    "studyMethodAnswers" JSONB NOT NULL DEFAULT '{}',
    "concentrationAnswers" JSONB NOT NULL DEFAULT '{}',
    "concern" TEXT,
    "recentAchievement" TEXT,
    "anxiousSubjectsUnits" TEXT,
    "preferredStudyMethod" TEXT,
    "familyConsideration" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "StudySurvey_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES "Student" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO "new_StudySurvey" ("answeredOn", "anxiousSubjectsUnits", "availableDays", "availableDaysPerWeek", "busyDays", "concentrationAnswers", "concentrationMinutes", "concentrationScore", "concern", "confidenceAnswers", "confidenceScore", "createdAt", "currentWeekdayMinutes", "currentWeekendMinutes", "environmentScore", "familyConsideration", "id", "motivationAnswers", "motivationScore", "preferredStudyMethod", "preferredTimeOfDay", "recentAchievement", "reviewHabitScore", "studentId", "studyHabitScore", "studyMethodAnswers", "updatedAt", "weekdayAvailableMinutes", "weekendAvailableMinutes") SELECT "answeredOn", "anxiousSubjectsUnits", "availableDays", "availableDaysPerWeek", "busyDays", "concentrationAnswers", "concentrationMinutes", "concentrationScore", "concern", "confidenceAnswers", "confidenceScore", "createdAt", "currentWeekdayMinutes", "currentWeekendMinutes", "environmentScore", "familyConsideration", "id", "motivationAnswers", "motivationScore", "preferredStudyMethod", "preferredTimeOfDay", "recentAchievement", "reviewHabitScore", "studentId", "studyHabitScore", "studyMethodAnswers", "updatedAt", "weekdayAvailableMinutes", "weekendAvailableMinutes" FROM "StudySurvey";
DROP TABLE "StudySurvey";
ALTER TABLE "new_StudySurvey" RENAME TO "StudySurvey";
CREATE INDEX "StudySurvey_studentId_answeredOn_idx" ON "StudySurvey"("studentId", "answeredOn");
CREATE TABLE "new_SubjectAnalysis" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "analysisResultId" TEXT NOT NULL,
    "subject" TEXT NOT NULL,
    "priorityScore" INTEGER NOT NULL,
    "priorityRank" INTEGER NOT NULL,
    "latestScoreRate" REAL,
    "scoreRateDelta" REAL,
    "recentScoreRates" JSONB NOT NULL DEFAULT '[]',
    "selfEvaluationScore" INTEGER,
    "confidenceLevel" INTEGER,
    "recognitionLabel" TEXT NOT NULL DEFAULT '',
    "analysisComment" TEXT NOT NULL DEFAULT '',
    "priorityUnit" TEXT,
    "reasonsSnapshot" JSONB NOT NULL,
    CONSTRAINT "SubjectAnalysis_analysisResultId_fkey" FOREIGN KEY ("analysisResultId") REFERENCES "AnalysisResult" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO "new_SubjectAnalysis" ("analysisComment", "analysisResultId", "confidenceLevel", "id", "latestScoreRate", "priorityRank", "priorityScore", "priorityUnit", "reasonsSnapshot", "recentScoreRates", "recognitionLabel", "scoreRateDelta", "selfEvaluationScore", "subject") SELECT "analysisComment", "analysisResultId", "confidenceLevel", "id", "latestScoreRate", "priorityRank", "priorityScore", "priorityUnit", "reasonsSnapshot", "recentScoreRates", "recognitionLabel", "scoreRateDelta", "selfEvaluationScore", "subject" FROM "SubjectAnalysis";
DROP TABLE "SubjectAnalysis";
ALTER TABLE "new_SubjectAnalysis" RENAME TO "SubjectAnalysis";
CREATE INDEX "SubjectAnalysis_analysisResultId_idx" ON "SubjectAnalysis"("analysisResultId");
CREATE UNIQUE INDEX "SubjectAnalysis_analysisResultId_subject_key" ON "SubjectAnalysis"("analysisResultId", "subject");
CREATE UNIQUE INDEX "SubjectAnalysis_analysisResultId_priorityRank_key" ON "SubjectAnalysis"("analysisResultId", "priorityRank");
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;

-- CreateIndex
CREATE UNIQUE INDEX "ManualAiImportSession_importToken_key" ON "ManualAiImportSession"("importToken");

-- CreateIndex
CREATE INDEX "ManualAiImportSession_studentId_academicTestId_createdAt_idx" ON "ManualAiImportSession"("studentId", "academicTestId", "createdAt");

-- CreateIndex
CREATE INDEX "ManualAiImportSession_status_idx" ON "ManualAiImportSession"("status");

-- CreateIndex
CREATE INDEX "ManualAiImportQuestion_sessionId_reviewStatus_idx" ON "ManualAiImportQuestion"("sessionId", "reviewStatus");

-- CreateIndex
CREATE UNIQUE INDEX "ManualAiImportQuestion_sessionId_majorQuestionNumber_minorQuestionNumber_key" ON "ManualAiImportQuestion"("sessionId", "majorQuestionNumber", "minorQuestionNumber");

-- CreateIndex
CREATE UNIQUE INDEX "ManualAiImportSummary_sessionId_key" ON "ManualAiImportSummary"("sessionId");
