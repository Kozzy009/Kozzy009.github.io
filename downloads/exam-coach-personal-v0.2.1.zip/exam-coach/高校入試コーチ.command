#!/bin/bash
cd "$(dirname "$0")" || exit 1
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js 24以上をインストールしてから、もう一度開いてください。"
else
  node scripts/local-app.mjs
fi
read -r -p "Enterキーで閉じます。" _
