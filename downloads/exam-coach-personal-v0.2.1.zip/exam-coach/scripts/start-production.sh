#!/bin/bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
# shellcheck source=common.sh
source "$SCRIPT_DIR/common.sh"
load_production_env
cd "$PROJECT_DIR"
START_LOG="$LOG_DIR/app-$(date '+%Y%m%d').log"

if [[ -f "$PID_FILE" ]]; then
  EXISTING_PID="$(cat "$PID_FILE" 2>/dev/null || true)"
  if is_app_process "$EXISTING_PID"; then
    echo "アプリは既に起動しています。ブラウザを開きます。"
    [[ "${IWAKI_SKIP_BROWSER:-0}" == "1" ]] || open "$APP_BASE_URL"
    exit 0
  fi
  rm -f "$PID_FILE"
fi
RUNNING_PID="$(find_app_pid_on_port || true)"
if [[ -n "$RUNNING_PID" ]]; then
  printf '%s\n' "$RUNNING_PID" > "$PID_FILE"
  chmod 600 "$PID_FILE"
  echo "アプリは既に起動しています。ブラウザを開きます。"
  [[ "${IWAKI_SKIP_BROWSER:-0}" == "1" ]] || open "$APP_BASE_URL"
  exit 0
fi

[[ -f "$PROJECT_DIR/.next/BUILD_ID" ]] || { echo "production buildがありません。先に初回設定を実行してください。" >&2; exit 1; }
[[ "${APP_ENV:-}" == "production" ]] || { echo "APP_ENVがproductionではないため起動を中止しました。" >&2; exit 1; }
if [[ "${ENABLE_LAN_ACCESS:-false}" == "true" ]]; then
  echo "認証機能が未実装のためLAN公開は有効化できません。ENABLE_LAN_ACCESS=falseに戻してください。" >&2
  exit 1
fi

echo "いわき高校入試コーチを起動しています…"
nohup "$PROJECT_DIR/node_modules/.bin/next" start --hostname 127.0.0.1 --port 3000 >> "$START_LOG" 2>&1 &
APP_PID=$!
printf '%s\n' "$APP_PID" > "$PID_FILE"
chmod 600 "$PID_FILE"

for _ in {1..40}; do
  if kill -0 "$APP_PID" 2>/dev/null && is_app_process "$APP_PID" && curl -fsS "$APP_BASE_URL/api/system/health" >/dev/null 2>&1; then
    log_event "START" "アプリ起動成功"
    echo "起動しました: $APP_BASE_URL"
    [[ "${IWAKI_SKIP_BROWSER:-0}" == "1" ]] || open "$APP_BASE_URL"
    exit 0
  fi
  if ! kill -0 "$APP_PID" 2>/dev/null; then break; fi
  sleep 0.5
done

rm -f "$PID_FILE"
log_event "START_FAILED" "アプリ起動失敗"
echo "起動に失敗しました。ログを確認してください: $START_LOG" >&2
tail -n 20 "$START_LOG" >&2 || true
exit 1
