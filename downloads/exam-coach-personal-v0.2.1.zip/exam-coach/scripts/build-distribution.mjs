import { readFile, readdir, lstat, mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { crc32 } from 'node:zlib';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const fixed = ['package.json', 'package-lock.json', 'prisma.config.ts', 'next.config.ts', 'tsconfig.json', 'postcss.config.mjs', 'eslint.config.mjs', 'vitest.config.ts', '.env.example', '.gitignore', 'AGENTS.md', 'README.md', '高校入試コーチ.command', '高校入試コーチ.cmd'];
const trees = { src: /\.(ts|tsx|css|svg)$/, 'prisma/migrations': /\.(sql|toml)$/, prompts: /\.md$/, schemas: /\.json$/, docs: /\.md$/, tests: /\.test\.(ts|mjs)$/ };
const scripts = ['scripts/common.sh', 'scripts/setup-production.sh', 'scripts/start-production.sh', 'scripts/stop-production.sh', 'scripts/backup.sh', 'scripts/restore.sh', 'scripts/start-lan.mjs', 'prisma/seed.ts', 'scripts/local-app.mjs', 'scripts/local-data.mjs', 'scripts/local-port.mjs', 'scripts/build-distribution.mjs'];

async function collect(directory, pattern) {
  const files = [];
  for (const item of await readdir(path.join(root, directory), { withFileTypes: true })) {
    if (item.name.startsWith('.') || item.name === 'generated') continue;
    const name = `${directory}/${item.name}`;
    if (item.isSymbolicLink()) throw new Error('配布対象にシンボリックリンクがあります。');
    if (item.isDirectory()) files.push(...await collect(name, pattern));
    else if (pattern.test(item.name)) files.push(name);
  }
  return files;
}

// 明示したプログラム・設計・テストだけを収録する。DB、環境設定、ログ、作業成果物は走査しない。
const files = [...fixed, ...scripts, 'prisma/schema.prisma'];
for (const [directory, pattern] of Object.entries(trees)) files.push(...await collect(directory, pattern));
const records = [], central = [];
let offset = 0;
for (const file of [...new Set(files)].sort()) {
  const info = await lstat(path.join(root, file));
  if (!info.isFile() || info.isSymbolicLink()) throw new Error('通常ファイル以外は配布できません。');
  const data = await readFile(path.join(root, file));
  const name = Buffer.from(`exam-coach/${file}`);
  const checksum = crc32(data);
  const local = Buffer.alloc(30);
  local.writeUInt32LE(0x04034b50); local.writeUInt16LE(20, 4); local.writeUInt16LE(0x800, 6);
  local.writeUInt16LE(33, 12); local.writeUInt32LE(checksum, 14);
  local.writeUInt32LE(data.length, 18); local.writeUInt32LE(data.length, 22); local.writeUInt16LE(name.length, 26);
  const header = Buffer.alloc(46);
  header.writeUInt32LE(0x02014b50); header.writeUInt16LE(0x314, 4); header.writeUInt16LE(20, 6); header.writeUInt16LE(0x800, 8);
  header.writeUInt16LE(33, 14); header.writeUInt32LE(checksum, 16); header.writeUInt32LE(data.length, 20); header.writeUInt32LE(data.length, 24);
  header.writeUInt16LE(name.length, 28); header.writeUInt32LE(((file.endsWith('.command') ? 0o100755 : 0o100644) << 16) >>> 0, 38); header.writeUInt32LE(offset, 42);
  records.push(local, name, data); central.push(header, name); offset += local.length + name.length + data.length;
}
const directory = Buffer.concat(central), end = Buffer.alloc(22);
end.writeUInt32LE(0x06054b50); end.writeUInt16LE(central.length / 2, 8); end.writeUInt16LE(central.length / 2, 10);
end.writeUInt32LE(directory.length, 12); end.writeUInt32LE(offset, 16);
await mkdir(path.join(root, 'dist'), { recursive: true });
await writeFile(path.join(root, 'dist/exam-coach-personal.zip'), Buffer.concat([...records, directory, end]));
console.log(`配布ZIPを作成しました: dist/exam-coach-personal.zip (${central.length / 2} files)`);
