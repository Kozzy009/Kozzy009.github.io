import { createServer } from 'node:net';

// 空き確認も起動も同じIPv4ループバックに限定する。
export function probePort(port) {
  return new Promise((resolve, reject) => {
    const server = createServer();
    server.once('error', error => {
      if (error.code === 'EADDRINUSE') resolve(null);
      else reject(new Error('ローカル接続の準備ができません。OSのネットワーク権限を確認してください。'));
    });
    server.listen({ host: '127.0.0.1', port, exclusive: true }, () => {
      const selected = server.address().port;
      server.close(error => error ? reject(error) : resolve(selected));
    });
  });
}

export async function selectPort(preferred = 3000, probe = probePort) {
  if (!Number.isInteger(preferred) || preferred < 1024 || preferred > 65535) {
    throw new Error('ポートは1024〜65535の整数で指定してください。');
  }
  for (let port = preferred; port <= Math.min(preferred + 9, 65535); port++) {
    const selected = await probe(port);
    if (selected !== null) return selected;
  }
  // 連続した10ポートが使用中ならOSに空きポートを選ばせる。
  const selected = await probe(0);
  if (selected === null) throw new Error('空きポートを確保できませんでした。時間をおいて再度起動してください。');
  return selected;
}
