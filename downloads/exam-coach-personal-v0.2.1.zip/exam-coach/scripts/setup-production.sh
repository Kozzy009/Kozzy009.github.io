#!/bin/bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
# shellcheck source=common.sh
source "$SCRIPT_DIR/common.sh"
trap 'echo "初回設定に失敗しました。直前の表示を確認してください。" >&2; [[ -n "${LOG_DIR:-}" ]] && log_event "SETUP_FAILED" "初回設定失敗" || true; pause_if_interactive' ERR

cd "$PROJECT_DIR"
echo "いわき高校入試コーチの初回設定を開始します。"
command -v node >/dev/null 2>&1 || { echo "Node.jsが見つかりません。Node.js 24以上をインストールしてください。" >&2; exit 1; }
NODE_MAJOR="$(node -p 'process.versions.node.split(".")[0]')"
[[ "$NODE_MAJOR" -ge 24 ]] || { echo "Node.js 24以上が必要です。現在: $(node -v)" >&2; exit 1; }
command -v npm >/dev/null 2>&1 || { echo "npmが見つかりません。" >&2; exit 1; }

DATA_ROOT_DEFAULT="$HOME/Documents/iwaki-exam-coach-data"
mkdir -p "$DATA_ROOT_DEFAULT"/{database,uploads,backups,exports,logs,runtime}
chmod 700 "$DATA_ROOT_DEFAULT" "$DATA_ROOT_DEFAULT"/* 2>/dev/null || true

if [[ ! -f "$PRODUCTION_ENV_FILE" ]]; then
  cat > "$PRODUCTION_ENV_FILE" <<EOF
DATABASE_URL="file:$DATA_ROOT_DEFAULT/database/app.db"
UPLOAD_STORAGE_PATH="$DATA_ROOT_DEFAULT/uploads"
BACKUP_STORAGE_PATH="$DATA_ROOT_DEFAULT/backups"
APP_BASE_URL="http://localhost:3000"
APP_ENV="production"
MAX_UPLOAD_SIZE_MB="20"
ENABLE_DEMO_DATA="false"
ENABLE_DEV_TOOLS="false"
ENABLE_LAN_ACCESS="false"
BACKUP_ON_SHUTDOWN="true"
PRIVACY_POLICY_CONFIRMED="false"
EOF
  chmod 600 "$PRODUCTION_ENV_FILE"
fi

load_production_env
DB_PATH="$(database_path)"
mkdir -p "$(dirname "$DB_PATH")" "$UPLOAD_STORAGE_PATH" "$BACKUP_STORAGE_PATH"
if [[ -f "$DB_PATH" ]]; then
  echo "既存データベースを先にバックアップします。"
  IWAKI_NO_PAUSE=1 "$SCRIPT_DIR/backup.sh" --setup
else
  # Prisma 7のSQLite接続確認は空ファイルがないと失敗するため、安全な権限で先に作成する。
  (umask 077; : > "$DB_PATH")
fi

if [[ ! -d node_modules ]]; then npm ci; else npm ls --depth=0 >/dev/null; fi
echo "Prisma Clientを生成します。"
npm run db:generate
echo "本番用マイグレーションを安全に適用します。"
npm run db:migrate:deploy
log_event "MIGRATION" "本番マイグレーション適用成功"
echo "production buildを作成します。"
npm run build
chmod +x "$PROJECT_DIR"/*.command "$SCRIPT_DIR"/*.sh 2>/dev/null || true
log_event "SETUP" "初回設定成功"
echo
echo "初回設定が完了しました。デモデータは投入していません。"
echo "次は『いわき高校入試コーチを起動.command』をダブルクリックしてください。"
pause_if_interactive
