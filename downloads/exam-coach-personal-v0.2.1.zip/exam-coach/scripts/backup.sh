#!/bin/bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
# shellcheck source=common.sh
source "$SCRIPT_DIR/common.sh"
load_production_env
DB_PATH="$(database_path)"
STAMP="$(timestamp)"
BACKUP_DIR="$BACKUP_STORAGE_PATH/iwaki-exam-coach-backup-$STAMP"
TMP_DIR="$BACKUP_STORAGE_PATH/.creating-$STAMP"
trap 'rm -rf "$TMP_DIR" 2>/dev/null || true; log_event "BACKUP_FAILED" "バックアップ失敗"; echo "バックアップに失敗しました。" >&2' ERR

command -v sqlite3 >/dev/null 2>&1 || { echo "sqlite3が見つかりません。Mac標準のsqlite3を確認してください。" >&2; exit 1; }
mkdir -p "$TMP_DIR"/{database,uploads,exports,config}
if [[ -f "$DB_PATH" ]]; then
  INTEGRITY="$(sqlite3 "$DB_PATH" 'PRAGMA integrity_check;' 2>&1)"
  [[ "$INTEGRITY" == "ok" ]] || { echo "データベース整合性確認に失敗しました: $INTEGRITY" >&2; exit 1; }
  sqlite3 "$DB_PATH" ".timeout 5000" ".backup '$TMP_DIR/database/app.db'"
else
  echo "データベースはまだ作成されていません。設定とファイルのみ保存します。"
fi
[[ -d "$UPLOAD_STORAGE_PATH" ]] && cp -R "$UPLOAD_STORAGE_PATH"/. "$TMP_DIR/uploads"/ 2>/dev/null || true
[[ -d "$EXPORT_DIR" ]] && cp -R "$EXPORT_DIR"/. "$TMP_DIR/exports"/ 2>/dev/null || true
cat > "$TMP_DIR/config/public-settings.env" <<EOF
APP_BASE_URL=${APP_BASE_URL}
APP_ENV=${APP_ENV}
MAX_UPLOAD_SIZE_MB=${MAX_UPLOAD_SIZE_MB:-20}
ENABLE_DEMO_DATA=${ENABLE_DEMO_DATA:-false}
ENABLE_DEV_TOOLS=${ENABLE_DEV_TOOLS:-false}
ENABLE_LAN_ACCESS=${ENABLE_LAN_ACCESS:-false}
BACKUP_ON_SHUTDOWN=${BACKUP_ON_SHUTDOWN:-false}
EOF
DB_SIZE="$(du -h "$TMP_DIR/database/app.db" 2>/dev/null | awk '{print $1}' || echo '0B')"
FILE_COUNT="$(find "$TMP_DIR" -type f | wc -l | tr -d ' ')"
cat > "$TMP_DIR/manifest.txt" <<EOF
backupVersion=1
createdAt=$(date '+%Y-%m-%d %H:%M:%S %z')
databaseSize=$DB_SIZE
fileCount=$FILE_COUNT
result=SUCCESS
EOF
mv "$TMP_DIR" "$BACKUP_DIR"
log_event "BACKUP" "バックアップ成功"
echo "バックアップ成功"
echo "保存先: $BACKUP_DIR"
echo "データベースサイズ: $DB_SIZE"
echo "ファイル数: $FILE_COUNT"
echo "日時: $(date '+%Y-%m-%d %H:%M:%S')"
OLD_COUNT="$(find "$BACKUP_STORAGE_PATH" -maxdepth 1 -type d -name 'iwaki-exam-coach-backup-*' | sort -r | tail -n +31 | wc -l | tr -d ' ')"
if [[ "$OLD_COUNT" -gt 0 ]]; then echo "30世代を超えた削除候補が${OLD_COUNT}件あります。自動削除はしていません。"; fi
