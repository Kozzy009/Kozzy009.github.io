#!/bin/bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
# shellcheck source=common.sh
source "$SCRIPT_DIR/common.sh"
load_production_env

if [[ ! -f "$PID_FILE" ]]; then echo "アプリは停止しています。"; exit 0; fi
APP_PID="$(cat "$PID_FILE" 2>/dev/null || true)"
if ! is_app_process "$APP_PID"; then
  echo "保存されたPIDは本アプリのプロセスではありません。安全のため終了操作を中止します。" >&2
  exit 1
fi

if [[ "${BACKUP_ON_SHUTDOWN:-false}" == "true" ]]; then
  echo "終了前バックアップを作成します。"
  if ! IWAKI_NO_PAUSE=1 "$SCRIPT_DIR/backup.sh" --shutdown; then
    echo "バックアップに失敗しました。"
    if [[ -t 0 ]]; then
      read -r -p "バックアップなしで終了しますか？ [y/N]: " answer
      [[ "$answer" =~ ^[Yy]$ ]] || exit 1
    else
      echo "非対話実行のため終了を中止しました。" >&2
      exit 1
    fi
  fi
fi

kill -TERM "$APP_PID"
for _ in {1..20}; do kill -0 "$APP_PID" 2>/dev/null || break; sleep 0.5; done
if kill -0 "$APP_PID" 2>/dev/null; then echo "正常終了を確認できませんでした。PIDファイルを保持します。" >&2; exit 1; fi
rm -f "$PID_FILE"
log_event "STOP" "アプリ正常終了"
echo "いわき高校入試コーチを終了しました。"
