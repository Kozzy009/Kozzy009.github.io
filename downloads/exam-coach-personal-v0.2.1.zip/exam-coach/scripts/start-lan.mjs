if (process.env.ENABLE_LAN_ACCESS !== "true") {
  console.error("LANアクセスは無効です。認証未実装のため有効化しないでください。");
  process.exit(1);
}
console.error("認証機能が未実装のため、LAN公開を安全に開始できません。");
process.exit(1);
