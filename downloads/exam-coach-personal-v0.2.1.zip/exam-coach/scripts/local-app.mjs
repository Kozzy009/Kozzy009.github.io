import { spawn } from 'node:child_process';
import { existsSync } from 'node:fs';
import { readdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createInterface } from 'node:readline/promises';
import { once } from 'node:events';
import { selectPort } from './local-port.mjs';
import { defaultDataRoot, initialize, acquireLock, createBackup, restoreBackup, validateBackup } from './local-data.mjs';

const project = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
if (process.env.EXAM_COACH_DATA_DIR && !path.isAbsolute(process.env.EXAM_COACH_DATA_DIR)) throw new Error('保存先は専用フォルダの絶対パスで指定してください。');
const root = path.resolve(process.env.EXAM_COACH_DATA_DIR || defaultDataRoot());
const preferredPort = Number(process.env.EXAM_COACH_PORT || '3000');
if (!Number.isInteger(preferredPort) || preferredPort < 1024 || preferredPort > 65535) throw new Error('ポートは1024〜65535の整数で指定してください。');

if (root === path.parse(root).root || root === project || root.startsWith(project + path.sep)) throw new Error('保存先はアプリの外の専用フォルダにしてください。');
process.umask(0o077);
const env = { ...process.env, DATABASE_URL: `file:${path.join(root, 'current', 'app.db').replaceAll('\\', '/')}`,
  UPLOAD_STORAGE_PATH: path.join(root, 'current', 'uploads'), BACKUP_STORAGE_PATH: path.join(root, 'backups'),
  EXAM_COACH_DATA_DIR: root, APP_BASE_URL: `http://127.0.0.1:${preferredPort}`, APP_ENV: 'production', NEXT_TELEMETRY_DISABLED: '1', CHECKPOINT_DISABLE: '1',
  ENABLE_LAN_ACCESS: 'false', ENABLE_DEMO_DATA: 'false', ENABLE_DEV_TOOLS: 'false' };
const rl = createInterface({ input: process.stdin, output: process.stdout });
const ask = (message) => rl.question(message);

async function runNode(script, args = []) {
  const child = spawn(process.execPath, [path.resolve(project, script), ...args], { cwd: project, env, stdio: 'inherit' });
  const [code] = await once(child, 'exit');
  if (code !== 0) throw new Error('設定処理に失敗しました。データを削除せず、表示を確認してください。');
}

async function setup() {
  if (existsSync(path.join(project, '.env.production.local'))) throw new Error('旧Mac版の設定があるフォルダです。新しい配布物を別フォルダに展開してください。既存データは変更していません。');
  if (existsSync(path.join(root, 'current', 'app.db'))) console.log(`更新前バックアップ: ${await createBackup(root)}`);
  else await writeFile(path.join(root, 'current', 'app.db'), '', { flag: 'wx', mode: 0o600 });
  console.log('初回設定・更新にはインターネット接続が必要です。依存パッケージを準備します。');
  // npm.cmdをシェル経由で組み立てず、Node同梱のnpm CLIを直接呼ぶ。
  const candidates = [process.env.npm_execpath, path.join(path.dirname(process.execPath), 'node_modules/npm/bin/npm-cli.js'),
    path.resolve(path.dirname(process.execPath), '../lib/node_modules/npm/bin/npm-cli.js')].filter(Boolean);
  const npm = candidates.find(candidate => existsSync(candidate));
  if (!npm) throw new Error('npmが見つかりません。Node.js公式インストーラーでNode.jsとnpmを導入してください。');
  await runNode(npm, ['ci']);
  await runNode('node_modules/prisma/build/index.js', ['migrate', 'deploy']);
  await runNode('node_modules/next/dist/bin/next', ['build']);
  console.log('設定が完了しました。デモデータは入れていません。');
}

function openBrowser(url) {
  const child = process.platform === 'win32' ? spawn('rundll32', ['url.dll,FileProtocolHandler', url], { stdio: 'ignore' })
    : spawn(process.platform === 'darwin' ? 'open' : 'xdg-open', [url], { stdio: 'ignore' });
  child.on('error', () => console.log(`ブラウザで ${url} を開いてください。`));
  child.unref();
}

async function start() {
  if (!existsSync(path.join(project, '.next/BUILD_ID')) || !existsSync(path.join(root, 'current/app.db'))) await setup();
  // 空き確認から起動までに他プロセスが取得した場合も、改めて選び直す。
  for (let attempt = 0; attempt < 5; attempt++) {
    const port = await selectPort(preferredPort);
    if (port !== preferredPort) console.log(`ポート${preferredPort}は使用中のため、空きポート${port}を使用します。`);
    if (await launch(port)) return;
    console.log('選択したポートが使用されたため、空きポートを選び直します。');
  }
  throw new Error('起動用ポートが続けて競合しました。時間をおいて再度起動してください。');
}

async function launch(port) {
  const appUrl = `http://127.0.0.1:${port}`;
  const launchEnv = { ...env, APP_BASE_URL: appUrl };
  const child = spawn(process.execPath, [path.join(project, 'node_modules/next/dist/bin/next'), 'start', '--hostname', '127.0.0.1', '--port', String(port)], { cwd: project, env: launchEnv, stdio: ['ignore', 'ignore', 'pipe'] });
  let portInUse = false, diagnosticTail = '', finished = false;
  // 生ログは表示・保存せず、再試行の判定に必要なエラーコードだけを見る。
  child.stderr.on('data', chunk => {
    const diagnostic = diagnosticTail + chunk.toString();
    if (diagnostic.includes('EADDRINUSE')) portInUse = true;
    diagnosticTail = diagnostic.slice(-8);
  });
  const exited = new Promise(resolve => {
    child.once('close', code => { finished = true; resolve(code); });
    child.once('error', () => { finished = true; resolve(null); });
  });
  let stopping = false;
  const stop = () => { stopping = true; child.kill('SIGTERM'); };
  process.on('SIGINT', stop); process.on('SIGTERM', stop);
  try {
    let ready = false;
    for (let attempt = 0; attempt < 100 && child.exitCode === null && child.signalCode === null && !finished && !stopping; attempt++) {
      await new Promise(resolve => setTimeout(resolve, 300));
      try {
        const response = await fetch(`${appUrl}/api/system/health`, { signal: AbortSignal.timeout(500) });
        const body = await response.json();
        if (response.ok && body.instanceId === env.EXAM_COACH_INSTANCE_ID) { ready = true; break; }
      } catch { /* 起動待ち */ }
    }
    if (!ready) {
      if (child.exitCode !== null || child.signalCode !== null) await exited;
      if (stopping) return true;
      if (portInUse) return false;
      throw new Error('起動を確認できませんでした。メニュー2「初回設定・更新」を実行してから再度起動してください。');
    }
    console.log(`起動しました: ${appUrl}\nこのウィンドウを残して利用してください。`);
    if (process.env.EXAM_COACH_SKIP_BROWSER !== '1') openBrowser(appUrl);
    await Promise.race([ask('終了するにはEnterを押してください。'), exited]);
  } finally {
    if (child.exitCode === null && child.signalCode === null) { stop(); await exited; }
    process.off('SIGINT', stop); process.off('SIGTERM', stop);
  }
  console.log(`終了時バックアップ: ${await createBackup(root)}`);
  return true;
}

async function restore() {
  const names = (await readdir(path.join(root, 'backups'))).filter(name => /^exam-coach-backup-[\w-]+$/.test(name)).sort().reverse();
  if (!names.length) throw new Error('バックアップがありません。移行元のバックアップフォルダをbackupsへコピーしてください。');
  names.forEach((name, index) => console.log(`${index + 1}: ${name}`));
  const value = await ask('復元する番号: ');
  if (!/^\d+$/.test(value) || !names[Number(value) - 1]) throw new Error('番号が不正です。');
  const name = names[Number(value) - 1];
  await validateBackup(path.join(root, 'backups', name));
  console.log(`対象: ${name}\n現在の成績・計画・AI原本・添付資料・出力物を置き換えます。現在の状態は先にバックアップします。`);
  if (await ask('復元する場合だけ RESTORE と入力: ') !== 'RESTORE') return;
  console.log(`復元完了。復元前バックアップ: ${await restoreBackup(root, name)}`);
}

let release;
try {
  const { randomUUID } = await import('node:crypto');
  env.EXAM_COACH_INSTANCE_ID = randomUUID();
  await initialize(root);
  console.log(`高校入試コーチ — 個人端末版\n保存先: ${root}\nデータを他の利用者へ自動共有しません。外部AIへ貼り付けた内容は、そのサービスへ送られます。`);
  const action = process.argv[2] || await ask('\n1: 起動  2: 初回設定・更新  3: バックアップ  4: 復元  5: 保存先を表示\n番号: ');
  if (action !== '5') {
    release = await acquireLock(root);
    if (action === '1' || action === 'start') await start();
    else if (action === '2' || action === 'setup') await setup();
    else if (action === '3' || action === 'backup') console.log(`バックアップ: ${await createBackup(root)}`);
    else if (action === '4' || action === 'restore') await restore();
    else throw new Error('1〜5を選んでください。');
  }
} catch (error) {
  // DB内容や入力値を含むスタックは表示しない。
  console.error(error instanceof Error && !('code' in error) ? error.message : '操作に失敗しました。保存先の権限・空き容量・操作ガイドを確認してください。');
  process.exitCode = 1;
} finally { if (release) await release(); rl.close(); }
