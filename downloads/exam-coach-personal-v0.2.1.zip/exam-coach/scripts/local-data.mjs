import { mkdir, readFile, writeFile, readdir, lstat, copyFile, rename, rm } from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { randomUUID, createHash } from 'node:crypto';
import { DatabaseSync, backup } from 'node:sqlite';

export function defaultDataRoot() {
  const base = process.platform === 'win32' ? (process.env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local'))
    : process.platform === 'darwin' ? path.join(os.homedir(), 'Library', 'Application Support')
    : (process.env.XDG_DATA_HOME || path.join(os.homedir(), '.local', 'share'));
  return path.join(base, 'exam-coach');
}

export async function initialize(root) {
  for (const dir of ['', 'current', 'current/uploads', 'current/exports', 'backups', 'logs']) {
    await mkdir(path.join(root, dir), { recursive: true, mode: 0o700 });
  }
}

export async function acquireLock(root) {
  const lock = path.join(root, '.operation-lock');
  try { await mkdir(lock, { mode: 0o700 }); }
  catch { throw new Error('起動中または別の操作中です。先にアプリを終了してください。異常終了後は操作ガイドのロック解除手順を確認してください。'); }
  await writeFile(path.join(lock, 'owner.json'), JSON.stringify({ pid: process.pid }), { mode: 0o600 });
  return () => rm(lock, { recursive: true, force: true });
}

async function filesUnder(root, prefix = '') {
  const result = [];
  if ((await lstat(path.join(root, prefix))).isSymbolicLink()) throw new Error('シンボリックリンクを含むデータは処理できません。');
  for (const entry of await readdir(path.join(root, prefix), { withFileTypes: true })) {
    const relative = path.posix.join(prefix, entry.name);
    if (entry.isSymbolicLink()) throw new Error('シンボリックリンクを含むデータは処理できません。');
    if (entry.isDirectory()) result.push(...await filesUnder(root, relative));
    else if (entry.isFile()) result.push(relative);
    else throw new Error('通常ファイル以外が含まれています。');
  }
  return result.sort();
}

async function copyTree(source, target) {
  await mkdir(target, { recursive: true, mode: 0o700 });
  for (const file of await filesUnder(source)) {
    await mkdir(path.dirname(path.join(target, file)), { recursive: true, mode: 0o700 });
    await copyFile(path.join(source, file), path.join(target, file));
  }
}

function checkDatabase(file) {
  const db = new DatabaseSync(file, { readOnly: true });
  try {
    if (db.prepare('PRAGMA integrity_check').get().integrity_check !== 'ok') throw new Error('データベースの整合性を確認できません。');
    if (db.prepare('PRAGMA foreign_key_check').all().length) throw new Error('データの参照関係が不正です。');
  } finally { db.close(); }
}

async function hashes(root) {
  const result = {};
  for (const file of await filesUnder(root)) result[file] = createHash('sha256').update(await readFile(path.join(root, file))).digest('hex');
  return result;
}

// 呼び出し側が起動・更新・バックアップ・復元に共通のロックを保持する。
export async function createBackup(root) {
  const current = path.join(root, 'current');
  checkDatabase(path.join(current, 'app.db'));
  const name = `exam-coach-backup-${new Date().toISOString().replace(/[:.]/g, '-')}-${randomUUID().slice(0, 8)}`;
  const staging = path.join(root, 'backups', `.creating-${randomUUID()}`);
  const payload = path.join(staging, 'data');
  await mkdir(payload, { recursive: true, mode: 0o700 });
  try {
    const db = new DatabaseSync(path.join(current, 'app.db'), { readOnly: true });
    try { await backup(db, path.join(payload, 'app.db')); } finally { db.close(); }
    for (const dir of ['uploads', 'exports']) await copyTree(path.join(current, dir), path.join(payload, dir));
    const manifest = { format: 'exam-coach-backup', version: 1, createdAt: new Date().toISOString(), files: await hashes(payload) };
    await writeFile(path.join(staging, 'manifest.json'), JSON.stringify(manifest, null, 2), { mode: 0o600 });
    await rename(staging, path.join(root, 'backups', name));
    return name;
  } catch (error) { await rm(staging, { recursive: true, force: true }); throw error; }
}

export async function validateBackup(directory) {
  if ((await lstat(directory)).isSymbolicLink() || (await lstat(path.join(directory, 'data'))).isSymbolicLink()) throw new Error('リンクは復元できません。');
  const manifest = JSON.parse(await readFile(path.join(directory, 'manifest.json'), 'utf8'));
  if (manifest.format !== 'exam-coach-backup' || manifest.version !== 1 || !manifest.files || typeof manifest.files !== 'object') throw new Error('対応していないバックアップ形式です。');
  const actual = await hashes(path.join(directory, 'data'));
  if (!actual['app.db'] || Object.keys(actual).some(file => file !== 'app.db' && !file.startsWith('uploads/') && !file.startsWith('exports/'))
    || JSON.stringify(Object.entries(actual).sort()) !== JSON.stringify(Object.entries(manifest.files).sort())) throw new Error('バックアップの欠損または変更を検出しました。');
  checkDatabase(path.join(directory, 'data', 'app.db'));
  return manifest;
}

export async function restoreBackup(root, name) {
  if (!/^exam-coach-backup-[\w-]+$/.test(name)) throw new Error('バックアップ名が不正です。');
  const source = path.join(root, 'backups', name);
  await validateBackup(source);
  const emergency = await createBackup(root);
  const staging = path.join(root, `.restore-${randomUUID()}`);
  const rollback = path.join(root, `.rollback-${randomUUID()}`);
  const current = path.join(root, 'current');
  await copyTree(path.join(source, 'data'), staging);
  for (const dir of ['uploads', 'exports']) await mkdir(path.join(staging, dir), { recursive: true, mode: 0o700 });
  await rename(current, rollback);
  try { await rename(staging, current); }
  catch (error) { await rename(rollback, current); throw error; }
  await rm(rollback, { recursive: true, force: true });
  return emergency;
}
