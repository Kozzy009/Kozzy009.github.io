#!/bin/bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
PRODUCTION_ENV_FILE="$PROJECT_DIR/.env.production.local"

load_production_env() {
  if [[ ! -f "$PRODUCTION_ENV_FILE" ]]; then
    echo "本番環境ファイルがありません。先に『初回設定.command』を実行してください。" >&2
    return 1
  fi
  set -a
  # shellcheck disable=SC1090
  source "$PRODUCTION_ENV_FILE"
  set +a
  : "${DATABASE_URL:?DATABASE_URLが設定されていません}"
  : "${UPLOAD_STORAGE_PATH:?UPLOAD_STORAGE_PATHが設定されていません}"
  : "${BACKUP_STORAGE_PATH:?BACKUP_STORAGE_PATHが設定されていません}"
  : "${APP_BASE_URL:=http://localhost:3000}"
  [[ "$UPLOAD_STORAGE_PATH" == /* && "$BACKUP_STORAGE_PATH" == /* ]] || {
    echo "本番の保存先は絶対パスで指定してください。" >&2
    return 1
  }
  DATA_ROOT="$(dirname "$UPLOAD_STORAGE_PATH")"
  DB_RESOLVED="$(database_path)"
  if [[ "$DATA_ROOT" == "/" || "$DATA_ROOT" == "$HOME" || "$DATA_ROOT" == "$PROJECT_DIR" ]]; then
    echo "運用データの保存先が安全ではありません。プロジェクト外の専用ディレクトリを指定してください。" >&2
    return 1
  fi
  [[ "$UPLOAD_STORAGE_PATH" == "$DATA_ROOT/"* && "$BACKUP_STORAGE_PATH" == "$DATA_ROOT/"* && "$DB_RESOLVED" == "$DATA_ROOT/"* ]] || {
    echo "database、uploads、backupsは同じ専用運用データディレクトリ内へ設定してください。" >&2
    return 1
  }
  LOG_DIR="$DATA_ROOT/logs"
  EXPORT_DIR="$DATA_ROOT/exports"
  RUNTIME_DIR="$DATA_ROOT/runtime"
  PID_FILE="$RUNTIME_DIR/app.pid"
  mkdir -p "$LOG_DIR" "$EXPORT_DIR" "$RUNTIME_DIR"
  chmod 700 "$DATA_ROOT" "$LOG_DIR" "$EXPORT_DIR" "$RUNTIME_DIR" 2>/dev/null || true
}

database_path() {
  local raw="${DATABASE_URL#file:}"
  if [[ "$raw" != /* ]]; then raw="$PROJECT_DIR/${raw#./}"; fi
  printf '%s\n' "$raw"
}

timestamp() { date '+%Y%m%d-%H%M%S'; }
log_event() {
  local kind="$1" message="$2"
  mkdir -p "$LOG_DIR"
  printf '%s [%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$kind" "$message" >> "$LOG_DIR/operations.log"
}

is_app_process() {
  local pid="$1" command cwd_line
  [[ "$pid" =~ ^[0-9]+$ ]] || return 1
  kill -0 "$pid" 2>/dev/null || return 1
  command="$(ps -p "$pid" -o command= 2>/dev/null || true)"
  [[ "$command" == *"next start"* || "$command" == *"npm run start"* || "$command" == *"next-server"* ]] || return 1
  if command -v lsof >/dev/null 2>&1; then
    cwd_line="$(lsof -a -p "$pid" -d cwd -Fn 2>/dev/null | sed -n 's/^n//p' | head -n 1)"
    [[ "$cwd_line" == "$PROJECT_DIR" ]] || return 1
  fi
}

find_app_pid_on_port() {
  command -v lsof >/dev/null 2>&1 || return 1
  local candidate
  for candidate in $(lsof -tiTCP:3000 -sTCP:LISTEN 2>/dev/null); do
    if is_app_process "$candidate"; then printf '%s\n' "$candidate"; return 0; fi
  done
  return 1
}

pause_if_interactive() {
  if [[ -t 0 && "${IWAKI_NO_PAUSE:-0}" != "1" ]]; then
    echo
    read -r -p "Enterキーを押して閉じてください。" _
  fi
}
