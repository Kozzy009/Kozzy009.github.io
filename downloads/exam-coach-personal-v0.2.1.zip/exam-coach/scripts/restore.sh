#!/bin/bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
# shellcheck source=common.sh
source "$SCRIPT_DIR/common.sh"
load_production_env
DB_PATH="$(database_path)"

if [[ -f "$PID_FILE" ]]; then
  PID="$(cat "$PID_FILE" 2>/dev/null || true)"
  if is_app_process "$PID"; then echo "復元前にアプリを終了してください。" >&2; exit 1; fi
fi
BACKUPS=()
while IFS= read -r backup; do BACKUPS[${#BACKUPS[@]}]="$backup"; done < <(find "$BACKUP_STORAGE_PATH" -maxdepth 1 -type d -name 'iwaki-exam-coach-backup-*' | sort -r)
[[ ${#BACKUPS[@]} -gt 0 ]] || { echo "利用可能なバックアップがありません。" >&2; exit 1; }
echo "利用可能なバックアップ："
for i in "${!BACKUPS[@]}"; do echo "$((i+1))) $(basename "${BACKUPS[$i]}")"; done
if [[ -n "${IWAKI_RESTORE_INDEX:-}" ]]; then choice="$IWAKI_RESTORE_INDEX"; else read -r -p "復元する番号を入力してください: " choice; fi
[[ "$choice" =~ ^[0-9]+$ ]] && (( choice >= 1 && choice <= ${#BACKUPS[@]} )) || { echo "選択が不正です。" >&2; exit 1; }
SELECTED="${BACKUPS[$((choice-1))]}"
[[ -f "$SELECTED/manifest.txt" ]] || { echo "バックアップの構成が不正です。" >&2; exit 1; }
cat "$SELECTED/manifest.txt"
if [[ "${IWAKI_RESTORE_CONFIRM:-}" != "RESTORE" ]]; then read -r -p "復元するには RESTORE と入力してください: " confirm; [[ "$confirm" == "RESTORE" ]] || { echo "復元を中止しました。"; exit 0; }; fi

echo "現在データの緊急バックアップを作成します。"
IWAKI_NO_PAUSE=1 "$SCRIPT_DIR/backup.sh" --emergency
STAMP="$(timestamp)"
STAGE="$DATA_ROOT/.restore-stage-$STAMP"
ROLLBACK="$DATA_ROOT/.restore-rollback-$STAMP"
mkdir -p "$STAGE" "$ROLLBACK" "$(dirname "$DB_PATH")"
trap 'echo "復元に失敗しました。元の状態へ戻します。" >&2; [[ -f "$ROLLBACK/app.db" ]] && cp "$ROLLBACK/app.db" "$DB_PATH"; [[ -d "$ROLLBACK/uploads" ]] && { rm -rf "$UPLOAD_STORAGE_PATH"; mv "$ROLLBACK/uploads" "$UPLOAD_STORAGE_PATH"; }; rm -rf "$STAGE"; log_event "RESTORE_FAILED" "復元失敗"' ERR
[[ -f "$SELECTED/database/app.db" ]] && cp "$SELECTED/database/app.db" "$STAGE/app.db"
mkdir -p "$STAGE/uploads"
[[ -d "$SELECTED/uploads" ]] && cp -R "$SELECTED/uploads"/. "$STAGE/uploads"/ 2>/dev/null || true
[[ -f "$DB_PATH" ]] && cp "$DB_PATH" "$ROLLBACK/app.db"
[[ -d "$UPLOAD_STORAGE_PATH" ]] && mv "$UPLOAD_STORAGE_PATH" "$ROLLBACK/uploads"
mkdir -p "$UPLOAD_STORAGE_PATH"
cp -R "$STAGE/uploads"/. "$UPLOAD_STORAGE_PATH"/ 2>/dev/null || true
[[ -f "$STAGE/app.db" ]] && mv "$STAGE/app.db" "$DB_PATH"
rm -rf "$STAGE"
rm -rf "$ROLLBACK"
log_event "RESTORE" "バックアップ復元成功"
echo "復元が完了しました。緊急バックアップも保存されています。"
