@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 24以上をインストールしてから、もう一度開いてください。
) else (
  node scripts/local-app.mjs
)
pause
