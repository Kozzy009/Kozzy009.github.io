# 受験カルテUI 実装計画

## 目的

既存の生徒、学力テスト、学習アンケート、固定ルール分析、週間計画を壊さず、生徒単位で8つのカルテを確認・更新できる導線へ再構成する。OCR、生成AI、類題生成は対象外とする。

## 調査結果とモデル対応

依頼文の名称は概念名であり、現行Prismaスキーマでは次のモデル群が同じ責務を担う。

| 概念 | 現行モデル | 判断 |
| --- | --- | --- |
| AcademicProfile | `AcademicTest`、`AcademicTestScore`、`SubjectAnalysis` | 既存データを集約して表示し、新しい1対1モデルは作らない |
| LearningProfile | `StudySurvey`、`StudySurveySubject`、`LearningTendency` | 回答履歴を保持する既存構造を再利用する |
| ExamProfile | `Student.examYear`、`TargetSchool` | 教科別目標と変更履歴だけ追加する |
| ProblemProfile | なし | 問題単位の手入力に必要なため追加する |
| ReviewProfile | なし | 復習予定と履歴に必要なため追加する |
| AnalysisHistory | `AnalysisResult` | 追記型であり履歴要件を満たす。画面上は「分析履歴」と呼ぶ |
| StudyPlan | `WeeklyStudyPlan`、`StudyPlanItem` | 既存の版管理・生成理由を再利用する |
| StudyRecord | `StudyRecord` | 既存モデルを再利用する |
| AIRecommendation | なし | 生成AIは今回対象外。`LearningTendency.recommendation` とルール版を説明可能な提案として使う |

## 最小データモデル変更

- `TargetSchool` に設定日・指導者コメントを追加する。
- `TargetSchoolSubjectGoal` を追加し、志望校ごとの5教科目標点を保持する。
- `TargetSchoolHistory` を追加し、編集前後の内容をJSONスナップショットで追記する。
- `ProblemProfile` を追加し、問題の出典、分類、正誤、複数ミス、復習対象を保持する。
- `ReviewProfile` と `ReviewAttempt` を追加し、復習状態、次回日、実施履歴を保持する。
- `SubjectAnalysis` に優先単元を追加する。問題データがない場合はアンケートの不安単元または暫定表現を用いる。

既存テーブルの削除・名称変更は行わない。追加列には既定値またはNULLを許可し、既存行を保持する。

## サービス層

- `src/services/karte-service.ts`: 各画面に必要な関連データを一括取得し、表示用データへ変換する。
- `src/domain/review-schedule.ts`: 翌日、3日、7日、14日、30日の決定的な復習間隔を計算する。
- `src/domain/karte-analysis.ts`: 問題・復習から優先単元、強み、課題、復習候補を導出する。
- 更新処理はServer Actionに置き、Zod検証と`studentId`による所有確認を必須とする。

## 画面と導線

1. 概要: `/students/[studentId]`
2. 学力カルテ: `/students/[studentId]/academic`
3. 学習カルテ: `/students/[studentId]/learning`
4. 受験カルテ: `/students/[studentId]/exam`
5. 問題カルテ: `/students/[studentId]/problems`
6. 復習カルテ: `/students/[studentId]/reviews`
7. 学習プラン: `/students/[studentId]/plans`
8. 学習記録: `/students/[studentId]/records`

既存の`/progress`と`/target-schools`は互換導線として残す。ナビゲーションはスマートフォンで横スクロール可能にする。

## 分析・計画の更新

- 分析更新時に直近3回のテスト、最新アンケート、問題の誤答、復習予定を1回ずつ取得する。
- `AnalysisResult`を毎回新規作成し、過去結果を削除しない。
- 優先単元は、誤答・無回答・復習期限超過を重み付けし、教科別に最上位を選ぶ。
- 学習計画は既存の優先教科・集中可能時間・曜日に加え、志望校目標差、優先単元、期限到来の復習問題を理由へ反映する。

## 実装順序

1. 追加モデル、マイグレーション、Zod、復習日計算の単体テスト
2. サービス層と共通カルテヘッダー／ナビゲーション
3. 概要・学力・学習・受験カルテ
4. 問題CRUD／絞り込み、復習登録／実施記録
5. 分析・計画連携、学習記録画面、空状態・loading/error
6. シード、単体・E2E相当の画面到達確認、lint、型検査、build

## 安全性と互換性

- 実名・解答・コメントをログへ出さない。
- 問題・復習・志望校更新では親生徒との所有関係を確認する。
- 削除は対象を画面で明示し、関連復習はDBのCascadeで削除する。
- 合否や能力を断定せず、「登録データ上の差」「可能性」「提案」と表現する。
- データ欠損は空状態として案内し、グラフ・分析を無理に生成しない。
