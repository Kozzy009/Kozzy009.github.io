# 汎用AI手動類似問題生成・個別問題集 実装計画

## 現状確認

- `ProblemProfile` は問題文、正答、本人解答、単元、ミス、復習対象と、手動AI解析元を保持する。
- `ReviewProfile` は問題別の復習予定と `ReviewAttempt` の履歴を保持する。
- 学習プランは `WeeklyStudyPlan → StudyPlanItem → StudyRecord` で、単元、目的、問題数、難易度、実施率を追跡する。
- 学習タイプは `LearningTendency`、優先教科・単元は `SubjectAnalysis` で保持しており、独立した `PrioritySubject` / `PriorityUnit` モデルは存在しない。
- `ManualAiImportSession / ManualAiImportQuestion` は学力テスト解析専用であり、匿名ID・トークン・JSON検証・人の確認を実装済みである。
- 問題・復習・学習プラン・分析画面は存在するが、類似問題生成と問題集機能は存在しない。
- サーバーPDF生成ライブラリはない。初期版は日本語をブラウザで描画するA4印刷画面を提供し、「PDFとして保存」でPDFを生成する。

## 実装方針

1. 解析用JSONと混同しない独立したテンプレート、スキーマ、セッション、候補モデルを追加する。
2. 元問題、復習予定、学習プラン、優先単元から生成依頼へ遷移できるようにする。
3. 学習アンケート・傾向・実施率は初期値の決定にだけ使い、自由記述や配慮事項を外部向けプロンプトへ含めない。
4. JSONは原本を保存し、照合・構造検証・保守的な数学検算を行う。すべて人が確認し、承認済みだけを問題集へ追加する。
5. 個別問題集は並び順と表示設定を保存し、A4印刷画面で問題・解答・詳細解説の出力モードを切り替える。
6. 実施結果は問題ごとに追記し、誤答を問題カルテ・復習カルテへトランザクションで反映する。

## 画面

1. `/students/[studentId]/generations` 類似問題生成履歴
2. `/students/[studentId]/generations/new` 元問題・生成条件
3. `/students/[studentId]/generations/[sessionId]/prompt` プロンプト表示・コピー
4. `/students/[studentId]/generations/[sessionId]/result` JSON貼り付け・ファイル検証
5. `/students/[studentId]/generations/[sessionId]/review` 問題確認・修正・承認
6. `/students/[studentId]/workbooks` 個別問題集一覧
7. `/students/[studentId]/workbooks/new` 承認済み問題選択・問題集作成
8. `/students/[studentId]/workbooks/[workbookId]` プレビュー・並び替え・複製・削除・実施結果
9. `/students/[studentId]/workbooks/[workbookId]/print` A4印刷／PDF保存

## 安全性と承認ゲート

- API通信を実装せず、氏名、アンケート自由記述、配慮事項をプロンプトへ含めない。
- セッションごとの匿名IDと `generationToken`、教科、学年、単元、スキーマ版、生成数を照合する。
- 元問題文は必要部分を最大500文字に制限し、長文読解では全文再利用を指示しない。
- confidence 80未満、図表、記述、英作文、証明、複数解、採点基準、検証注記、数学検算不能は初期状態を要確認にする。
- AI出力を自動承認せず、原本、修正後、承認者、監査ログを保持する。

## 実装順

1. Prismaモデル、テンプレート、JSON Schema、Zod、初期値、数学検算
2. 生成依頼、プロンプト、JSON受信、確認・承認
3. 既存4画面からの入口
4. 問題集作成、並び替え、印刷、複製、削除
5. 実施結果と問題・復習カルテ反映
6. 一次関数サンプル、単体テスト、ブラウザE2E、全品質検査
