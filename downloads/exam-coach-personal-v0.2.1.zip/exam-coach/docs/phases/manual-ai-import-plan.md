# 汎用AI手動解析連携 実装計画

## 方針

システムから外部AIへ通信しない。匿名化した解析依頼プロンプトを人がコピーし、任意の汎用AIへ資料とともに入力する。返却JSONは候補として保存し、照合・検証・人の確認・重複方針の選択後にだけ問題カルテへ反映する。

## 既存機能との関係

- `UploadedFile` の登録済み資料を解析対象として選べるが、ファイル自体を外部送信する処理は持たない。
- 既存の `ImportSession` / `ImportCandidateQuestion` はMock OCR・手入力用として維持する。
- 汎用AI手動解析は `ManualAiImportSession` 以下の独立した履歴とし、既存OCR候補と取り違えない。
- 確定時は既存の `ProblemProfile` と `ReviewProfile` を使用し、分析更新・週間計画は既存の固定ルールを再利用する。

## 安全性

- 生徒氏名をプロンプトへ含めず、セッションごとにランダムな `studentAnonymousId` を発行する。
- `importToken`、匿名ID、テスト名、教科、学年、スキーマ版をJSONと照合する。
- 外部AIサービス名を保存・固定せず、APIキーやHTTPクライアントを追加しない。
- JSONは5MB以下、完全なJSONまたは全体を囲むMarkdown JSONコードブロックだけを受け付ける。
- AI結果は未確認候補として表示し、70未満の確信度または `needsHumanReview=true` を要確認にする。
- 元JSON、検証エラー、AI出力の原値、修正後スナップショット、確認者、監査ログを保持する。

## 画面

1. `/students/[studentId]/manual-ai` セッション一覧
2. `/students/[studentId]/manual-ai/new` 解析依頼作成
3. `/students/[studentId]/manual-ai/[sessionId]/prompt` プロンプト表示・コピー
4. `/students/[studentId]/manual-ai/[sessionId]/result` JSON貼り付け・ファイル・検証結果
5. `/students/[studentId]/manual-ai/[sessionId]/review` 候補確認・修正
6. `/students/[studentId]/manual-ai/[sessionId]/confirm` 問題カルテ反映確認
7. `/students/[studentId]/manual-ai/[sessionId]/complete` 完了・分析更新導線

## 実装順

1. テンプレート、JSON Schema、Zod、照合ロジック
2. Prismaモデルと既存問題への追跡リレーション
3. Server Actions、サービス、監査ログ
4. 画面・コピー機能・既存カルテからの導線
5. 境界テスト、E2E、全品質検査
