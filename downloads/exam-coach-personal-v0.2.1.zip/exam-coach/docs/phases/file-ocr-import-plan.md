# ファイル・OCR取り込み 実装計画

## 目的

成績表、問題用紙、本人解答、模範解答、解説、その他資料を学力テストへ紐づけ、読み取り候補を必ず人が確認・修正してから学力テストと問題カルテへ反映する。外部OCR、生成AI、自動確定は行わない。

## 現状確認

- `AcademicTest` は生徒と5教科得点、`ProblemProfile` は問題別結果、`ReviewProfile` は復習予定を保持している。
- `UploadedFile`、OCR、取り込みセッション、監査ログ、非公開ファイルストレージは存在しない。
- アップロード用環境変数はなく、DB以外の保存先設定も存在しない。
- 既存カルテはServer Component、入力はServer ActionとZod、DB処理はPrismaを使用している。

## 最小追加モデル

- `UploadedFile`: ファイル属性、ハッシュ、保存キー、処理・確認状態。
- `OcrJob` / `OcrPageResult` / `OcrExtractedItem`: 読み取り実行と未確定候補。
- `ImportSession` / `ImportCandidateQuestion`: 複数資料の統合、問題候補、人の確認状態。
- `AuditLog`: アップロード、処理、修正、除外、確定、中止、問題・復習作成を記録。
- `ProblemProfile` に問題文、読み取り元、確認者・確認日時、候補IDを追加する。

既存行を削除せず、追加列はnullableまたは既定値付きとする。既存の問題・復習ルールは再利用する。

## 層構成

1. `StorageProvider`: 保存、取得、削除。初期実装はリポジトリ外部公開されない `.data/uploads` の `LocalStorageProvider`。
2. ファイル検証: MIME、拡張子、実体シグネチャ、サイズ、空ファイル、ファイル名、SHA-256重複。
3. `OcrProvider`: `MockOcrProvider` と `ManualEntryProvider`。外部送信なし。
4. 候補統合: 大問・小問を正規化したキーで資料間を対応付ける。不一致は要確認。
5. 人による確認: 抽出項目・問題候補の修正、確認、除外、追加、削除。
6. 確定: 未確認・判定保留を拒否し、重複方針を確認してトランザクションで得点・問題・復習へ反映。

## 画面・ルート

1. `/students/[studentId]/files`
2. `/students/[studentId]/files/new`
3. `/students/[studentId]/files/[fileId]`
4. `/students/[studentId]/files/[fileId]/status`
5. `/students/[studentId]/imports/[sessionId]/review`
6. `/students/[studentId]/imports/[sessionId]/mapping`
7. `/students/[studentId]/imports/[sessionId]/confirm`
8. `/students/[studentId]/imports/[sessionId]/complete`

元ファイルは `/api/students/[studentId]/files/[fileId]` から関連確認後に返し、保存パスを画面やURLへ出さない。

## 安全性

- 許可形式はPDF/PNG/JPEG、既定上限は20MB。`UPLOAD_MAX_BYTES` で変更可能。
- 保存名はランダムUUIDで、氏名・元ファイル名を含めない。`.data/uploads` はGit対象外。
- 現行MVPに認証がないため、生徒ID・ファイル所有関係を検証する。ただし本番公開は不可。
- ログには保存パス、ファイル本文、生徒氏名、OCR全文を記録しない。
- DB作成失敗時は保存済みファイルを削除し、確定処理はトランザクション化する。

## 実装順

1. モデル・マイグレーション・環境設定
2. 保存・検証・OCRプロバイダー・候補統合の純粋ロジック
3. サービス層とServer Action
4. 8画面、元ファイル取得API、既存カルテからの導線
5. モックデータ、単体テスト、E2E、品質検査
