# 高校入試コーチ 画面一覧

## 1. 画面設計方針

- 中学生がスマートフォンで迷わず使える、短い日本語と一画面一目的を基本とする。
- 生徒選択後は「基本情報・志望校・学力テスト・学習アンケート・学習状況の分析・優先教科/単元・学習プラン・学習記録」の順で導線を表示する。
- 保存成功、入力エラー、データ不足、削除影響を文字で明示する。
- グラフは補助表を併設し、色だけで教科や増減を表現しない。

## 2. 画面一覧

| ID | 画面 | ルート案 | 主な内容・操作 |
| --- | --- | --- | --- |
| SC-01 | 生徒一覧 | `/` | 生徒カード、登録、詳細へ移動。0件時は登録案内。 |
| SC-02 | 生徒登録 | `/students/new` | 氏名、ふりがな、学年、中学校、地域、受験年度、第一/第二志望校・学科、部活動、習い事、配慮事項、備考。学習時間や得意・苦手は含めない。 |
| SC-03 | 生徒概要 | `/students/[studentId]` | プロフィール、志望校、最新入力、分析・計画への次アクション。 |
| SC-04 | 生徒編集・削除 | `/students/[studentId]/edit` | 基本情報編集。削除時は関連件数と不可逆性を確認。 |
| SC-05 | 志望校設定 | `/students/[studentId]/target-schools` | 第1・第2志望を各1校まで登録・変更・解除。自由入力である旨を表示。 |
| SC-06 | テスト履歴 | `/students/[studentId]/tests` | 受験日、受験時学年、テスト名、5教科合計・得点率、追加・詳細。 |
| SC-07 | テスト登録 | `/students/[studentId]/tests/new` | 基本情報と5教科の得点・満点を一括入力。 |
| SC-08 | テスト詳細・編集 | `/students/[studentId]/tests/[testId]` | 全得点、編集、削除。保存済み分析が古くなる場合を案内。 |
| SC-09 | アンケート履歴 | `/students/[studentId]/surveys` | 回答日、モチベーション、可能時間、追加・詳細。 |
| SC-10 | アンケート回答 | `/students/[studentId]/surveys/new` | 現在時間、確保可能時間、集中時間、可能/繁忙曜日、意欲、自信、方法、集中環境、教科別自己評価・頻度、自由記述。新規回答として履歴保存。 |
| SC-11 | アンケート詳細・編集 | `/students/[studentId]/surveys/[surveyId]` | 回答内容、編集、削除。分析への影響を案内。 |
| SC-12 | 成績推移 | `/students/[studentId]/progress` | 教科タブ、得点率折れ線、受験時学年、同内容の表、空状態。 |
| SC-13 | 学習分析 | `/students/[studentId]/analysis` | 学習状況、強み、課題、複数学習タイプ、推奨方法、5教科順位・理由、計画作成ボタン。 |
| SC-14 | 週間計画一覧 | `/students/[studentId]/plans` | 対象週・版・作成日時、計画作成、過去版表示。 |
| SC-15 | 週間計画作成・編集 | `/students/[studentId]/plans` | 対象週の下書きを自動提案し、曜日・教科・時間・問題数・内容を編集して確定。 |
| SC-16 | 週間計画・実績 | `/students/[studentId]/plans` | 詳細、実施時間、問題数、正答数、集中、ミス、コメント、週間集計、次週調整案。 |

## 3. 主要導線

### 初回利用

`生徒登録 → 志望校設定 → テスト登録 → アンケート回答 → 成績推移 → 学習分析 → 週間計画作成`

### 継続利用

`生徒概要 → 新しいテストまたはアンケートを登録 → 再分析 → 次週計画を作成`

## 4. 共通状態

- 読み込み中: 画面構造が分かるプレースホルダーまたは短い進行表示。
- 空状態: 不足データと、次に入力する画面へのリンクを表示。
- 入力エラー: 項目直下とページ上部に日本語で表示し、入力値を保持。
- 対象なし: 他生徒の子データを含め、存在を推測させない404表示。
- 古い分析: より新しい入力または元データの変更を検知し、再分析ボタンを表示。
- 破壊的操作: 対象名、影響範囲、取り消せないことを確認してから実行。

## 5. レスポンシブ・アクセシビリティ

- 360px幅で横スクロールせず主要操作を完了できることを目標とする。
- 5教科入力は教科ごとのまとまりを保ち、数値入力に単位と範囲を表示する。
- すべての入力にラベルを関連付け、キーボードで操作できるようにする。
- グラフには教科名、軸名、単位、ツールチップを付け、同値情報を表で提供する。
- モチベーションや点数を否定的・断定的に表現せず、「次の行動」に結びつく文言を使う。

## 6. カルテナビゲーション

生徒詳細の主要導線は次の8画面に統一する。従来の入力・分析詳細ルートは各カルテから遷移する補助画面として残す。

| 順 | 画面 | ルート | 主な内容 |
| ---: | --- | --- | --- |
| 1 | 概要 | `/students/[studentId]` | 基本情報、最新状況、優先教科・単元、次の操作 |
| 2 | 学力カルテ | `/students/[studentId]/academic` | 得点推移、平均との差、教科・単元分析 |
| 3 | 学習カルテ | `/students/[studentId]/learning` | 学習時間、習慣、本人認識、学習傾向 |
| 4 | 受験カルテ | `/students/[studentId]/exam` | 志望校、目標点、差、設定日、変更履歴、指導者コメント |
| 5 | 問題カルテ | `/students/[studentId]/problems` | 問題別結果の登録・編集・削除・絞り込み |
| 6 | 復習カルテ | `/students/[studentId]/reviews` | 復習予定、状態、実施履歴、定着状況 |
| 7 | 学習プラン | `/students/[studentId]/plans` | 最新分析・復習候補に基づく週間計画 |
| 8 | 学習記録 | `/students/[studentId]/records` | 実施結果の履歴 |

狭い画面ではナビゲーションだけを横スクロール可能にし、本文は360px幅に収める。各画面は読み込み中、空状態、404、サーバーエラーからの再試行を用意する。

## 7. ファイル取り込み画面

| 順 | 画面 | ルート |
| ---: | --- | --- |
| 1 | ファイル一覧 | `/students/[studentId]/files` |
| 2 | アップロード | `/students/[studentId]/files/new` |
| 3 | ファイル詳細 | `/students/[studentId]/files/[fileId]` |
| 4 | OCR処理状況 | `/students/[studentId]/files/[fileId]/status` |
| 5 | 読み取り確認 | `/students/[studentId]/imports/[sessionId]/review` |
| 6 | 問題対応付け | `/students/[studentId]/imports/[sessionId]/mapping` |
| 7 | 取り込み確認 | `/students/[studentId]/imports/[sessionId]/confirm` |
| 8 | 取り込み完了 | `/students/[studentId]/imports/[sessionId]/complete` |

確認画面はデスクトップで元ファイルと候補を左右、スマートフォンで上下に表示する。

## 8. 汎用AI手動解析画面

| 順 | 画面 | ルート |
| ---: | --- | --- |
| 1 | 解析依頼一覧 | `/students/[studentId]/manual-ai` |
| 2 | AI解析依頼作成 | `/students/[studentId]/manual-ai/new` |
| 3 | プロンプト表示・コピー | `/students/[studentId]/manual-ai/[sessionId]/prompt` |
| 4 | JSON貼り付け・ファイル選択・検証結果 | `/students/[studentId]/manual-ai/[sessionId]/result` |
| 5 | 読み込み候補確認・修正 | `/students/[studentId]/manual-ai/[sessionId]/review` |
| 6 | 問題カルテ反映確認・重複方針 | `/students/[studentId]/manual-ai/[sessionId]/confirm` |
| 7 | 取り込み完了 | `/students/[studentId]/manual-ai/[sessionId]/complete` |

各段階でAI出力を「候補」と表現し、JSON検証成功だけでは問題カルテへ反映しない。

## 9. 類似問題生成・個別問題集画面

| 画面 | ルート |
| --- | --- |
| 類似問題生成履歴・条件設定 | `/students/[studentId]/generations`, `/generations/new` |
| プロンプト・JSON・確認承認 | `/generations/[sessionId]/prompt`, `/result`, `/review` |
| 問題集一覧・新規作成 | `/students/[studentId]/workbooks`, `/workbooks/new` |
| 問題集編集・実施結果 | `/workbooks/[workbookId]` |
| A4印刷・PDF保存 | `/workbooks/[workbookId]/print?mode=...` |

## 個人端末版（2026-09-14）

ホームに端末内保存・任意AI連携・バックアップの案内を追加。AIプロンプト画面で外部サービスへの送信と自由入力部分の確認を明示する。端末の起動メニューは起動、初回設定・更新、バックアップ、復元、保存先表示を提供する。
