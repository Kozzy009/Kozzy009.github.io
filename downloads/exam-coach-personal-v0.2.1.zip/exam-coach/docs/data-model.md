# 高校入試コーチ データモデル

## 1. 設計方針

- PrismaとSQLiteを使用し、主キーはCUID文字列とする。
- 作成・更新日時はUTCで保存し、画面ではAsia/Tokyoとして表示する。
- 日付のみの項目はアプリケーション層で `YYYY-MM-DD` として検証する。
- 得点率は元データから計算し、重複保存しない。
- 分析と計画は、後から理由を説明できるよう入力・結果のスナップショットを保存する。
- MVPの削除は物理削除とする。生徒削除時の関連削除は確認後、トランザクションで行う。

## 2. 列挙値

| 名前 | 値 |
| --- | --- |
| `GradeLevel` | `JH1`, `JH2`, `JH3` |
| `Subject` | `JAPANESE`, `MATH`, `ENGLISH`, `SCIENCE`, `SOCIAL_STUDIES` |
| `PreferenceRank` | `FIRST`, `SECOND` |
| `AnalysisStatus` | `COMPLETE`, `PROVISIONAL` |
| `PlanStatus` | `ACTIVE`, `SUPERSEDED` |

日本語表示名は共通定数に集約し、DBには列挙値を保存する。

## 3. 関係図

```mermaid
erDiagram
  Student ||--o{ TargetSchool : has
  Student ||--o{ AcademicTest : takes
  AcademicTest ||--|{ AcademicTestScore : contains
  Student ||--o{ StudySurvey : answers
  StudySurvey ||--|{ SurveySubject : contains
  Student ||--o{ AnalysisResult : receives
  AnalysisResult ||--|{ SubjectAnalysis : contains
  AnalysisResult ||--o{ LearningTendency : classifies
  Student ||--o{ WeeklyStudyPlan : owns
  AnalysisResult ||--o{ WeeklyStudyPlan : drives
  WeeklyStudyPlan ||--o{ StudyPlanItem : contains
  StudyPlanItem ||--o| StudyRecord : records
```

## 4. エンティティ

### Student

| フィールド | 型 | 必須 | 制約 |
| --- | --- | --- | --- |
| `id` | String | ○ | PK、CUID |
| `displayName` | String | ○ | 1〜50文字。ニックネーム推奨 |
| `currentGrade` | GradeLevel | ○ | 現在学年 |
| `juniorHighSchoolName` | String |  | 100文字以内 |
| `createdAt` | DateTime | ○ | 作成日時 |
| `updatedAt` | DateTime | ○ | 更新日時 |

### TargetSchool

| フィールド | 型 | 必須 | 制約 |
| --- | --- | --- | --- |
| `id` | String | ○ | PK、CUID |
| `studentId` | String | ○ | FK → Student、削除時カスケード |
| `schoolName` | String | ○ | 1〜100文字、自由入力 |
| `preferenceRank` | PreferenceRank | ○ | 第1または第2志望 |
| `note` | String |  | 500文字以内 |
| `createdAt` | DateTime | ○ | 作成日時 |
| `updatedAt` | DateTime | ○ | 更新日時 |

制約: `@@unique([studentId, preferenceRank])`。1生徒につき最大2件。

### AcademicTest

| フィールド | 型 | 必須 | 制約 |
| --- | --- | --- | --- |
| `id` | String | ○ | PK、CUID |
| `studentId` | String | ○ | FK → Student、削除時カスケード |
| `name` | String | ○ | 1〜100文字 |
| `takenOn` | DateTime | ○ | 受験日、未来日不可 |
| `gradeAtTest` | GradeLevel | ○ | 受験時学年 |
| `note` | String |  | 500文字以内 |
| `createdAt` | DateTime | ○ | 作成日時 |
| `updatedAt` | DateTime | ○ | 更新日時 |

### AcademicTestScore

| フィールド | 型 | 必須 | 制約 |
| --- | --- | --- | --- |
| `id` | String | ○ | PK、CUID |
| `academicTestId` | String | ○ | FK → AcademicTest、削除時カスケード |
| `subject` | Subject | ○ | 対象教科 |
| `score` | Int | ○ | 0以上、満点以下 |
| `maxScore` | Int | ○ | 1〜500 |

制約: `@@unique([academicTestId, subject])`。AcademicTest保存時に5教科が各1件あることをアプリケーションのトランザクションで保証する。

### StudySurvey

| フィールド | 型 | 必須 | 制約 |
| --- | --- | --- | --- |
| `id` | String | ○ | PK、CUID |
| `studentId` | String | ○ | FK → Student、削除時カスケード |
| `answeredOn` | DateTime | ○ | 回答日、未来日不可 |
| `weekdayAvailableMinutes` | Int | ○ | 平日1日、0〜600分 |
| `weekendAvailableMinutes` | Int | ○ | 休日1日、0〜900分 |
| `concentrationMinutes` | Int | ○ | 1回に集中できる時間、10〜120分 |
| `availableDaysPerWeek` | Int | ○ | 1〜7日 |
| `busyDays` | Json | ○ | 忙しい曜日の配列 |
| `preferredTimeOfDay` | String | ○ | 学びやすい時間帯 |
| `motivationScore` ほか | Float | ○ | 意欲、自信、習慣、解き直し、集中、環境の派生平均 |
| `motivationAnswers` ほか | Json | ○ | 意欲・自信・方法・集中環境の設問別回答 |
| `concern` | String |  | 1000文字以内 |
| `recentAchievement` ほか | String |  | 最近できたこと、不安単元、希望方法、家庭への配慮 |
| `createdAt` | DateTime | ○ | 作成日時 |
| `updatedAt` | DateTime | ○ | 更新日時 |

### SurveySubject

| フィールド | 型 | 必須 | 制約 |
| --- | --- | --- | --- |
| `id` | String | ○ | PK、CUID |
| `studySurveyId` | String | ○ | FK → StudySurvey、削除時カスケード |
| `subject` | Subject | ○ | 対象教科 |
| `weeklyStudyMinutes` | Int | ○ | 直近7日、0〜10080分 |
| `confidenceLevel` | Int | ○ | 自信度、1〜5 |
| `preferenceScore` | Int | ○ | 好き嫌い、1〜5 |
| `difficultyScore` | Int | ○ | 苦手感、1〜5 |
| `easeOfStartingScore` | Int | ○ | 始めやすさ、1〜5 |
| `knowsWhatToStudyScore` | Int | ○ | 学ぶ内容の明確さ、1〜5 |

制約: `@@unique([studySurveyId, subject])`。StudySurvey保存時に5教科が各1件あることを保証する。

### AnalysisResult

| フィールド | 型 | 必須 | 制約 |
| --- | --- | --- | --- |
| `id` | String | ○ | PK、CUID |
| `studentId` | String | ○ | FK → Student、削除時カスケード |
| `latestTestId` | String |  | 使用した最新テスト |
| `previousTestId` | String |  | 使用した直前テスト |
| `surveyId` | String |  | 使用した最新アンケート |
| `status` | AnalysisStatus | ○ | 通常または暫定 |
| `ruleVersion` | String | ○ | `priority-v3` |
| `inputSnapshot` | String | ○ | JSON文字列。使用入力と日時 |
| `summarySnapshot` | Json | ○ | 強み、課題、尺度平均、推奨方法、注意点 |
| `createdAt` | DateTime | ○ | 判定日時 |

最新テストとアンケートが両方ない場合は作成しない。参照元が後から更新・削除されても説明できるよう、必要最小限の入力値をスナップショットに含める。

### SubjectAnalysis

| フィールド | 型 | 必須 | 制約 |
| --- | --- | --- | --- |
| `id` | String | ○ | PK、CUID |
| `analysisResultId` | String | ○ | FK → AnalysisResult、削除時カスケード |
| `subject` | Subject | ○ | 対象教科 |
| `priorityScore` | Int | ○ | 0〜13 |
| `priorityRank` | Int | ○ | 1〜5 |
| `latestScoreRate` | Float |  | 丸め前の得点率 |
| `scoreRateDelta` | Float |  | 前回との差（ポイント） |
| `reasonsSnapshot` | String | ○ | JSON文字列。観点、値、点、説明 |

制約: `@@unique([analysisResultId, subject])`、`@@unique([analysisResultId, priorityRank])`。1分析につき5件。

### LearningTendency

| フィールド | 型 | 必須 | 制約 |
| --- | --- | --- | --- |
| `id` | String | ○ | PK、CUID |
| `analysisResultId` | String | ○ | FK → AnalysisResult、削除時カスケード |
| `tendencyType` | String | ○ | 8タイプの識別子 |
| `score` | Int | ○ | ルール一致点 |
| `evidence` | Json | ○ | 判定根拠の配列 |
| `recommendation` | Json | ○ | 非断定表現と推奨方法 |
| `analyzedAt` | DateTime | ○ | 分析日時 |

### WeeklyStudyPlan

| フィールド | 型 | 必須 | 制約 |
| --- | --- | --- | --- |
| `id` | String | ○ | PK、CUID |
| `studentId` | String | ○ | FK → Student、削除時カスケード |
| `analysisResultId` | String | ○ | FK → AnalysisResult |
| `weekStartOn` | DateTime | ○ | 月曜日の日付 |
| `version` | Int | ○ | 生徒・対象週内で1から連番 |
| `status` | PlanStatus | ○ | DRAFT、CONFIRMED、SUPERSEDED（旧ACTIVEも互換保持） |
| `availableMinutesSnapshot` | Int | ○ | 丸め前の週間可能時間 |
| `plannedMinutes` | Int | ○ | 計画項目の合計 |
| `ruleVersion` | String | ○ | `weekly-plan-v3` |
| `weeklyGoal` | String | ○ | 週間目標 |
| `recommendedDays` | Int | ○ | 推奨学習日数 |
| `recommendedSessionMinutes` | Int | ○ | 1回の推奨時間 |
| `generatedBy` | String | ○ | MVPはRULE |
| `confirmedAt` | DateTime |  | 確定日時 |
| `createdAt` | DateTime | ○ | 作成日時 |

制約: `@@unique([studentId, weekStartOn, version])`。同じ生徒・週のACTIVEはアプリケーショントランザクションで1件にする。

### StudyPlanItem

| フィールド | 型 | 必須 | 制約 |
| --- | --- | --- | --- |
| `id` | String | ○ | PK、CUID |
| `weeklyStudyPlanId` | String | ○ | FK → WeeklyStudyPlan、削除時カスケード |
| `studyOn` | DateTime | ○ | 対象週内の日付 |
| `sequence` | Int | ○ | 同日内の表示順 |
| `subject` | Subject | ○ | 教科 |
| `minutes` | Int | ○ | 10〜120分 |
| `guidance` | String | ○ | 定型の学習方針 |
| `unit` / `purpose` / `activity` | String | ○ | 暫定単元、目的、内容 |
| `problemCount` | Int | ○ | 予定問題数 |
| `difficulty` | String | ○ | BASIC、STANDARD、ADVANCED |
| `studyMethod` | String | ○ | 学習方法 |
| `completionCriteria` | String | ○ | 完了条件 |
| `reason` | String | ○ | 割当・調整理由 |

制約: `@@unique([weeklyStudyPlanId, studyOn, sequence])`。

### StudyRecord

| フィールド | 型 | 必須 | 制約 |
| --- | --- | --- | --- |
| `studyPlanItemId` | String | ○ | StudyPlanItemと1対1 |
| `completed` | Boolean | ○ | 実施したか |
| `actualMinutes` | Int | ○ | 実際の時間 |
| `attemptedCount` / `correctCount` | Int | ○ | 問題数と正答数 |
| `difficultyRating` / `concentrationRating` | Int |  | 1〜5 |
| `retryPreference` | Boolean |  | 再挑戦希望 |
| `mistakeTypes` | Json | ○ | ミス種別の配列 |
| `studentComment` | String |  | 1000文字以内 |

## 5. 並び順と整合性

- 最新テストは `takenOn DESC, createdAt DESC`、最新アンケートは `answeredOn DESC, createdAt DESC` で決める。

## 変更点（学習フロー v3）

- `Student` は `phoneticName`、`residenceArea`、`examYear`、`clubActivity`、`lessons`、`accommodations`、`note` を保持する。変化する得意・苦手や学習時間は保持しない。
- `TargetSchool.departmentName` で第一・第二志望の学科を保持する。
- `StudySurvey` は `currentWeekdayMinutes`、`currentWeekendMinutes`、確保可能時間、`concentrationMinutes`、`availableDays`、`busyDays` を回答ごとに追加保存し、過去回答を上書きしない。
- `StudySurveySubject` は5教科ごとに `selfEvaluationScore`（1=かなり苦手〜5=かなり得意）と `studyFrequencyPerWeek` を保持する。
- `AcademicTestScore` は任意の `averageScore` と `unansweredRate` を保持し、値がある場合だけ分析へ加味する。問題別結果モデルはMVPに存在しないため、問題別正答率はデータ追加後に利用する。
- `SubjectAnalysis` は最近3回の得点率、本人評価、自信、認識区分、説明文をスナップショットとして保持する。
- `WeeklyStudyPlan.analysisResultId` から、生成に使用した分析とその `studySurveyId` を追跡する。
- 同日テストの推移表示は `takenOn ASC, createdAt ASC` とする。
- 親IDと子IDを同時に受け取る操作では、必ず所有関係を検証する。
- 5教科一括保存、生徒の関連削除、計画の版更新はDBトランザクション内で行う。
- JSONスナップショットはZodスキーマと `schemaVersion` を持たせ、読み込み時にも検証する。

## 6. カルテUI追加モデル

- `ProblemProfile`: 生徒と任意の学力テストに属し、教科、単元、出典、設問番号、正誤、無回答、ミス種別配列、メモ、復習対象を保持する。
- `ReviewProfile`: `ProblemProfile` と1対1で、復習状態、次回復習日、連続定着回数を保持する。`ReviewAttempt` を複数持ち、履歴は追記する。
- `TargetSchoolSubjectGoal`: 志望校ごとの5教科目標点を保持する。
- `TargetSchoolHistory`: 志望順位、学校・学科、設定日、コメントの変更履歴を追記する。
- `SubjectAnalysis.priorityUnit`: 問題別結果と復習状況から求めた優先単元を分析スナップショットに残す。
- `AnalysisResult` は再分析時も更新せず追加し、使用した問題ID、復習候補、優先単元をスナップショットへ保存する。

関連の中心は `Student → AcademicTest / StudySurvey / TargetSchool / ProblemProfile → ReviewProfile → ReviewAttempt` とし、`AnalysisResult → WeeklyStudyPlan → StudyPlanItem → StudyRecord` が判断から実施までを追跡する。

## 7. ファイル取り込みモデル

- `UploadedFile`: 学力テストに属する非公開ファイルのメタデータ、ハッシュ、処理・確認状態を保持する。
- `OcrJob → OcrPageResult / OcrExtractedItem`: プロバイダー実行、ページ結果、未確定の項目候補を保持する。
- `ImportSession → ImportCandidateQuestion`: 複数資料を一つの取り込み単位でまとめ、人の修正、正誤候補、対応付け、確定状態を保持する。
- `AuditLog`: ファイル、OCR、候補修正、除外、確定、問題・復習作成の操作種別と最小限のメタデータを保持する。
- `ProblemProfile` は任意の読み取り元ファイル・取り込み候補、問題文、確認者、確認日時を参照する。

`UploadedFile.storagePath` はサーバー内部だけで使用し、画面・URL・監査メタデータには含めない。

## 8. 汎用AI手動解析モデル

- `ManualAiImportSession`: 生徒・テスト・教科・学年、スキーマ版、匿名ID、`importToken`、選択資料、生成プロンプト、原本JSON、検証エラー、状態と各日時を保持する。
- `ManualAiImportQuestion`: AIが返した問題候補を原本列に保存し、人の修正は `correctedData` に分離する。確認状態、確認者、確認日時を持つ。
- `ManualAiImportSummary`: 単元集計と全体分析候補、および確認状態を保持する。
- `ProblemProfile.manualAiImportQuestionId`: 反映元候補を追跡する。反映はセッションが `CONFIRMED` かつ問題が確認済み・修正済みの場合だけ行う。
- 状態遷移は `DRAFT → PROMPT_CREATED → WAITING_FOR_RESULT → RESULT_RECEIVED → REVIEWING → CONFIRMED → IMPORTED` を基本とし、検証失敗と中止を分岐として保持する。

`Student → ManualAiImportSession → ManualAiImportQuestion / ManualAiImportSummary → ProblemProfile → ReviewProfile` の関係とし、原本JSONと修正後データを同一値で上書きしない。

## 9. 類似問題生成・個別問題集モデル

- `ProblemGenerationSession`: 匿名ID、generationToken、教科・学年・単元、元問題、生成条件、プロンプト、raw JSON、検証状態を保持する。
- `GeneratedProblem / GeneratedProblemSource`: 生成候補と元問題の多対多関係、修正前後、プログラム検算、人の確認・承認を保持する。
- `Workbook / WorkbookItem`: 承認済み問題だけを順序付きで配置し、印刷・解答・ヒント・氏名表示設定を保持する。
- `WorkbookAttempt / WorkbookProblemResult`: 実施ごとの時間・自己評価と問題別結果を追記し、作成した `ProblemProfile / ReviewProfile` を追跡する。

## 個人端末版（2026-09-14）

個人端末版ではモデルと分析スナップショットを維持する。DB・添付資料・出力物をcurrent配下にまとめ、バックアップは形式version=1、作成日時、ファイルごとのSHA-256をmanifest.jsonに保存する。設定や個人の絶対パスはバックアップに含めない。
