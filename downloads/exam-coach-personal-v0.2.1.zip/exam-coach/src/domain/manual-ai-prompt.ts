export type ManualAiPromptVariables = {
  studentAnonymousId: string;
  importToken: string;
  testName: string;
  testDate: string;
  grade: string;
  subject: string;
  schemaVersion: string;
};

export function renderManualAiPrompt(template: string, variables: ManualAiPromptVariables): string {
  let result = template;
  for (const [key, value] of Object.entries(variables)) result = result.replaceAll(`{{${key}}}`, value);
  if (/{{[^}]+}}/.test(result)) throw new Error("プロンプトテンプレートに未解決の変数があります。");
  return result;
}
