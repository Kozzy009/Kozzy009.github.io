import type { SubjectKey } from "@/domain/subjects";

export type OcrItem = { pageNumber: number; itemType: string; fieldName: string; rawValue: string; normalizedValue?: string; confidence: number };
export type OcrOutput = { pages: Array<{ pageNumber: number; rawText: string; confidence: number }>; items: OcrItem[]; rawResponse?: Record<string, unknown> };
export interface OcrProvider { extractText(input: { fileType: string; subject: string }): Promise<OcrOutput>; extractPages(): Promise<number[]>; getProviderName(): string; healthCheck(): Promise<boolean> }

const questions = [
  ["1","1","2 + 3","5","2","計算","数と式","CORRECT"], ["1","2","-4 + 7","3","2","計算","数と式","CORRECT"],
  ["1","3","6 × 2","12","2","計算","数と式","CORRECT"], ["2","1","x + 3 = 8","5","3","短答","一次方程式","INCORRECT"],
  ["2","2","2x = 12","6","3","短答","一次方程式","CORRECT"], ["3","1","y = 2x の値","4","4","短答","一次関数","INCORRECT"],
  ["3","2","一次関数の傾き","3","4","短答","一次関数","UNANSWERED"],
] as const;

function qField(major: string, minor: string, field: string) { return `question.${major}.${minor}.${field}`; }
export class MockOcrProvider implements OcrProvider {
  getProviderName() { return "MOCK"; }
  async healthCheck() { return true; }
  async extractPages() { return [1]; }
  async extractText({ fileType }: { fileType: string; subject: string }): Promise<OcrOutput> {
    const items: OcrItem[] = [];
    if (fileType === "SCORE_REPORT") {
      for (const [fieldName, rawValue] of [["testName","モック学力テスト"],["takenOn","2026-07-15"],["grade","JUNIOR_HIGH_3"],["MATH.score","36"],["MATH.averageScore","52.5"],["totalScore","286"],["deviationValue","48.2"],["rank","83"],["examineeCount","210"]]) items.push({ pageNumber: 1, itemType: "SCORE_FIELD", fieldName, rawValue, confidence: 0.86 });
    } else {
      for (const [major,minor,text,correct,score,type,unit,grading] of questions) {
        const common = { pageNumber: 1, confidence: 0.88 };
        if (fileType === "QUESTION_PAPER") {
          items.push({ ...common, itemType:"QUESTION", fieldName:qField(major,minor,"questionText"), rawValue:text }, { ...common, itemType:"QUESTION", fieldName:qField(major,minor,"unit"), rawValue:unit }, { ...common, itemType:"QUESTION", fieldName:qField(major,minor,"questionType"), rawValue:type });
        }
        if (fileType === "STUDENT_ANSWER") items.push({ ...common, confidence: 0.72, itemType:"STUDENT_ANSWER", fieldName:qField(major,minor,"answerText"), rawValue: grading === "UNANSWERED" ? "" : grading === "INCORRECT" ? `${correct}x` : correct });
        if (fileType === "MODEL_ANSWER" || fileType === "EXPLANATION") {
          items.push({ ...common, itemType:"MODEL_ANSWER", fieldName:qField(major,minor,"correctAnswer"), rawValue:correct }, { ...common, itemType:"MODEL_ANSWER", fieldName:qField(major,minor,"score"), rawValue:score });
        }
      }
    }
    return { pages: [{ pageNumber:1, rawText:"モックOCR結果。実ファイル本文は外部送信していません。", confidence:0.85 }], items, rawResponse:{ provider:"MOCK", itemCount:items.length } };
  }
}

export class ManualEntryProvider implements OcrProvider {
  getProviderName() { return "MANUAL"; }
  async healthCheck() { return true; }
  async extractPages() { return []; }
  async extractText(input: { fileType: string; subject: string }): Promise<OcrOutput> { void input; return { pages: [], items: [] }; }
}

export function normalizeAnswer(value: string): string {
  return value.trim().normalize("NFKC").replace(/\s+/g, " ").toLocaleLowerCase("ja-JP");
}

export function gradeCandidate(input: { answerText?: string | null; correctAnswer?: string | null; questionType?: string | null }): "CORRECT"|"INCORRECT"|"UNANSWERED"|"NEEDS_REVIEW"|"UNDETERMINED" {
  if (!input.answerText?.trim()) return "UNANSWERED";
  if (!input.correctAnswer?.trim()) return "UNDETERMINED";
  if (input.questionType && /記述|英作文|作文|数式|単位/.test(input.questionType)) return "NEEDS_REVIEW";
  return normalizeAnswer(input.answerText) === normalizeAnswer(input.correctAnswer) ? "CORRECT" : "INCORRECT";
}

export function parseQuestionField(fieldName: string): { major: string; minor: string; field: string } | null {
  const match = /^question\.([^.]+)\.([^.]+)\.(.+)$/.exec(fieldName);
  return match ? { major: match[1], minor: match[2], field: match[3] } : null;
}

export type CandidateInput = { subject: SubjectKey; major: string; minor: string; values: Record<string,string>; sourceFileIds: string[]; confidence: number };
