import type { AnalysisInput, SubjectPriority } from "./analysis";
import type { LearningSurveyProfile } from "./learning-survey";
import { SUBJECT_LABELS } from "./subjects";

export const LEARNING_TENDENCY_RULE_VERSION = "learning-tendency-v1";

export const TENDENCY_LABELS = {
  NEEDS_METHOD: "意欲はあるが方法を具体化したい",
  LOW_CONFIDENCE: "自信を少しずつ育てたい",
  EFFORT_NOT_CONVERTING: "学習時間を得点につなげたい",
  UNSTABLE_HABIT: "学習習慣を整えたい",
  AVOIDS_WEAK_SUBJECT: "苦手教科へ入りやすくしたい",
  CARELESS_REVIEW: "見直しと解き直しを増やしたい",
  TIME_MANAGEMENT: "時間配分を練習したい",
  STABLE_HABIT: "学習習慣が比較的安定している",
} as const;

export type LearningTendencyType = keyof typeof TENDENCY_LABELS;

export type LearningTendencyResult = {
  tendencyType: LearningTendencyType;
  score: number;
  statement: string;
  evidence: string[];
  recommendations: string[];
};

export type LearningSummary = {
  currentWeeklyMinutes: number;
  weeklyAvailableMinutes: number;
  recommendedSessionMinutes: number;
  recommendedDays: number;
  motivationScore: number;
  confidenceScore: number;
  studyHabitScore: number;
  reviewHabitScore: number;
  concentrationScore: number;
  environmentScore: number;
  strengths: string[];
  challenges: string[];
  recommendedMethods: string[];
  notes: string[];
};

function value(answers: Record<string, number>, key: string): number {
  return answers[key] ?? 0;
}

function averageTrend(input: AnalysisInput): number | null {
  if (!input.currentScores || !input.previousScores) return null;
  const previous = new Map(input.previousScores.map((score) => [score.subject, score]));
  const deltas = input.currentScores.flatMap((score) => {
    const before = previous.get(score.subject);
    return before ? [(score.score / score.maxScore) * 100 - (before.score / before.maxScore) * 100] : [];
  });
  return deltas.length ? deltas.reduce((sum, delta) => sum + delta, 0) / deltas.length : null;
}

function make(
  tendencyType: LearningTendencyType,
  score: number,
  evidence: string[],
  recommendations: string[],
): LearningTendencyResult {
  const statement = tendencyType === "LOW_CONFIDENCE"
    ? "最近の結果では、基礎問題から成功体験を積む方法が合っていると考えられます"
    : `現在の回答と成績から、${TENDENCY_LABELS[tendencyType]}可能性があります`;
  return { tendencyType, score, statement, evidence, recommendations };
}

export function analyzeLearningTendencies(
  survey: LearningSurveyProfile | null,
  scores: AnalysisInput,
): LearningTendencyResult[] {
  if (!survey) return [];
  const method = survey.studyMethodAnswers;
  const motivation = survey.motivationAnswers;
  const concentration = survey.concentrationAnswers;
  const trend = averageTrend(scores);
  const totalStudy = survey.subjects.reduce((sum, subject) => sum + subject.weeklyStudyMinutes, 0);
  const hasAvoidedSubject = survey.subjects.some((subject) =>
    subject.selfEvaluationScore <= 2 && subject.easeOfStartingScore <= 2 && subject.weeklyStudyMinutes <= totalStudy / 10,
  );
  const results: LearningTendencyResult[] = [];

  let points = 0;
  const methodEvidence: string[] = [];
  if (survey.motivationScore >= 3.8) { points += 2; methodEvidence.push("学習への意欲が高い"); }
  if (value(method, "planBeforeTests") <= 2) { points += 1; methodEvidence.push("計画づくりはこれから伸ばせる"); }
  if (value(method, "reviewMistakes") <= 2) { points += 1; methodEvidence.push("解き直しの手順を具体化できる"); }
  if (survey.subjects.some((subject) => subject.knowsWhatToStudyScore <= 2)) { points += 2; methodEvidence.push("学ぶ内容が分かりにくい教科がある"); }
  if (points >= 3) results.push(make("NEEDS_METHOD", points, methodEvidence, ["教科・内容・問題数を毎回示す", "1回15〜25分で基礎問題と解き直しを行う"]));

  points = 0;
  const confidenceEvidence: string[] = [];
  if (survey.confidenceScore < 2.8) { points += 3; confidenceEvidence.push("学習への自信の平均が低め"); }
  if (survey.subjects.some((subject) => subject.confidenceLevel <= 2)) { points += 2; confidenceEvidence.push("自信が低い教科がある"); }
  if (trend !== null && trend < -2) { points += 2; confidenceEvidence.push("最近の得点率が全体に下降傾向"); }
  if (points >= 3) results.push(make("LOW_CONFIDENCE", points, confidenceEvidence, ["1回10〜15分・3〜5問から始める", "正答率70〜80%程度の基礎問題を中心にする"]));

  points = 0;
  const effortEvidence: string[] = [];
  if (totalStudy >= 300) { points += 2; effortEvidence.push(`直近7日で合計${totalStudy}分学習している`); }
  if (trend !== null && trend <= 1) { points += 2; effortEvidence.push("最近の得点率が横ばいまたは下降している"); }
  if (value(method, "solveProblems") <= 2) { points += 2; effortEvidence.push("問題演習を増やせる"); }
  if (value(method, "timedPractice") <= 2) { points += 1; effortEvidence.push("時間を測る練習が少ない"); }
  if (points >= 4) results.push(make("EFFORT_NOT_CONVERTING", points, effortEvidence, ["学習時間の60%以上を問題演習にする", "週1回は時間を測った確認問題を行う"]));

  points = 0;
  const habitEvidence: string[] = [];
  if (survey.availableDaysPerWeek <= 3) { points += 2; habitEvidence.push("学習できる日数が週3日以下"); }
  if (value(motivation, "selfStart") <= 2) { points += 2; habitEvidence.push("自分から始めるきっかけが必要"); }
  if (value(concentration, "independentStart") <= 2) { points += 1; habitEvidence.push("始める合図を固定するとよい"); }
  if (points >= 3) results.push(make("UNSTABLE_HABIT", points, habitEvidence, ["同じ時間帯に10〜15分から始める", "毎日ではなく週3回の実施回数を目標にする"]));

  if (hasAvoidedSubject) results.push(make("AVOIDS_WEAK_SUBJECT", 5, ["苦手感が強く、取り組み時間が少ない教科がある"], ["苦手教科は2〜3問の短時間にする", "得意教科と同じ日に組み合わせる"]));

  points = 0;
  const reviewEvidence: string[] = [];
  if (value(method, "reviewMistakes") <= 2) { points += 2; reviewEvidence.push("間違い直しが少ない"); }
  if (value(method, "repeatProblems") <= 2) { points += 1; reviewEvidence.push("同じ問題の再確認が少ない"); }
  if (trend !== null && trend <= 0) { points += 1; reviewEvidence.push("得点率が上向いていない"); }
  if (points >= 3) results.push(make("CARELESS_REVIEW", points, reviewEvidence, ["解答と見直しの時間を分ける", "誤答原因を記録して翌日に解き直す"]));

  points = value(method, "timedPractice") <= 2 ? 3 : 0;
  if (points >= 3) results.push(make("TIME_MANAGEMENT", points, ["時間を測る問題演習が少ない"], ["週1〜2回の時間制限問題を入れる", "最後に見直し時間を確保する"]));

  points = 0;
  const stableEvidence: string[] = [];
  if (survey.availableDaysPerWeek >= 5) { points += 2; stableEvidence.push("週5日以上学習できる"); }
  if (value(method, "reviewMistakes") >= 4) { points += 2; stableEvidence.push("解き直しの習慣がある"); }
  if (value(motivation, "selfStart") >= 4) { points += 2; stableEvidence.push("自分から始められる"); }
  if (trend !== null && trend >= 0) { points += 1; stableEvidence.push("成績が維持または上昇している"); }
  if (points >= 5) results.push(make("STABLE_HABIT", points, stableEvidence, ["入試形式と応用問題を段階的に増やす", "週単位の目標点を決める"]));

  return results.sort((a, b) => b.score - a.score).slice(0, 4);
}

export function buildLearningSummary(
  survey: LearningSurveyProfile | null,
  priorities: SubjectPriority[],
  tendencies: LearningTendencyResult[],
): LearningSummary | null {
  if (!survey) return null;
  const lowConfidence = survey.confidenceScore < 2.8;
  const lowMotivation = survey.motivationScore < 2.8;
  const recommendedSessionMinutes = Math.min(
    survey.concentrationMinutes,
    lowConfidence || lowMotivation ? 15 : survey.confidenceScore >= 4 ? 30 : 25,
  );
  const recommendedDays = Math.min(survey.availableDaysPerWeek, lowMotivation ? 3 : 7);
  const strengths: string[] = [];
  const challenges: string[] = [];
  if (value(survey.motivationAnswers, "targetSchool") >= 4) strengths.push("志望校への意欲が高い");
  if (survey.weekendAvailableMinutes >= 60) strengths.push("休日に学習時間を確保できる");
  if (value(survey.studyMethodAnswers, "readExplanations") >= 4) strengths.push("問題の解説を読む習慣がある");
  for (const priority of priorities.filter((item) => (item.scoreRateDelta ?? 0) > 2)) strengths.push(`${SUBJECT_LABELS[priority.subject]}の成績が上昇している`);
  if (survey.reviewHabitScore < 3) challenges.push("間違い直しの習慣を増やせる");
  if (survey.concentrationMinutes < 20) challenges.push("短い学習時間に区切ると集中しやすい");
  const avoided = survey.subjects.find((subject) => subject.selfEvaluationScore <= 2 && subject.easeOfStartingScore <= 2);
  if (avoided) challenges.push(`${SUBJECT_LABELS[avoided.subject]}を後回しにしやすい傾向がある`);
  const declining = priorities.find((item) => (item.scoreRateDelta ?? 0) <= -5);
  if (declining) challenges.push(`${SUBJECT_LABELS[declining.subject]}の得点率が前回より下降している`);
  return {
    currentWeeklyMinutes: survey.currentWeekdayMinutes * 5 + survey.currentWeekendMinutes * 2,
    weeklyAvailableMinutes: survey.availableDays.reduce((sum, day) => sum + (["SAT", "SUN"].includes(day) ? survey.weekendAvailableMinutes : survey.weekdayAvailableMinutes), 0),
    recommendedSessionMinutes: Math.max(10, recommendedSessionMinutes),
    recommendedDays: Math.max(1, recommendedDays),
    motivationScore: survey.motivationScore,
    confidenceScore: survey.confidenceScore,
    studyHabitScore: survey.studyHabitScore,
    reviewHabitScore: survey.reviewHabitScore,
    concentrationScore: survey.concentrationScore,
    environmentScore: survey.environmentScore,
    strengths: strengths.length ? strengths : ["アンケートに回答し、自分の学び方を振り返れている"],
    challenges: challenges.length ? challenges : ["次のテスト結果と実施記録を追加すると、より具体的に調整できる"],
    recommendedMethods: tendencies.flatMap((item) => item.recommendations).slice(0, 5),
    notes: ["単元別・問題別の正誤データがないため、優先単元は暫定です", "学力テストや実施記録の追加後に再分析してください"],
  };
}
