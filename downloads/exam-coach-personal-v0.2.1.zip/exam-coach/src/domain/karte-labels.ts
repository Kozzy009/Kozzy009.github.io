export const MISTAKE_LABELS: Record<string, string> = {
  KNOWLEDGE: "知識不足", METHOD: "解法未理解", MISREAD: "問題文の読み違い", CALCULATION: "計算ミス", UNIT: "単位ミス",
  DESCRIPTION: "記述不足", TIME: "時間不足", CARELESS: "ケアレスミス", UNANSWERED: "無回答", OUT_OF_SCOPE: "学習範囲外",
  UNKNOWN: "判定不能", OTHER: "その他",
};
export const REVIEW_STATUS_LABELS: Record<string, string> = { NOT_STARTED: "未着手", SCHEDULED: "復習予定", IN_PROGRESS: "復習中", CHECKING: "定着確認中", STABLE: "一旦定着", RECHECK_NEEDED: "再確認が必要" };
export const TIME_LABELS: Record<string, string> = { MORNING: "朝", AFTER_SCHOOL: "放課後", EVENING: "夕方", NIGHT: "夜" };
export const DAY_LABELS: Record<string, string> = { MON: "月", TUE: "火", WED: "水", THU: "木", FRI: "金", SAT: "土", SUN: "日" };
export const SELF_EVALUATION_LABELS: Record<number, string> = { 1: "かなり苦手", 2: "やや苦手", 3: "どちらともいえない", 4: "やや得意", 5: "かなり得意" };
