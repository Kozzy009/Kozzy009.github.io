export const REVIEW_INTERVAL_DAYS = [1, 3, 7, 14, 30] as const;

export type ReviewStatus = "NOT_STARTED" | "SCHEDULED" | "IN_PROGRESS" | "CHECKING" | "STABLE" | "RECHECK_NEEDED";

export function addCalendarDays(date: Date, days: number): Date {
  const next = new Date(date);
  next.setDate(next.getDate() + days);
  return next;
}

export function initialReviewDate(attemptedOn: Date, stage = 0): Date {
  return addCalendarDays(attemptedOn, REVIEW_INTERVAL_DAYS[Math.min(Math.max(stage, 0), REVIEW_INTERVAL_DAYS.length - 1)]);
}

export function nextReviewSchedule(args: { reviewedOn: Date; isCorrect: boolean; consecutiveCorrect: number }): { nextReviewOn: Date; consecutiveCorrect: number; status: ReviewStatus } {
  if (!args.isCorrect) {
    return { nextReviewOn: addCalendarDays(args.reviewedOn, 1), consecutiveCorrect: 0, status: "RECHECK_NEEDED" };
  }
  const consecutiveCorrect = args.consecutiveCorrect + 1;
  const intervalIndex = Math.min(consecutiveCorrect, REVIEW_INTERVAL_DAYS.length - 1);
  return {
    nextReviewOn: addCalendarDays(args.reviewedOn, REVIEW_INTERVAL_DAYS[intervalIndex]),
    consecutiveCorrect,
    status: consecutiveCorrect >= 4 ? "STABLE" : consecutiveCorrect >= 2 ? "CHECKING" : "IN_PROGRESS",
  };
}
