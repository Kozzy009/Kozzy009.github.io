import { guidanceFor, type SubjectPriority } from "./analysis";
import type { LearningSurveyProfile } from "./learning-survey";
import type { LearningTendencyResult, LearningTendencyType } from "./learning-analysis";
import { SUBJECT_LABELS, type SubjectKey } from "./subjects";

export const PLAN_RULE_VERSION = "weekly-plan-v3";

export type PlanDifficulty = "BASIC" | "STANDARD" | "ADVANCED";

export type PreviousWeekPerformance = {
  completionRate: number;
  correctRate: number | null;
  averageTimeRatio: number | null;
  concentrationAverage: number | null;
  recurringMistakes: boolean;
};

export type PlanItemDraft = {
  dayOffset: number;
  sequence: number;
  subject: SubjectKey;
  durationMinutes: number;
  unit: string;
  purpose: string;
  activity: string;
  problemCount: number;
  difficulty: PlanDifficulty;
  studyMethod: string;
  completionCriteria: string;
  guidance: string;
  reason: string;
};

export type StudyPlanDraft = {
  weeklyGoal: string;
  recommendedDays: number;
  recommendedSessionMinutes: number;
  focusSubjects: SubjectKey[];
  availableMinutes: number;
  plannedMinutes: number;
  unallocatedMinutes: number;
  adjustments: string[];
  items: PlanItemDraft[];
};

export interface StudyPlanGenerator {
  generate(args: StudyPlanGeneratorInput): StudyPlanDraft;
}

export type StudyPlanGeneratorInput = {
  priorities: SubjectPriority[];
  survey?: LearningSurveyProfile;
  tendencies?: LearningTendencyResult[];
  previousWeek?: PreviousWeekPerformance | null;
  weekdayAvailableMinutes?: number;
  weekendAvailableMinutes?: number;
  priorityUnits?: Partial<Record<SubjectKey, string>>;
  dueReviews?: Array<{ subject: SubjectKey; unit: string }>;
};

function hasType(tendencies: LearningTendencyResult[], type: LearningTendencyType): boolean {
  return tendencies.some((item) => item.tendencyType === type);
}

function availableForDay(survey: LearningSurveyProfile, dayOffset: number): number {
  return dayOffset < 5 ? survey.weekdayAvailableMinutes : survey.weekendAvailableMinutes;
}

function selectDays(survey: LearningSurveyProfile, recommendedDays: number): number[] {
  const keys = ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"];
  const selected = survey.availableDays.length ? survey.availableDays : keys;
  return keys.map((key, index) => ({ key, index }))
    .filter(({ key }) => selected.includes(key as never) && !survey.busyDays.includes(key as never))
    .map(({ index }) => index)
    .slice(0, recommendedDays);
}

function subjectSequence(priorities: SubjectPriority[], count: number, limited: boolean): SubjectKey[] {
  if (count === 0) return [];
  const focus = priorities.slice(0, 2);
  const strongest = [...priorities].sort((a, b) => (b.latestScoreRate ?? -1) - (a.latestScoreRate ?? -1))[0];
  const candidates = limited
    ? [...focus, ...(strongest && !focus.some((item) => item.subject === strongest.subject) ? [strongest] : [])]
    : priorities;
  const maxFirst = Math.max(1, Math.floor(count * 0.4));
  const maxSecond = Math.max(1, Math.floor(count * 0.3));
  const counts = new Map<SubjectKey, number>();
  const result: SubjectKey[] = [];
  if (strongest && count >= 5) {
    result.push(strongest.subject);
    counts.set(strongest.subject, 1);
  }
  while (result.length < count) {
    const sorted = candidates
      .map((priority) => ({
        priority,
        count: counts.get(priority.subject) ?? 0,
        ratio: (counts.get(priority.subject) ?? 0) / Math.max(1, result.length),
      }))
      .filter(({ priority, count: used }) => {
        if (priority.priorityRank === 1 && used >= maxFirst) return false;
        if (priority.priorityRank === 2 && used >= maxSecond) return false;
        return true;
      })
      .sort((a, b) => a.ratio - b.ratio || b.priority.priorityScore - a.priority.priorityScore || a.priority.priorityRank - b.priority.priorityRank);
    const selected = sorted[0]?.priority ?? candidates[result.length % candidates.length];
    result.push(selected.subject);
    counts.set(selected.subject, (counts.get(selected.subject) ?? 0) + 1);
  }
  return result;
}

function buildItem(args: {
  priority: SubjectPriority;
  dayOffset: number;
  sequence: number;
  duration: number;
  confidence: number;
  tendencies: LearningTendencyResult[];
  previousWeek?: PreviousWeekPerformance | null;
  unitFocus?: string | null;
}): PlanItemDraft {
  const { priority, confidence, tendencies, previousWeek } = args;
  let difficulty: PlanDifficulty = confidence < 3 ? "BASIC" : confidence >= 4 ? "STANDARD" : "BASIC";
  let problemCount = confidence < 3 ? 4 : confidence >= 4 ? Math.max(8, Math.floor(args.duration / 3)) : Math.max(5, Math.floor(args.duration / 4));
  const reasons: string[] = [`優先度${priority.priorityRank}位・${priority.priorityScore}点`];
  const recentTrend = priority.recentScoreRates.length >= 3
    ? priority.recentScoreRates[priority.recentScoreRates.length - 1] - priority.recentScoreRates[0]
    : null;
  if (recentTrend !== null && recentTrend <= -5) {
    difficulty = "BASIC";
    problemCount = Math.min(problemCount, 5);
    reasons.push(`最近3回で${Math.abs(recentTrend).toFixed(1)}ポイント下降しているため基礎量を調整`);
  }
  if (previousWeek?.correctRate !== null && previousWeek?.correctRate !== undefined) {
    if (previousWeek.correctRate >= 0.8) { difficulty = difficulty === "BASIC" ? "STANDARD" : "ADVANCED"; reasons.push("前週の正答率が80%以上"); }
    if (previousWeek.correctRate < 0.5) { difficulty = "BASIC"; reasons.push("前週の正答率が50%未満"); }
  }
  if (previousWeek?.averageTimeRatio && previousWeek.averageTimeRatio > 1.15) {
    problemCount = Math.max(3, problemCount - 2);
    reasons.push("前週は予定時間を超える傾向");
  }
  const review = hasType(tendencies, "CARELESS_REVIEW") || previousWeek?.recurringMistakes;
  const timed = hasType(tendencies, "TIME_MANAGEMENT") || hasType(tendencies, "EFFORT_NOT_CONVERTING");
  const lowConfidence = hasType(tendencies, "LOW_CONFIDENCE") || confidence < 3;
  const unit = priority.priorityRank <= 2
    ? args.unitFocus?.trim() || "基礎・前回の誤答（優先単元は暫定）"
    : "既習範囲の確認";
  const activity = review
    ? `基礎問題${problemCount}問と前回の間違い直し`
    : `${difficulty === "BASIC" ? "基礎" : difficulty === "STANDARD" ? "標準" : "応用"}問題${problemCount}問`;
  const studyMethod = timed
    ? "時間を測って解き、最後の3分で見直す"
    : review
      ? "途中式や根拠を書き、答え合わせ後に誤答原因を選ぶ"
      : "1問ずつ答え合わせし、解説を読んでから次へ進む";
  return {
    dayOffset: args.dayOffset,
    sequence: args.sequence,
    subject: priority.subject,
    durationMinutes: args.duration,
    unit,
    purpose: lowConfidence ? "解ける問題から成功体験をつくる" : review ? "同じ間違いを減らす" : "得点につながる解き方を定着させる",
    activity,
    problemCount,
    difficulty,
    studyMethod,
    completionCriteria: `${problemCount}問に取り組み、間違えた問題へ印を付ける`,
    guidance: guidanceFor(priority),
    reason: reasons.join("／"),
  };
}

export const ruleBasedStudyPlanGenerator: StudyPlanGenerator = {
  generate(args) {
    if (args.priorities.length !== 5) throw new Error("学習計画には5教科の優先度が必要です。");
    const fallbackSurvey: LearningSurveyProfile = {
      currentWeekdayMinutes: 0,
      currentWeekendMinutes: 0,
      weekdayAvailableMinutes: args.weekdayAvailableMinutes ?? 0,
      weekendAvailableMinutes: args.weekendAvailableMinutes ?? 0,
      concentrationMinutes: 30,
      availableDaysPerWeek: 7,
      availableDays: ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"],
      busyDays: [],
      preferredTimeOfDay: "EVENING",
      anxiousSubjectsUnits: null,
      motivationAnswers: {}, confidenceAnswers: {}, studyMethodAnswers: {}, concentrationAnswers: {},
      motivationScore: 3, confidenceScore: 3, studyHabitScore: 3, reviewHabitScore: 3, concentrationScore: 3, environmentScore: 3,
      subjects: args.priorities.map((priority) => ({ subject: priority.subject, weeklyStudyMinutes: 0, confidenceLevel: 3, selfEvaluationScore: 3, studyFrequencyPerWeek: 0, preferenceScore: 3, difficultyScore: 3, easeOfStartingScore: 3, knowsWhatToStudyScore: 3 })),
    };
    const survey = args.survey ?? fallbackSurvey;
    const tendencies = args.tendencies ?? [];
    const lowConfidence = survey.confidenceScore < 2.8 || hasType(tendencies, "LOW_CONFIDENCE");
    const lowMotivation = survey.motivationScore < 2.8;
    const availableMinutes = survey.availableDays.reduce(
      (sum, day) => sum + (["SAT", "SUN"].includes(day) ? survey.weekendAvailableMinutes : survey.weekdayAvailableMinutes),
      0,
    );
    const limited = availableMinutes < 180;
    let recommendedDays = Math.min(survey.availableDaysPerWeek, lowMotivation ? 3 : 7);
    const adjustments: string[] = [];
    if (args.previousWeek && args.previousWeek.completionRate < 0.5) {
      recommendedDays = Math.max(1, recommendedDays - 1);
      adjustments.push("前週の完了率が50%未満のため、学習日を1日減らしました");
    }
    recommendedDays = Math.max(1, recommendedDays);
    const confidenceCap = lowConfidence ? 15 : survey.confidenceScore >= 4 ? 40 : 25;
    const recommendedSessionMinutes = Math.max(10, Math.min(survey.concentrationMinutes, confidenceCap));
    const days = selectDays(survey, recommendedDays).filter((day) => availableForDay(survey, day) >= 10);
    const sessionsPerDay = lowConfidence || lowMotivation ? 1 : 2;
    let sessionCount = days.reduce((sum, day) => sum + Math.min(sessionsPerDay, Math.floor(availableForDay(survey, day) / recommendedSessionMinutes)), 0);
    if (args.previousWeek && args.previousWeek.completionRate < 0.5) sessionCount = Math.max(1, Math.floor(sessionCount * 0.7));
    const subjects = subjectSequence(args.priorities, sessionCount, limited);
    if (hasType(tendencies, "CARELESS_REVIEW") && subjects.length >= 2) subjects[1] = args.priorities[0].subject;
    const priorityMap = new Map(args.priorities.map((item) => [item.subject, item]));
    const feelingMap = new Map(survey.subjects.map((item) => [item.subject, item]));
    const items: PlanItemDraft[] = [];
    let cursor = 0;
    for (const dayOffset of days) {
      const dailyLimit = availableForDay(survey, dayOffset);
      let dailyUsed = 0;
      for (let sequence = 1; sequence <= sessionsPerDay && cursor < subjects.length; sequence += 1) {
        const remaining = dailyLimit - dailyUsed;
        if (remaining < 10) break;
        const duration = Math.min(recommendedSessionMinutes, remaining);
        const subject = subjects[cursor++];
        const priority = priorityMap.get(subject);
        if (!priority) continue;
        const dueReview = args.dueReviews?.find((review) => review.subject === subject);
        const unitFocus = dueReview?.unit ?? args.priorityUnits?.[subject] ?? (priority.priorityRank <= 2 ? survey.anxiousSubjectsUnits : null);
        const item = buildItem({ priority, dayOffset, sequence, duration, confidence: Math.min(feelingMap.get(subject)?.confidenceLevel ?? survey.confidenceScore, survey.confidenceScore), tendencies, previousWeek: args.previousWeek, unitFocus });
        if (dueReview) {
          item.activity = `前回間違えた${dueReview.unit}の解き直しと確認問題${Math.max(3, item.problemCount - 1)}問`;
          item.reason = `${item.reason}／前回間違えた${dueReview.unit}の復習予定日が到来しているため`;
        } else if (args.priorityUnits?.[subject]) {
          item.reason = `${item.reason}／問題カルテで${args.priorityUnits[subject]}の誤答が確認されたため`;
        }
        items.push(item);
        dailyUsed += duration;
      }
      if (cursor >= subjects.length) break;
    }
    const plannedMinutes = items.reduce((sum, item) => sum + item.durationMinutes, 0);
    if (limited) adjustments.push("週間時間が少ないため、優先教科は最大2教科に絞り、得意教科を習慣維持用に加えました");
    if (lowConfidence) adjustments.push("自信に合わせ、1回10〜15分・3〜5問程度を中心にしました");
    if (survey.currentWeekdayMinutes < survey.weekdayAvailableMinutes || survey.currentWeekendMinutes < survey.weekendAvailableMinutes) adjustments.push("現在の学習時間から無理なく増やせるよう、集中できる時間単位で計画しました");
    if (survey.busyDays.length) adjustments.push("忙しい曜日は原則として計画日から外しました");
    return {
      weeklyGoal: `${SUBJECT_LABELS[args.priorities[0].subject]}を中心に、短い問題演習と解き直しを続ける`,
      recommendedDays: days.length,
      recommendedSessionMinutes,
      focusSubjects: args.priorities.slice(0, limited ? 2 : 3).map((item) => item.subject),
      availableMinutes,
      plannedMinutes,
      unallocatedMinutes: Math.max(0, availableMinutes - plannedMinutes),
      adjustments,
      items,
    };
  },
};

export function generateStudyPlan(args: StudyPlanGeneratorInput): StudyPlanDraft {
  return ruleBasedStudyPlanGenerator.generate(args);
}
