const LOOPBACK_HOSTS = new Set(["localhost", "127.0.0.1", "[::1]"]);

export function isLocalRequest(host: string | null, origin: string | null, fetchSite: string | null) {
  if (!host || fetchSite === "cross-site") return false;
  try {
    const target = new URL(`http://${host}`);
    if (!LOOPBACK_HOSTS.has(target.hostname) || target.host !== host || target.username || target.password) return false;
    if (origin) {
      const source = new URL(origin);
      if (source.protocol !== "http:" || source.host !== target.host || source.origin !== origin) return false;
    }
    return true;
  } catch { return false; }
}
