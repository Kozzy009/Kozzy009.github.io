import { z } from "zod";

export const PROBLEM_GENERATION_SCHEMA_VERSION = "1.0";
export const GENERATION_LEVELS = ["BASIC","SIMILAR","STANDARD","EXAM_STYLE","ADVANCED"] as const;
export const GENERATED_DIFFICULTIES = ["BASIC","STANDARD","ADVANCED","UNKNOWN"] as const;
export const GENERATED_QUESTION_TYPES = ["CALCULATION","MULTIPLE_CHOICE","SHORT_ANSWER","WRITTEN_RESPONSE","PROOF","GRAPH","TABLE_READING","EXPERIMENT","ENGLISH_COMPOSITION","READING_COMPREHENSION","OTHER"] as const;
export const GENERATED_REVIEW_STATUSES = ["UNREVIEWED","NEEDS_REVIEW","CONFIRMED","CORRECTED","REJECTED","UNDETERMINED"] as const;

const sourceSimilaritySchema = z.object({
  commonKnowledge:z.array(z.string().max(300)).max(20), commonMethod:z.array(z.string().max(300)).max(20),
  changedConditions:z.array(z.string().max(500)).min(1).max(20), difficultyDifference:z.string().max(1000),
}).strict();

export const generatedProblemSchema = z.object({
  problemId:z.string().min(1).max(100), sourceProblemIds:z.array(z.string().min(1)).min(1).max(30), level:z.enum(GENERATION_LEVELS),
  field:z.string().min(1).max(100), unit:z.string().min(1).max(100), subUnit:z.string().max(100).nullable(), questionType:z.enum(GENERATED_QUESTION_TYPES),
  difficulty:z.enum(GENERATED_DIFFICULTIES), questionText:z.string().min(1).max(10000), choices:z.array(z.string().min(1).max(2000)).max(12),
  hasVisual:z.boolean(), visualDescription:z.string().max(3000).nullable(), points:z.number().int().min(0).max(100).nullable(), estimatedMinutes:z.number().int().min(0).max(180).nullable(),
  hint:z.string().max(3000).nullable(), correctAnswer:z.string().min(1).max(5000), alternativeAnswers:z.array(z.string().max(2000)).max(20), solutionSteps:z.array(z.string().max(2000)).max(30),
  explanation:z.string().max(10000), scoringCriteria:z.array(z.string().max(2000)).max(30), requiredKnowledge:z.array(z.string().max(500)).max(30), commonMistakes:z.array(z.string().max(500)).max(30),
  sourceSimilarity:sourceSimilaritySchema, validationNotes:z.array(z.string().max(2000)).max(30), confidence:z.number().int().min(0).max(100), needsHumanReview:z.boolean(), reviewReason:z.string().max(3000).nullable(),
}).strict().superRefine((problem,ctx)=>{
  if(problem.questionType==="MULTIPLE_CHOICE"){
    if(problem.choices.length<2)ctx.addIssue({code:"custom",path:["choices"],message:"選択式には2件以上の選択肢が必要です"});
    if(!problem.choices.includes(problem.correctAnswer))ctx.addIssue({code:"custom",path:["correctAnswer"],message:"正答が選択肢に含まれていません"});
  }
  if(["WRITTEN_RESPONSE","PROOF","ENGLISH_COMPOSITION"].includes(problem.questionType)&&problem.scoringCriteria.length===0)ctx.addIssue({code:"custom",path:["scoringCriteria"],message:"記述・証明・英作文には採点基準が必要です"});
  if(problem.hasVisual&&!problem.visualDescription)ctx.addIssue({code:"custom",path:["visualDescription"],message:"図表ありの場合は図表説明が必要です"});
});

export const problemGenerationPayloadSchema=z.object({
  schemaVersion:z.literal(PROBLEM_GENERATION_SCHEMA_VERSION),studentAnonymousId:z.string().min(1),generationToken:z.string().min(1),
  subject:z.enum(["JAPANESE","MATH","ENGLISH","SCIENCE","SOCIAL_STUDIES"]),grade:z.enum(["JUNIOR_HIGH_1","JUNIOR_HIGH_2","JUNIOR_HIGH_3"]),unit:z.string().min(1),
  generationSummary:z.object({sourceProblemCount:z.number().int().min(0),generatedProblemCount:z.number().int().min(0),studyPurpose:z.array(z.string()),estimatedTotalMinutes:z.number().int().min(0).nullable(),limitations:z.array(z.string())}).strict(),
  problems:z.array(generatedProblemSchema).max(100),
}).strict().superRefine((value,ctx)=>{const seen=new Set<string>();value.problems.forEach((p,i)=>{if(seen.has(p.problemId))ctx.addIssue({code:"custom",path:["problems",i,"problemId"],message:"problemIdが重複しています"});seen.add(p.problemId);});if(value.generationSummary.generatedProblemCount!==value.problems.length)ctx.addIssue({code:"custom",path:["generationSummary","generatedProblemCount"],message:"生成問題数とproblemsの件数が一致しません"});});

export type GeneratedProblemInput=z.infer<typeof generatedProblemSchema>;
export type ProblemGenerationPayload=z.infer<typeof problemGenerationPayloadSchema>;
export type ProblemGenerationExpected={studentAnonymousId:string;generationToken:string;subject:string;grade:string;unit:string;schemaVersion:string;sourceProblemIds:string[];requestedTotal:number};
export type ProblemGenerationValidation={success:true;data:ProblemGenerationPayload;normalizedJson:string}|{success:false;errors:string[];normalizedJson?:string};

export function stripJsonFence(input:string){const trimmed=input.trim();const match=/^```(?:json)?\s*\r?\n([\s\S]*?)\r?\n```$/i.exec(trimmed);if(match)return match[1].trim();if(trimmed.startsWith("```")||trimmed.endsWith("```"))throw new Error("JSONコードブロックの前後に説明文を含めないでください");return trimmed;}
function issueMessage(issue:z.core.$ZodIssue){const path=issue.path.map(String);const index=path[0]==="problems"&&/^\d+$/.test(path[1]??"")?Number(path[1])+1:null;const location=index?`${index}番目の問題${path[2]?`の${path[2]}`:""}`:path.join(".")||"JSON全体";if(path.at(-1)==="confidence")return `${location}は0～100の整数で入力してください`;if(path.at(-1)==="level")return `${location}のlevelが不正です`;return `${location}: ${issue.message}`;}
export function validateProblemGenerationJson(raw:string,expected:ProblemGenerationExpected):ProblemGenerationValidation{let normalizedJson:string,value:unknown;try{normalizedJson=stripJsonFence(raw);value=JSON.parse(normalizedJson);}catch(error){return{success:false,errors:[error instanceof Error&&error.message.includes("コードブロック")?error.message:"JSON形式が正しくありません"]};}const parsed=problemGenerationPayloadSchema.safeParse(value);if(!parsed.success)return{success:false,normalizedJson,errors:parsed.error.issues.map(issueMessage)};const errors:string[]=[];if(parsed.data.studentAnonymousId!==expected.studentAnonymousId)errors.push("生徒IDが生成依頼と一致しません");if(parsed.data.generationToken!==expected.generationToken)errors.push("generationTokenが生成依頼と一致しません");if(parsed.data.subject!==expected.subject)errors.push("教科が生成依頼と一致しません");if(parsed.data.grade!==expected.grade)errors.push("学年が生成依頼と一致しません");if(parsed.data.unit!==expected.unit)errors.push("単元が生成依頼と一致しません");if(parsed.data.schemaVersion!==expected.schemaVersion)errors.push("未対応のスキーマバージョンです");const allowed=new Set(expected.sourceProblemIds);parsed.data.problems.forEach((p,i)=>p.sourceProblemIds.forEach(id=>{if(!allowed.has(id))errors.push(`${i+1}番目の問題のsourceProblemIdsに依頼外の問題があります`);}));if(Math.abs(parsed.data.problems.length-expected.requestedTotal)>1)errors.push(`生成問題数が依頼数（${expected.requestedTotal}問）と大きく異なります`);return errors.length?{success:false,normalizedJson,errors}:{success:true,normalizedJson,data:parsed.data};}

export function initialGeneratedReviewStatus(problem:GeneratedProblemInput):"UNREVIEWED"|"NEEDS_REVIEW"{const riskyType=["WRITTEN_RESPONSE","PROOF","ENGLISH_COMPOSITION"].includes(problem.questionType);return problem.confidence<80||problem.needsHumanReview||problem.hasVisual||riskyType||problem.alternativeAnswers.length>0||problem.scoringCriteria.length>0||problem.validationNotes.length>0?"NEEDS_REVIEW":"UNREVIEWED";}

export function verifyMathProblem(problem:Pick<GeneratedProblemInput,"questionType"|"questionText"|"correctAnswer">):{status:"VERIFIED"|"FAILED"|"NEEDS_REVIEW";notes:string[]}{
  if(problem.questionType!=="CALCULATION"&&problem.questionType!=="SHORT_ANSWER")return{status:"NEEDS_REVIEW",notes:["この問題形式はプログラム検算の対象外です"]};
  const normalized=problem.questionText.replaceAll("−","-").replaceAll("×","*").replaceAll("÷","/");
  const arithmetic=normalized.match(/(-?\d+(?:\.\d+)?)\s*([+\-*/])\s*(-?\d+(?:\.\d+)?)/);const answer=Number(problem.correctAnswer.replace(/[^0-9.\-]/g,""));
  if(arithmetic&&Number.isFinite(answer)){const a=Number(arithmetic[1]),b=Number(arithmetic[3]);const actual=arithmetic[2]==="+"?a+b:arithmetic[2]==="-"?a-b:arithmetic[2]==="*"?a*b:b===0?NaN:a/b;if(!Number.isFinite(actual))return{status:"FAILED",notes:["0で割る式になっています"]};return Math.abs(actual-answer)<1e-9?{status:"VERIFIED",notes:["四則計算の正答を再計算しました"]}:{status:"FAILED",notes:[`再計算結果は${actual}で、登録された正答と一致しません`]};}
  const equation=normalized.match(/(-?\d*)x\s*([+\-]\s*\d+(?:\.\d+)?)?\s*=\s*(-?\d+(?:\.\d+)?)/i);if(equation&&Number.isFinite(answer)){const a=equation[1]===""?1:equation[1]==="-"?-1:Number(equation[1]),b=Number((equation[2]??"0").replaceAll(" ","")),c=Number(equation[3]);if(a===0)return{status:"FAILED",notes:["一次方程式の解が一意になりません"]};const actual=(c-b)/a;return Math.abs(actual-answer)<1e-9?{status:"VERIFIED",notes:["一次方程式の解を再計算しました"]}:{status:"FAILED",notes:[`方程式の解は${actual}で、登録された正答と一致しません`]};}
  return{status:"NEEDS_REVIEW",notes:["安全に再計算できない形式のため、人による正答確認が必要です"]};
}

export function canApproveGeneratedProblem(reviewStatus:string,programCheckStatus:string){return["CONFIRMED","CORRECTED"].includes(reviewStatus)&&programCheckStatus!=="FAILED";}
