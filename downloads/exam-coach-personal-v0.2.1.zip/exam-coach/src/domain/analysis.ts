import { PRIORITY_TIE_ORDER, SUBJECTS, SUBJECT_LABELS, type SubjectKey } from "./subjects";

export const ANALYSIS_RULE_VERSION = "priority-v3";

export type ScoreInput = {
  subject: SubjectKey;
  score: number;
  maxScore: number;
  averageScore?: number | null;
  unansweredRate?: number | null;
};

export type SurveySubjectInput = {
  subject: SubjectKey;
  weeklyStudyMinutes: number;
  confidenceLevel: number;
  selfEvaluationScore?: number;
  studyFrequencyPerWeek?: number;
  preferenceScore?: number;
  difficultyScore?: number;
  easeOfStartingScore?: number;
  knowsWhatToStudyScore?: number;
};

export type AnalysisInput = {
  currentScores?: ScoreInput[];
  previousScores?: ScoreInput[];
  recentScores?: ScoreInput[][];
  surveySubjects?: SurveySubjectInput[];
};

export type AnalysisReason = {
  category: "score" | "trend" | "average" | "unanswered" | "selfEvaluation" | "confidence" | "studyTime" | "frequency" | "avoidance" | "clarity" | "data";
  points: number;
  text: string;
};

export type SubjectPriority = {
  subject: SubjectKey;
  priorityScore: number;
  priorityRank: number;
  latestScoreRate: number | null;
  scoreRateDelta: number | null;
  recentScoreRates: number[];
  selfEvaluationScore: number | null;
  confidenceLevel: number | null;
  recognitionLabel: string;
  analysisComment: string;
  reasons: AnalysisReason[];
};

function rate(score: ScoreInput | undefined): number | null {
  return score ? (score.score / score.maxScore) * 100 : null;
}

function scorePoints(value: number | null): number {
  if (value === null || value >= 80) return 0;
  if (value < 60) return 4;
  if (value < 70) return 3;
  return 2;
}

function trendPoints(value: number | null): number {
  if (value === null || value > -5) return 0;
  return value <= -10 ? 2 : 1;
}

function confidencePoints(value: number | null): number {
  if (value === null || value >= 4) return 0;
  return value <= 2 ? 2 : 1;
}

function recognition(args: { selfEvaluation: number | null; confidence: number | null; latest: number | null; delta: number | null }): { label: string; comment: string } {
  const { selfEvaluation, confidence, latest, delta } = args;
  const selfText = selfEvaluation === null ? "未回答" : selfEvaluation <= 1 ? "かなり苦手" : selfEvaluation === 2 ? "やや苦手" : selfEvaluation === 3 ? "どちらともいえない" : selfEvaluation === 4 ? "やや得意" : "かなり得意";
  const isStable = latest !== null && latest >= 70 && (delta === null || delta >= -2);
  const isDeclining = delta !== null && delta < -2;
  if (selfEvaluation !== null && selfEvaluation <= 2 && isDeclining) return { label: "優先的な支援が必要と考えられる教科", comment: `本人の${selfText}という認識と得点の下降傾向が一致しています。` };
  if (selfEvaluation !== null && selfEvaluation >= 4 && isDeclining) return { label: "本人は得意と感じているが成績が低下している教科", comment: `本人は${selfText}と感じていますが、最近の得点は低下しています。短い復習で変化を確認します。` };
  if (selfEvaluation !== null && selfEvaluation <= 2 && isStable) return { label: "本人は苦手と感じているが成績は安定している教科", comment: `本人は${selfText}と感じていますが、成績は比較的安定しています。できている点も確認します。` };
  if (selfEvaluation !== null && selfEvaluation >= 4 && isStable) return { label: "本人が得意と感じ、成績上も比較的安定している教科", comment: `本人の${selfText}という認識と、成績の安定または上昇傾向が一致しています。` };
  return { label: selfEvaluation !== null && selfEvaluation >= 4 ? "本人が得意と感じている教科" : "継続して様子を確認する教科", comment: `本人の認識は${selfText}、自信は${confidence ?? "未回答"}/5です。今後の結果と合わせて確認します。` };
}

export function calculatePriorities(input: AnalysisInput): SubjectPriority[] {
  if (!input.currentScores && !input.surveySubjects) {
    throw new Error("分析にはテスト結果またはアンケートが必要です。");
  }

  const scoreSets = input.recentScores?.length ? input.recentScores : [input.currentScores ?? [], input.previousScores ?? []];
  const currentMap = new Map((scoreSets[0] ?? []).map((item) => [item.subject, item]));
  const previousMap = new Map((scoreSets[1] ?? []).map((item) => [item.subject, item]));
  const surveyMap = new Map(input.surveySubjects?.map((item) => [item.subject, item]));
  const studyMinutes = SUBJECTS.map((subject) => surveyMap.get(subject)?.weeklyStudyMinutes)
    .filter((value): value is number => value !== undefined)
    .sort((a, b) => a - b);
  const studyCutoff = studyMinutes.length >= 2 ? studyMinutes[1] : null;

  const calculated = SUBJECTS.map((subject) => {
    const latestScoreRate = rate(currentMap.get(subject));
    const previousScoreRate = rate(previousMap.get(subject));
    const scoreRateDelta =
      latestScoreRate !== null && previousScoreRate !== null
        ? latestScoreRate - previousScoreRate
        : null;
    const survey = surveyMap.get(subject);
    const recentScoreRates = scoreSets.map((scores) => rate(scores.find((item) => item.subject === subject))).filter((value): value is number => value !== null).reverse();
    const reasons: AnalysisReason[] = [];

    const latestPoints = scorePoints(latestScoreRate);
    reasons.push({
      category: "score",
      points: latestPoints,
      text:
        latestScoreRate === null
          ? "最新のテスト結果はまだありません"
          : latestPoints > 0
            ? `最新の得点率 ${latestScoreRate.toFixed(1)}% を、伸びしろの目安として加味しました`
            : `最新の得点率 ${latestScoreRate.toFixed(1)}% は安定しています`,
    });

    const currentScore = currentMap.get(subject);
    const averageDifference = currentScore?.averageScore === null || currentScore?.averageScore === undefined ? null : currentScore.score - currentScore.averageScore;
    reasons.push({ category: "average", points: averageDifference !== null && averageDifference < -10 ? 1 : 0, text: averageDifference === null ? "平均点は未登録です" : `平均点との差は ${averageDifference >= 0 ? "+" : ""}${averageDifference.toFixed(1)}点です` });
    reasons.push({ category: "unanswered", points: (currentScore?.unansweredRate ?? 0) >= 20 ? 1 : 0, text: currentScore?.unansweredRate === null || currentScore?.unansweredRate === undefined ? "無回答率は未登録です" : `無回答率は ${currentScore.unansweredRate.toFixed(1)}% です` });

    const selfEvaluation = survey?.selfEvaluationScore ?? null;
    reasons.push({ category: "selfEvaluation", points: selfEvaluation !== null && selfEvaluation <= 2 ? 2 : 0, text: selfEvaluation === null ? "得意・苦手の自己評価は未回答です" : `本人の得意・苦手の自己評価は ${selfEvaluation}/5 です` });

    const deltaPoints = trendPoints(scoreRateDelta);
    reasons.push({
      category: "trend",
      points: deltaPoints,
      text:
        scoreRateDelta === null
          ? "比較できる前回のテスト結果はまだありません"
          : deltaPoints > 0
            ? `前回から ${Math.abs(scoreRateDelta).toFixed(1)} ポイント変化しているため、復習の機会にします`
            : `前回から ${scoreRateDelta >= 0 ? "+" : ""}${scoreRateDelta.toFixed(1)} ポイントです`,
    });

    const confidence = survey?.confidenceLevel ?? null;
    const confidenceScore = confidencePoints(confidence);
    reasons.push({
      category: "confidence",
      points: confidenceScore,
      text:
        confidence === null
          ? "自信度の回答はまだありません"
          : confidenceScore > 0
            ? `自信度 ${confidence}/5 を、取り組みを増やす目安として加味しました`
            : `自信度は ${confidence}/5 です`,
    });

    const isLowStudyTime =
      survey !== undefined && studyCutoff !== null && survey.weeklyStudyMinutes <= studyCutoff;
    reasons.push({
      category: "studyTime",
      points: isLowStudyTime ? 2 : 0,
      text:
        survey === undefined
          ? "学習時間の回答はまだありません"
          : isLowStudyTime
            ? `直近7日間は ${survey.weeklyStudyMinutes}分。短時間から取り組む候補にします`
            : `直近7日間は ${survey.weeklyStudyMinutes}分です`,
    });

    const lowFrequency = survey?.studyFrequencyPerWeek !== undefined && survey.studyFrequencyPerWeek <= 1;
    reasons.push({
      category: "frequency",
      points: lowFrequency ? 1 : 0,
      text: survey?.studyFrequencyPerWeek === undefined
        ? "学習頻度は未回答です"
        : lowFrequency
          ? `現在は週${survey.studyFrequencyPerWeek}日程度のため、短い実施回数を増やす候補にします`
          : `現在は週${survey.studyFrequencyPerWeek}日程度取り組んでいます`,
    });

    const avoidsSubject = survey !== undefined &&
      (survey.difficultyScore ?? 3) >= 4 &&
      ((survey.easeOfStartingScore ?? 3) <= 2 || isLowStudyTime);
    reasons.push({
      category: "avoidance",
      points: avoidsSubject ? 2 : 0,
      text: survey === undefined
        ? "教科への苦手感・取り組みやすさは未回答です"
        : avoidsSubject
          ? `苦手感 ${survey.difficultyScore ?? 3}/5、取り組みやすさ ${survey.easeOfStartingScore ?? 3}/5 のため、短い課題から始めます`
          : "苦手感と取り組みやすさは大きな妨げになっていません",
    });

    const lacksClarity = survey !== undefined && (survey.knowsWhatToStudyScore ?? 3) <= 2;
    reasons.push({
      category: "clarity",
      points: lacksClarity ? 1 : 0,
      text: survey === undefined
        ? "何を勉強するかの分かりやすさは未回答です"
        : lacksClarity
          ? `何を勉強するかの分かりやすさ ${survey.knowsWhatToStudyScore ?? 3}/5 のため、課題を具体化します`
          : "取り組む内容の見通しがあります",
    });

    const recognitionResult = recognition({ selfEvaluation, confidence, latest: latestScoreRate, delta: scoreRateDelta });
    return {
      subject,
      priorityScore: reasons.reduce((sum, reason) => sum + reason.points, 0),
      priorityRank: 0,
      latestScoreRate,
      scoreRateDelta,
      recentScoreRates,
      selfEvaluationScore: selfEvaluation,
      confidenceLevel: confidence,
      recognitionLabel: recognitionResult.label,
      analysisComment: recognitionResult.comment,
      reasons,
    };
  });

  return calculated
    .sort((a, b) => {
      if (a.priorityScore !== b.priorityScore) return b.priorityScore - a.priorityScore;
      if (a.latestScoreRate !== b.latestScoreRate) {
        if (a.latestScoreRate === null) return 1;
        if (b.latestScoreRate === null) return -1;
        return a.latestScoreRate - b.latestScoreRate;
      }
      return PRIORITY_TIE_ORDER.indexOf(a.subject) - PRIORITY_TIE_ORDER.indexOf(b.subject);
    })
    .map((item, index) => ({ ...item, priorityRank: index + 1 }));
}

export function guidanceFor(priority: SubjectPriority): string {
  const mainReason = [...priority.reasons]
    .filter((reason) => reason.points > 0)
    .sort((a, b) => b.points - a.points)[0];

  if (mainReason?.category === "trend") {
    return `${SUBJECT_LABELS[priority.subject]}：前回の内容を振り返り、解き方を確かめよう`;
  }
  if (mainReason?.category === "confidence") {
    return `${SUBJECT_LABELS[priority.subject]}：基本例題から始めて、できる感覚を増やそう`;
  }
  if (mainReason?.category === "studyTime") {
    return `${SUBJECT_LABELS[priority.subject]}：短時間でも教科書やノートを開く習慣をつくろう`;
  }
  if (mainReason?.category === "avoidance") {
    return `${SUBJECT_LABELS[priority.subject]}：得意な教科と組み合わせ、基礎問題を少しだけ解こう`;
  }
  if (mainReason?.category === "clarity") {
    return `${SUBJECT_LABELS[priority.subject]}：取り組む範囲と問題数を先に決めよう`;
  }
  if (mainReason?.category === "score") {
    return `${SUBJECT_LABELS[priority.subject]}：間違えた問題を一つずつ整理しよう`;
  }
  return `${SUBJECT_LABELS[priority.subject]}：これまでの学習を無理なく続けよう`;
}
