import type { SubjectKey } from "./subjects";

export type ProblemEvidence = { subject: SubjectKey; unit: string; isCorrect: boolean; isUnanswered: boolean; mistakeTypes: unknown; isReviewTarget: boolean; nextReviewOn?: Date | null };

export function priorityUnits(problems: ProblemEvidence[], now = new Date()): Map<SubjectKey, { unit: string; score: number; reason: string }> {
  const scores = new Map<string, { subject: SubjectKey; unit: string; score: number; errors: number; due: number }>();
  for (const problem of problems) {
    if (problem.isCorrect && !problem.isReviewTarget) continue;
    const key = `${problem.subject}:${problem.unit}`;
    const current = scores.get(key) ?? { subject: problem.subject, unit: problem.unit, score: 0, errors: 0, due: 0 };
    if (!problem.isCorrect) { current.score += 3; current.errors += 1; }
    if (problem.isUnanswered) current.score += 2;
    if (problem.isReviewTarget) current.score += 1;
    if (problem.nextReviewOn && problem.nextReviewOn <= now) { current.score += 3; current.due += 1; }
    scores.set(key, current);
  }
  const result = new Map<SubjectKey, { unit: string; score: number; reason: string }>();
  for (const item of scores.values()) {
    const previous = result.get(item.subject);
    if (!previous || item.score > previous.score) {
      result.set(item.subject, { unit: item.unit, score: item.score, reason: `${item.errors}問の誤答${item.due ? `、期限到来の復習${item.due}件` : ""}を確認` });
    }
  }
  return result;
}

export function scoreTrend(values: number[]): "上昇傾向" | "やや上昇" | "横ばい" | "やや下降" | "下降傾向" | "データ不足" {
  if (values.length < 2) return "データ不足";
  const delta = values[values.length - 1] - values[0];
  if (delta >= 10) return "上昇傾向";
  if (delta >= 3) return "やや上昇";
  if (delta <= -10) return "下降傾向";
  if (delta <= -3) return "やや下降";
  return "横ばい";
}
