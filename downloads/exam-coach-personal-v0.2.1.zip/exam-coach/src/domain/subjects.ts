export const SUBJECTS = [
  "JAPANESE",
  "MATH",
  "ENGLISH",
  "SCIENCE",
  "SOCIAL_STUDIES",
] as const;

export type SubjectKey = (typeof SUBJECTS)[number];

export const SUBJECT_LABELS: Record<SubjectKey, string> = {
  JAPANESE: "国語",
  MATH: "数学",
  ENGLISH: "英語",
  SCIENCE: "理科",
  SOCIAL_STUDIES: "社会",
};

export const PRIORITY_TIE_ORDER: SubjectKey[] = [
  "MATH",
  "ENGLISH",
  "JAPANESE",
  "SCIENCE",
  "SOCIAL_STUDIES",
];

export function isSubject(value: string): value is SubjectKey {
  return SUBJECTS.includes(value as SubjectKey);
}
