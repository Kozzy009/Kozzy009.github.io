export const MANUAL_AI_STATUS_LABELS:Record<string,string>={DRAFT:"下書き",PROMPT_CREATED:"プロンプト作成済み",WAITING_FOR_RESULT:"結果待ち",RESULT_RECEIVED:"JSON受信済み",VALIDATION_FAILED:"検証エラー",REVIEWING:"確認中",CONFIRMED:"確認完了",IMPORTED:"取り込み済み",CANCELLED:"中止"};
export const MANUAL_AI_REVIEW_LABELS:Record<string,string>={UNREVIEWED:"未確認",NEEDS_REVIEW:"要確認",CONFIRMED:"確認済み",CORRECTED:"修正済み",EXCLUDED:"除外"};
export const MANUAL_AI_JUDGMENT_LABELS:Record<string,string>={CORRECT:"正解候補",INCORRECT:"不正解候補",PARTIALLY_CORRECT:"部分正解候補",BLANK:"無回答",NEEDS_REVIEW:"要確認",UNDETERMINED:"判定不能"};
