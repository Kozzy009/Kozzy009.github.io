export const FILE_TYPE_LABELS:Record<string,string>={SCORE_REPORT:"成績表",QUESTION_PAPER:"問題用紙",STUDENT_ANSWER:"本人解答",MODEL_ANSWER:"模範解答",EXPLANATION:"解説",OTHER:"その他"};
export const FILE_SUBJECT_LABELS:Record<string,string>={JAPANESE:"国語",MATH:"数学",ENGLISH:"英語",SCIENCE:"理科",SOCIAL_STUDIES:"社会",ALL:"5教科共通",UNCLASSIFIED:"未分類"};
export const PROCESSING_LABELS:Record<string,string>={UPLOADED:"アップロード済み",QUEUED:"処理待ち",PROCESSING:"処理中",PROCESSED:"読み取り済み",FAILED:"エラー"};
export const CONFIRMATION_LABELS:Record<string,string>={UNCONFIRMED:"確認待ち",REVIEWING:"修正中",CONFIRMED:"確定済み",REJECTED:"除外"};
export const REVIEW_LABELS:Record<string,string>={UNREVIEWED:"未確認",CONFIRMED:"確認済み",CORRECTED:"修正済み",EXCLUDED:"除外",UNDETERMINED:"判定不能"};
export const GRADING_LABELS:Record<string,string>={CORRECT:"正解候補",INCORRECT:"不正解候補",UNANSWERED:"無回答",NEEDS_REVIEW:"要確認",UNDETERMINED:"判定不能"};
