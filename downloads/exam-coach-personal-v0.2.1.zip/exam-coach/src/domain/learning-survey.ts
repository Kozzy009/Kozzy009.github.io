import type { SubjectKey } from "./subjects";

export const DAY_OPTIONS = [
  ["MON", "月"], ["TUE", "火"], ["WED", "水"], ["THU", "木"],
  ["FRI", "金"], ["SAT", "土"], ["SUN", "日"],
] as const;

export type DayKey = (typeof DAY_OPTIONS)[number][0];

export const TIME_OF_DAY_OPTIONS = [
  ["MORNING", "朝"], ["AFTER_SCHOOL", "放課後"], ["EVENING", "夕方"], ["NIGHT", "夜"],
] as const;

export const MOTIVATION_QUESTIONS = {
  targetSchool: "志望校に入りたい気持ち",
  improveGrades: "成績を上げたい気持ち",
  selfStart: "自分から勉強を始められる",
  followPlan: "学習計画に取り組みたい",
  faceWeakSubjects: "苦手教科にも取り組める",
} as const;

export const CONFIDENCE_QUESTIONS = {
  effortWorks: "勉強すれば成績が上がると思う",
  achievement: "問題を解けたときに達成感がある",
  improveWeakness: "苦手教科も少しずつ改善できると思う",
  improveTest: "テストで以前より点を取れると思う",
  solveUnknown: "分からない問題を解決できると思う",
} as const;

export const STUDY_METHOD_QUESTIONS = {
  extraStudy: "学校の宿題以外にも取り組んでいる",
  reviewMistakes: "間違えた問題を解き直している",
  readExplanations: "解説を読んで理解している",
  askQuestions: "分からない問題を人に質問している",
  planBeforeTests: "テスト前に計画を立てている",
  solveProblems: "覚えるだけでなく問題を解いている",
  timedPractice: "時間を測って問題を解いている",
  repeatProblems: "同じ問題を繰り返している",
} as const;

export const CONCENTRATION_QUESTIONS = {
  sustainFocus: "勉強中に集中を続けられる",
  stopDevices: "スマートフォンやゲームを中断できる",
  quietPlace: "静かに勉強できる場所がある",
  independentStart: "家族に声をかけられなくても始められる",
  shortWhenTired: "疲れているときも短時間なら取り組める",
} as const;

export type ScaleAnswers = Record<string, number>;

export type SubjectFeelingInput = {
  subject: SubjectKey;
  weeklyStudyMinutes: number;
  confidenceLevel: number;
  selfEvaluationScore: number;
  studyFrequencyPerWeek: number;
  preferenceScore: number;
  difficultyScore: number;
  easeOfStartingScore: number;
  knowsWhatToStudyScore: number;
};

export type LearningSurveyProfile = {
  currentWeekdayMinutes: number;
  currentWeekendMinutes: number;
  weekdayAvailableMinutes: number;
  weekendAvailableMinutes: number;
  concentrationMinutes: number;
  availableDaysPerWeek: number;
  availableDays: DayKey[];
  busyDays: DayKey[];
  preferredTimeOfDay: string;
  anxiousSubjectsUnits?: string | null;
  motivationAnswers: ScaleAnswers;
  confidenceAnswers: ScaleAnswers;
  studyMethodAnswers: ScaleAnswers;
  concentrationAnswers: ScaleAnswers;
  motivationScore: number;
  confidenceScore: number;
  studyHabitScore: number;
  reviewHabitScore: number;
  concentrationScore: number;
  environmentScore: number;
  subjects: SubjectFeelingInput[];
};

export function averageAnswers(values: ScaleAnswers): number {
  const numbers = Object.values(values).filter((value) => Number.isFinite(value));
  if (numbers.length === 0) return 0;
  return numbers.reduce((sum, value) => sum + value, 0) / numbers.length;
}

export function surveyScores(args: {
  motivationAnswers: ScaleAnswers;
  confidenceAnswers: ScaleAnswers;
  studyMethodAnswers: ScaleAnswers;
  concentrationAnswers: ScaleAnswers;
}) {
  const method = args.studyMethodAnswers;
  const concentration = args.concentrationAnswers;
  return {
    motivationScore: averageAnswers(args.motivationAnswers),
    confidenceScore: averageAnswers(args.confidenceAnswers),
    studyHabitScore: averageAnswers(method),
    reviewHabitScore: averageAnswers({
      reviewMistakes: method.reviewMistakes ?? 0,
      readExplanations: method.readExplanations ?? 0,
      repeatProblems: method.repeatProblems ?? 0,
    }),
    concentrationScore: averageAnswers({
      sustainFocus: concentration.sustainFocus ?? 0,
      stopDevices: concentration.stopDevices ?? 0,
      shortWhenTired: concentration.shortWhenTired ?? 0,
    }),
    environmentScore: averageAnswers({
      quietPlace: concentration.quietPlace ?? 0,
      independentStart: concentration.independentStart ?? 0,
    }),
  };
}
