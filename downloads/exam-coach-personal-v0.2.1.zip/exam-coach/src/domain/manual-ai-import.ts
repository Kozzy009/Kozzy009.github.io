import { z } from "zod";

export const MANUAL_AI_SCHEMA_VERSION = "manual-ai-test-analysis-v1";
export const MANUAL_AI_JUDGMENTS = ["CORRECT", "INCORRECT", "PARTIALLY_CORRECT", "BLANK", "NEEDS_REVIEW", "UNDETERMINED"] as const;
export const MANUAL_AI_REVIEW_STATUSES = ["UNREVIEWED", "NEEDS_REVIEW", "CONFIRMED", "CORRECTED", "EXCLUDED"] as const;
const subjects = ["JAPANESE", "MATH", "ENGLISH", "SCIENCE", "SOCIAL_STUDIES"] as const;
const grades = ["JUNIOR_HIGH_1", "JUNIOR_HIGH_2", "JUNIOR_HIGH_3"] as const;
const difficulties = ["BASIC", "STANDARD", "ADVANCED", "UNKNOWN"] as const;

export const manualAiQuestionSchema = z.object({
  majorQuestionNumber: z.string().min(1).max(20), minorQuestionNumber: z.string().max(20).nullable(),
  pageNumber: z.number().int().min(1), questionText: z.string().max(10000), hasVisual: z.boolean(), visualType: z.string().max(100).nullable(),
  field: z.string().max(100), unit: z.string().max(100), subUnit: z.string().max(100).nullable(), questionType: z.string().max(100), difficulty: z.enum(difficulties),
  points: z.number().int().min(0).max(100).nullable(), studentAnswer: z.string().max(5000).nullable(), correctAnswer: z.string().max(5000).nullable(),
  judgment: z.enum(MANUAL_AI_JUDGMENTS), isBlank: z.boolean(), mistakeTypes: z.array(z.string().max(100)).max(20),
  requiredKnowledge: z.array(z.string().max(300)).max(30), solutionSummary: z.string().max(5000), recommendedReview: z.string().max(5000),
  confidence: z.number().int().min(0).max(100), needsHumanReview: z.boolean(), reviewReason: z.string().max(2000).nullable(),
}).strict();

export const manualAiPayloadSchema = z.object({
  schemaVersion: z.literal(MANUAL_AI_SCHEMA_VERSION), studentAnonymousId: z.string().min(1), importToken: z.string().min(1),
  test: z.object({ name: z.string().min(1), date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/), grade: z.enum(grades), subject: z.enum(subjects) }).strict(),
  questions: z.array(manualAiQuestionSchema).max(500),
  unitSummary: z.array(z.record(z.string(), z.unknown())),
  overallAnalysis: z.object({ summary: z.string().max(10000), strengths: z.array(z.string().max(1000)), issues: z.array(z.string().max(1000)), recommendedStudy: z.array(z.string().max(1000)) }).strict(),
}).strict().superRefine((value, ctx) => {
  const seen = new Set<string>();
  value.questions.forEach((question, index) => { const key = `${question.majorQuestionNumber}:${question.minorQuestionNumber ?? ""}`; if (seen.has(key)) ctx.addIssue({ code: "custom", path: ["questions", index], message: "同じ問題番号が重複しています" }); seen.add(key); });
});

export type ManualAiPayload = z.infer<typeof manualAiPayloadSchema>;
export type ManualAiQuestion = z.infer<typeof manualAiQuestionSchema>;

export function stripMarkdownJsonFence(input: string): string {
  const trimmed = input.trim();
  const fenced = /^```(?:json)?\s*\r?\n([\s\S]*?)\r?\n```$/i.exec(trimmed);
  if (fenced) return fenced[1].trim();
  if (trimmed.startsWith("```") || trimmed.endsWith("```")) throw new Error("JSONコードブロックの前後に説明文を含めないでください");
  return trimmed;
}

export type ManualAiExpected = { studentAnonymousId: string; importToken: string; testName: string; testDate: string; grade: string; subject: string; schemaVersion: string };
export type ManualAiValidation = { success: true; data: ManualAiPayload; normalizedJson: string } | { success: false; errors: string[]; normalizedJson?: string };

function issueMessage(issue: z.core.$ZodIssue): string {
  const path = issue.path.map(String); const questionIndex = path[0] === "questions" && /^\d+$/.test(path[1] ?? "") ? Number(path[1]) + 1 : null;
  const location = questionIndex ? `${questionIndex}番目の問題${path[2] ? `の${path[2]}` : ""}` : path.length ? path.join(".") : "JSON全体";
  if (path.at(-1) === "schemaVersion") return "未対応のスキーマバージョンです";
  if (path.at(-1) === "confidence") return `${location}は0～100の整数で入力してください`;
  if (path.at(-1) === "difficulty") return `${location}が不正です`;
  return `${location}: ${issue.message}`;
}

export function validateManualAiJson(raw: string, expected: ManualAiExpected): ManualAiValidation {
  let normalizedJson: string; let value: unknown;
  try { normalizedJson = stripMarkdownJsonFence(raw); value = JSON.parse(normalizedJson); } catch (error) { return { success: false, errors: [error instanceof Error && error.message.includes("コードブロック") ? error.message : "JSON形式が正しくありません"] }; }
  const parsed = manualAiPayloadSchema.safeParse(value);
  if (!parsed.success) return { success: false, normalizedJson, errors: parsed.error.issues.map(issueMessage) };
  const errors: string[] = [];
  if (parsed.data.schemaVersion !== expected.schemaVersion) errors.push("未対応のスキーマバージョンです");
  if (parsed.data.studentAnonymousId !== expected.studentAnonymousId) errors.push("生徒IDが解析依頼と一致しません");
  if (parsed.data.importToken !== expected.importToken) errors.push("importTokenが解析依頼と一致しません");
  if (parsed.data.test.name !== expected.testName) errors.push("テスト名が解析依頼と一致しません");
  if (parsed.data.test.date !== expected.testDate) errors.push("テスト実施日が解析依頼と一致しません");
  if (parsed.data.test.subject !== expected.subject) errors.push("解析対象の教科が一致しません");
  if (parsed.data.test.grade !== expected.grade) errors.push("学年が解析依頼と一致しません");
  return errors.length ? { success: false, normalizedJson, errors } : { success: true, normalizedJson, data: parsed.data };
}

export function initialManualAiReviewStatus(question: Pick<ManualAiQuestion, "confidence"|"needsHumanReview"|"judgment">): "NEEDS_REVIEW"|"UNREVIEWED" {
  return question.confidence < 70 || question.needsHumanReview || question.judgment === "NEEDS_REVIEW" ? "NEEDS_REVIEW" : "UNREVIEWED";
}

export function canImportManualAiQuestion(reviewStatus: string): boolean {
  return ["CONFIRMED", "CORRECTED"].includes(reviewStatus);
}

export function manualAiReviewCandidateStatus(judgment: string): "SCHEDULED" | "NEEDS_CONFIRMATION" | null {
  if (judgment === "NEEDS_REVIEW") return "NEEDS_CONFIRMATION";
  return ["INCORRECT", "BLANK", "PARTIALLY_CORRECT"].includes(judgment) ? "SCHEDULED" : null;
}
