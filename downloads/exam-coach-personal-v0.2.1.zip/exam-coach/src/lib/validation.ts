import { z } from "zod";
import { SUBJECTS } from "@/domain/subjects";
import { DAY_OPTIONS } from "@/domain/learning-survey";

const optionalText = (max: number) =>
  z.string().trim().max(max).transform((value) => value || null);

const optionalNumber = (schema: z.ZodNumber) => z.preprocess(
  (value) => (value === "" || value === null || value === undefined ? null : value),
  z.coerce.number().pipe(schema).nullable(),
);

export const studentSchema = z.object({
  displayName: z.string().trim().min(1, "表示名を入力してください").max(50),
  phoneticName: optionalText(100),
  grade: z.enum(["JUNIOR_HIGH_1", "JUNIOR_HIGH_2", "JUNIOR_HIGH_3"]),
  schoolName: optionalText(100),
  residenceArea: optionalText(100),
  examYear: optionalNumber(z.number().int().min(2020).max(2100)),
  clubActivity: optionalText(300),
  lessons: optionalText(300),
  accommodations: optionalText(1000),
  note: optionalText(1000),
});

export const studentRegistrationSchema = studentSchema.extend({
  firstChoiceSchool: optionalText(100),
  firstChoiceDepartment: optionalText(100),
  secondChoiceSchool: optionalText(100),
  secondChoiceDepartment: optionalText(100),
}).superRefine((value, context) => {
  if (value.firstChoiceDepartment && !value.firstChoiceSchool) context.addIssue({ code: "custom", path: ["firstChoiceSchool"], message: "第一志望学科を入力する場合は学校名も入力してください" });
  if (value.secondChoiceDepartment && !value.secondChoiceSchool) context.addIssue({ code: "custom", path: ["secondChoiceSchool"], message: "第二志望学科を入力する場合は学校名も入力してください" });
});

export const targetSchoolSchema = z.object({
  schoolName: z.string().trim().min(1, "志望校名を入力してください").max(100),
  departmentName: optionalText(100),
  preferenceRank: z.coerce.number().int().min(1).max(10),
  targetTotalScore: z.preprocess(
    (value) => (value === "" ? null : value),
    z.coerce.number().int().min(0).max(500).nullable(),
  ),
  note: optionalText(500),
  setOn: z.coerce.date().optional(),
  instructorComment: optionalText(1000).optional(),
  subjectGoals: z.array(z.object({ subject: z.enum(SUBJECTS), targetScore: z.coerce.number().int().min(0).max(100) })).length(5).optional(),
});

export const MISTAKE_TYPES = ["KNOWLEDGE", "METHOD", "MISREAD", "CALCULATION", "UNIT", "DESCRIPTION", "TIME", "CARELESS", "UNANSWERED", "OUT_OF_SCOPE", "UNKNOWN", "OTHER"] as const;

export const problemProfileSchema = z.object({
  testName: z.string().trim().min(1, "テスト名を入力してください").max(100),
  attemptedOn: z.coerce.date().max(new Date(), "未来の日付は入力できません"),
  subject: z.enum(SUBJECTS),
  majorNumber: z.string().trim().min(1, "大問番号を入力してください").max(30),
  minorNumber: optionalText(30),
  area: z.string().trim().min(1, "分野を入力してください").max(100),
  unit: z.string().trim().min(1, "単元を入力してください").max(100),
  questionFormat: z.string().trim().min(1).max(100),
  difficulty: z.enum(["BASIC", "STANDARD", "ADVANCED"]),
  points: z.coerce.number().int().min(0).max(100),
  studentAnswer: optionalText(1000),
  correctAnswer: optionalText(1000),
  isCorrect: z.boolean(),
  answerSeconds: optionalNumber(z.number().int().min(0).max(10800)),
  isUnanswered: z.boolean(),
  mistakeTypes: z.array(z.enum(MISTAKE_TYPES)).max(MISTAKE_TYPES.length),
  instructorComment: optionalText(1000),
  isReviewTarget: z.boolean(),
}).superRefine((data, context) => {
  if (data.isUnanswered && data.isCorrect) context.addIssue({ code: "custom", path: ["isCorrect"], message: "無回答の問題を正解にはできません" });
});

export const reviewAttemptSchema = z.object({
  reviewedOn: z.coerce.date().max(new Date(), "未来の日付は入力できません"),
  isCorrect: z.boolean(),
  note: optionalText(1000),
});

export const academicTestSchema = z.object({
  name: z.string().trim().min(1, "テスト名を入力してください").max(100),
  takenOn: z.coerce.date().max(new Date(), "未来の日付は入力できません"),
  note: optionalText(500),
  scores: z.array(
    z.object({
      subject: z.enum(SUBJECTS),
      score: z.coerce.number().int().min(0),
      maxScore: z.coerce.number().int().min(1).max(500),
      averageScore: optionalNumber(z.number().min(0).max(500)),
      unansweredRate: optionalNumber(z.number().min(0).max(100)),
    }).refine((value) => value.score <= value.maxScore, {
      message: "得点は満点以下で入力してください",
      path: ["score"],
    }),
  ).length(5),
});

export const surveySchema = z.object({
  answeredOn: z.coerce.date().max(new Date(), "未来の日付は入力できません"),
  currentWeekdayMinutes: z.coerce.number().int().min(0).max(600),
  currentWeekendMinutes: z.coerce.number().int().min(0).max(900),
  weekdayAvailableMinutes: z.coerce.number().int().min(0).max(600),
  weekendAvailableMinutes: z.coerce.number().int().min(0).max(900),
  concentrationMinutes: z.coerce.number().int().min(10).max(120),
  availableDaysPerWeek: z.coerce.number().int().min(1).max(7),
  availableDays: z.array(z.enum(DAY_OPTIONS.map(([key]) => key))).min(1).max(7),
  busyDays: z.array(z.enum(DAY_OPTIONS.map(([key]) => key))).max(7),
  preferredTimeOfDay: z.enum(["MORNING", "AFTER_SCHOOL", "EVENING", "NIGHT"]),
  motivationAnswers: z.record(z.string(), z.coerce.number().int().min(1).max(5)),
  confidenceAnswers: z.record(z.string(), z.coerce.number().int().min(1).max(5)),
  studyMethodAnswers: z.record(z.string(), z.coerce.number().int().min(1).max(5)),
  concentrationAnswers: z.record(z.string(), z.coerce.number().int().min(1).max(5)),
  concern: optionalText(1000),
  recentAchievement: optionalText(1000),
  anxiousSubjectsUnits: optionalText(1000),
  preferredStudyMethod: optionalText(1000),
  familyConsideration: optionalText(1000),
  subjects: z.array(z.object({
    subject: z.enum(SUBJECTS),
    weeklyStudyMinutes: z.coerce.number().int().min(0).max(10080),
    confidenceLevel: z.coerce.number().int().min(1).max(5),
    selfEvaluationScore: z.coerce.number().int().min(1).max(5),
    studyFrequencyPerWeek: z.coerce.number().int().min(0).max(7),
    preferenceScore: z.coerce.number().int().min(1).max(5),
    difficultyScore: z.coerce.number().int().min(1).max(5),
    easeOfStartingScore: z.coerce.number().int().min(1).max(5),
    knowsWhatToStudyScore: z.coerce.number().int().min(1).max(5),
  })).length(5),
});

export const planItemSchema = z.object({
  plannedOn: z.coerce.date(),
  subject: z.enum(SUBJECTS),
  durationMinutes: z.coerce.number().int().min(10).max(120),
  unit: z.string().trim().min(1).max(200),
  purpose: z.string().trim().min(1).max(300),
  activity: z.string().trim().min(1).max(300),
  problemCount: z.coerce.number().int().min(0).max(200),
  difficulty: z.enum(["BASIC", "STANDARD", "ADVANCED"]),
  studyMethod: z.string().trim().min(1).max(500),
  completionCriteria: z.string().trim().min(1).max(500),
});

export const studyRecordSchema = z.object({
  completed: z.boolean(),
  actualMinutes: z.coerce.number().int().min(0).max(900),
  attemptedCount: z.coerce.number().int().min(0).max(1000),
  correctCount: z.coerce.number().int().min(0).max(1000),
  difficultyRating: z.coerce.number().int().min(1).max(5),
  concentrationRating: z.coerce.number().int().min(1).max(5),
  retryPreference: z.boolean(),
  mistakeTypes: z.array(z.enum(["CALCULATION", "MISREAD", "UNKNOWN_METHOD", "MEMORY", "TIME", "OTHER"])),
  studentComment: optionalText(1000),
}).refine((value) => value.correctCount <= value.attemptedCount, {
  message: "正答数は解いた問題数以下で入力してください",
  path: ["correctCount"],
});
