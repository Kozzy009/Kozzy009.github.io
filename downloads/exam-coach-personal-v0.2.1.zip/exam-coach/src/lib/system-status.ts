import "server-only";
import { access, readFile, readdir, stat, statfs } from "node:fs/promises";
import { constants } from "node:fs";
import path from "node:path";
import { prisma } from "@/lib/prisma";

const runtime = globalThis as unknown as { iwakiAppStartedAt?: Date };
const appStartedAt = runtime.iwakiAppStartedAt ?? new Date();
runtime.iwakiAppStartedAt = appStartedAt;

function databasePath() {
  const raw = (process.env.DATABASE_URL ?? "file:./dev.db").replace(/^file:/, "");
  return path.isAbsolute(raw) ? raw : path.resolve(/* turbopackIgnore: true */ process.cwd(), raw.replace(/^\.\//, ""));
}

async function latestBackup() {
  const root = process.env.BACKUP_STORAGE_PATH;
  if (!root) return { createdAt: null as Date | null, result: "未設定" };
  try {
    const entries = (await readdir(root, { withFileTypes: true }))
      .filter((entry) => entry.isDirectory() && (entry.name.startsWith("iwaki-exam-coach-backup-") || entry.name.startsWith("exam-coach-backup-")))
      .sort((a, b) => b.name.localeCompare(a.name));
    if (!entries[0]) return { createdAt: null, result: "未実施" };
    const backupPath = path.join(root, entries[0].name);
    const [info, manifest] = await Promise.all([
      stat(backupPath),
      readFile(path.join(backupPath, entries[0].name.startsWith("exam-coach-backup-") ? "manifest.json" : "manifest.txt"), "utf8").catch(() => ""),
    ]);
    return { createdAt: info.mtime, result: (manifest.includes("result=SUCCESS") || manifest.includes('"exam-coach-backup"')) ? "成功" : "要確認" };
  } catch {
    return { createdAt: null, result: "確認できません" };
  }
}

async function writable(target: string | undefined) {
  if (!target) return false;
  try { await access(target, constants.W_OK); return true; } catch { return false; }
}

export async function getSystemStatus() {
  const dbPath = databasePath();
  let databaseConnected = false;
  try { await prisma.$queryRaw`SELECT 1`; databaseConnected = true; } catch { databaseConnected = false; }
  const [dbInfo, disk, backup, counts] = await Promise.all([
    stat(dbPath).catch(() => null),
    statfs(path.dirname(dbPath)).catch(() => null),
    latestBackup(),
    databaseConnected ? Promise.all([
      prisma.student.count(), prisma.academicTest.count(), prisma.problemProfile.count(),
      prisma.reviewProfile.count(), prisma.workbook.count(), prisma.uploadedFile.count(),
    ]) : Promise.resolve([0, 0, 0, 0, 0, 0]),
  ]);
  return {
    version: "0.2.1",
    environment: process.env.APP_ENV ?? "development",
    databaseConnected,
    databaseSizeBytes: dbInfo?.size ?? 0,
    studentCount: counts[0], academicTestCount: counts[1], problemCount: counts[2],
    reviewCount: counts[3], workbookCount: counts[4], uploadCount: counts[5],
    latestBackupAt: backup.createdAt, latestBackupResult: backup.result,
    diskFreeBytes: disk ? disk.bavail * disk.bsize : null,
    appStartedAt,
  };
}

export async function getPreflightChecks() {
  const status = await getSystemStatus();
  const backupWritable = await writable(process.env.BACKUP_STORAGE_PATH);
  const uploadWritable = await writable(process.env.UPLOAD_STORAGE_PATH);
  const buildExists = await access(path.join(/* turbopackIgnore: true */ process.cwd(), ".next", "BUILD_ID")).then(() => true).catch(() => false);
  const manualExists = await access(path.join(/* turbopackIgnore: true */ process.cwd(), "docs", "manuals", "quick-start-guide.md")).then(() => true).catch(() => false);
  return [
    { label: "production build済み", ok: buildExists },
    { label: "データベース接続正常", ok: status.databaseConnected },
    { label: "バックアップ先書込み可能", ok: backupWritable },
    { label: "アップロード先書込み可能", ok: uploadWritable },
    { label: "デモデータ無効", ok: process.env.ENABLE_DEMO_DATA === "false" },
    { label: "開発ツール無効", ok: process.env.ENABLE_DEV_TOOLS === "false" },
    { label: "本番環境設定", ok: process.env.APP_ENV === "production" },
    { label: "最新バックアップあり", ok: status.latestBackupAt !== null && status.latestBackupResult === "成功" },
    { label: "操作マニュアルあり", ok: manualExists },
    { label: "個人端末の保存先設定済み", ok: Boolean(process.env.EXAM_COACH_DATA_DIR) || process.env.PRIVACY_POLICY_CONFIRMED === "true" },
  ];
}

export function formatBytes(bytes: number | null) {
  if (bytes === null) return "確認できません";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 ** 2) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 ** 3) return `${(bytes / 1024 ** 2).toFixed(1)} MB`;
  return `${(bytes / 1024 ** 3).toFixed(1)} GB`;
}
