import "server-only";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { renderManualAiPrompt, type ManualAiPromptVariables } from "@/domain/manual-ai-prompt";

export async function generateManualAiPrompt(variables: ManualAiPromptVariables): Promise<string> {
  const templatePath = path.join(/* turbopackIgnore: true */ process.cwd(), "prompts", "manual-ai-test-analysis-v1.md");
  const template = await readFile(templatePath, "utf8");
  return renderManualAiPrompt(template, variables);
}
