import { appendFile, mkdir } from "node:fs/promises";
import path from "node:path";

export async function writeSanitizedAppError(error: unknown, routeType: string, routePath: string) {
  if (process.env.APP_ENV !== "production" || !process.env.UPLOAD_STORAGE_PATH) return;
  const logDirectory = path.join(process.env.EXAM_COACH_DATA_DIR ?? path.dirname(process.env.UPLOAD_STORAGE_PATH), "logs");
  const errorName = error instanceof Error ? error.name.replace(/[^A-Za-z0-9_-]/g, "") : "UnknownError";
  const line = `${new Date().toISOString()} [APP_ERROR] ${routeType} ${routePath} ${errorName}\n`;
  try {
    await mkdir(logDirectory, { recursive: true, mode: 0o700 });
    await appendFile(path.join(logDirectory, "app-errors.log"), line, { encoding: "utf8", mode: 0o600 });
  } catch {
    // Logging must never replace the original application error.
  }
}
