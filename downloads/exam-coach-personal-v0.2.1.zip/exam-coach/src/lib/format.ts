import { SUBJECT_LABELS, type SubjectKey } from "@/domain/subjects";

export const GRADE_LABELS = {
  JUNIOR_HIGH_1: "中学1年",
  JUNIOR_HIGH_2: "中学2年",
  JUNIOR_HIGH_3: "中学3年",
} as const;

export function formatDate(date: Date): string {
  return new Intl.DateTimeFormat("ja-JP", {
    timeZone: "Asia/Tokyo",
    year: "numeric",
    month: "short",
    day: "numeric",
  }).format(date);
}

export function formatShortDate(date: Date): string {
  return new Intl.DateTimeFormat("ja-JP", {
    timeZone: "Asia/Tokyo",
    month: "numeric",
    day: "numeric",
    weekday: "short",
  }).format(date);
}

export function subjectLabel(subject: string): string {
  return SUBJECT_LABELS[subject as SubjectKey] ?? subject;
}

export function toDateInput(date: Date): string {
  const formatter = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Tokyo",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  });
  return formatter.format(date);
}

export function startOfWeek(date = new Date()): Date {
  const dateText = toDateInput(date);
  const local = new Date(`${dateText}T00:00:00+09:00`);
  const day = new Date(`${dateText}T12:00:00+09:00`).getUTCDay();
  const offset = day === 0 ? -6 : 1 - day;
  local.setUTCDate(local.getUTCDate() + offset);
  return local;
}

export function addDays(date: Date, days: number): Date {
  const result = new Date(date);
  result.setUTCDate(result.getUTCDate() + days);
  return result;
}
