import "server-only";
import {readFile}from"node:fs/promises";
import path from"node:path";
import{renderProblemGenerationPrompt,type ProblemGenerationPromptVariables}from"@/domain/problem-generation-prompt";
export async function generateProblemGenerationPrompt(variables:ProblemGenerationPromptVariables){const template=await readFile(path.join(/* turbopackIgnore: true */process.cwd(),"prompts","manual-ai-problem-generation-v1.md"),"utf8");return renderProblemGenerationPrompt(template,variables);}
