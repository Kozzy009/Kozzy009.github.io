import { createHash } from "node:crypto";
import { z } from "zod";

export const FILE_TYPES = ["SCORE_REPORT", "QUESTION_PAPER", "STUDENT_ANSWER", "MODEL_ANSWER", "EXPLANATION", "OTHER"] as const;
export const FILE_SUBJECTS = ["JAPANESE", "MATH", "ENGLISH", "SCIENCE", "SOCIAL_STUDIES", "ALL", "UNCLASSIFIED"] as const;

export const uploadMetadataSchema = z.object({
  studentId: z.string().min(1), academicTestId: z.string().min(1),
  fileType: z.enum(FILE_TYPES), subject: z.enum(FILE_SUBJECTS),
  schoolGrade: z.string().max(30).optional(),
  academicYear: z.coerce.number().int().min(2000).max(2200).optional(),
  notes: z.string().max(1000).optional(),
});

const accepted: Record<string, { mime: string[]; magic: (bytes: Uint8Array) => boolean }> = {
  pdf: { mime: ["application/pdf"], magic: (b) => b.length >= 5 && String.fromCharCode(...b.slice(0, 5)) === "%PDF-" },
  png: { mime: ["image/png"], magic: (b) => b.length >= 8 && [137,80,78,71,13,10,26,10].every((v,i) => b[i] === v) },
  jpg: { mime: ["image/jpeg"], magic: (b) => b.length >= 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff },
  jpeg: { mime: ["image/jpeg"], magic: (b) => b.length >= 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff },
};

export type ValidatedUpload = { extension: string; mimeType: string; sizeBytes: number; fileHash: string; bytes: Uint8Array; safeOriginalName: string };

export function uploadLimitBytes(): number {
  const configuredMb = Number(process.env.MAX_UPLOAD_SIZE_MB ?? 20);
  const configured = Number(process.env.UPLOAD_MAX_BYTES ?? configuredMb * 1024 * 1024);
  return Number.isFinite(configured) && configured > 0 ? Math.floor(configured) : 20 * 1024 * 1024;
}

export function validateUpload(input: { name: string; type: string; bytes: Uint8Array }, maxBytes = uploadLimitBytes()): ValidatedUpload {
  const name = input.name.trim();
  if (!name || name.length > 255 || /[\u0000-\u001f/\\]/.test(name)) throw new Error("ファイル名が不正です。");
  if (input.bytes.byteLength === 0) throw new Error("0バイトのファイルは登録できません。");
  if (input.bytes.byteLength > maxBytes) throw new Error(`ファイルサイズは${Math.floor(maxBytes / 1024 / 1024)}MB以内にしてください。`);
  const extension = name.includes(".") ? name.split(".").pop()!.toLowerCase() : "";
  const rule = accepted[extension];
  if (!rule) throw new Error("PDF、PNG、JPEG、JPG形式のファイルを選択してください。");
  if (!rule.mime.includes(input.type.toLowerCase())) throw new Error("ファイルのMIMEタイプと拡張子が一致しません。");
  if (!rule.magic(input.bytes)) throw new Error("ファイルの実体と拡張子が一致しません。");
  return {
    extension, mimeType: input.type.toLowerCase(), sizeBytes: input.bytes.byteLength,
    fileHash: createHash("sha256").update(input.bytes).digest("hex"), bytes: input.bytes,
    safeOriginalName: name.replace(/[^\p{L}\p{N}._ -]/gu, "_").slice(0, 255),
  };
}
