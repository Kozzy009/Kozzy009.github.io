import "server-only";
import { randomUUID } from "node:crypto";
import { mkdir, readFile, unlink, writeFile } from "node:fs/promises";
import path from "node:path";

export interface StorageProvider {
  save(bytes: Uint8Array, extension: string): Promise<{ storedFileName: string; storagePath: string }>;
  read(storagePath: string): Promise<Uint8Array>;
  delete(storagePath: string): Promise<void>;
}

export interface S3CompatibleStorageProvider extends StorageProvider {
  readonly bucket: string;
}

export class LocalStorageProvider implements StorageProvider {
  private readonly root: string;
  constructor(root = process.env.UPLOAD_STORAGE_PATH ?? process.env.UPLOAD_STORAGE_ROOT ?? ".data/uploads") {
    this.root = path.resolve(/* turbopackIgnore: true */ process.cwd(), root);
  }
  private resolve(key: string): string {
    if (!/^[a-f0-9-]+\.(pdf|png|jpe?g)$/i.test(key)) throw new Error("保存キーが不正です。");
    const resolved = path.resolve(this.root, key);
    if (!resolved.startsWith(`${this.root}${path.sep}`)) throw new Error("保存キーが不正です。");
    return resolved;
  }
  async save(bytes: Uint8Array, extension: string) {
    await mkdir(this.root, { recursive: true, mode: 0o700 });
    const storedFileName = `${randomUUID()}.${extension}`;
    await writeFile(this.resolve(storedFileName), bytes, { mode: 0o600, flag: "wx" });
    return { storedFileName, storagePath: storedFileName };
  }
  async read(storagePath: string) { return new Uint8Array(await readFile(this.resolve(storagePath))); }
  async delete(storagePath: string) { try { await unlink(this.resolve(storagePath)); } catch (error) { if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error; } }
}

export const storageProvider: StorageProvider = new LocalStorageProvider();
