import { NextResponse, type NextRequest } from "next/server";
import { isLocalRequest } from "@/domain/local-access";

export function proxy(request: NextRequest) {
  if (!isLocalRequest(request.headers.get("host"), request.headers.get("origin"), request.headers.get("sec-fetch-site"))) {
    return new NextResponse("このアプリは同じ端末のブラウザから利用してください。", { status: 403 });
  }
  const response = NextResponse.next();
  response.headers.set("Cache-Control", "private, no-store");
  response.headers.set("X-Content-Type-Options", "nosniff");
  response.headers.set("X-Frame-Options", "DENY");
  response.headers.set("Referrer-Policy", "no-referrer");
  return response;
}

export const config = { matcher: ["/((?!_next/static|_next/image|icon.svg).*)"] };
