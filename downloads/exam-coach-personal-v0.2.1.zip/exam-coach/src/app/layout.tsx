import type { Metadata, Viewport } from "next";
import Link from "next/link";
import "./globals.css";

export const metadata: Metadata = {
  title: { default: "高校入試コーチ", template: "%s | 高校入試コーチ" },
  description: "テスト結果と学習状況から、次の一週間の学び方を一緒に整理する個人端末用アプリです。",
  applicationName: "高校入試コーチ",
  manifest: "/manifest.webmanifest",
  appleWebApp: { capable: true, statusBarStyle: "default", title: "入試コーチ" },
  icons: { icon: "/icon.svg", apple: "/icon.svg" },
};
export const viewport: Viewport = { themeColor: "#123a5a" };

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="ja">
      <body>
        <header className="border-b border-white/10 bg-[#123a5a] text-white">
          <div className="page-shell flex min-h-20 items-center justify-between gap-4 py-3">
            <Link href="/" className="group flex items-center gap-3 no-underline">
              <span aria-hidden="true" className="grid size-11 place-items-center rounded-2xl bg-[#dff4f2] text-xl font-black text-[#123a5a]">学</span>
              <span>
                <span className="block text-[11px] font-bold tracking-[.16em] text-[#9de2dc]">自分のペースで、次の一週間へ</span>
                <span className="block text-base font-black sm:text-lg">高校入試コーチ</span>
              </span>
            </Link>
            <nav aria-label="全体ナビゲーション" className="hidden items-center gap-2 sm:flex">
              <Link href="/" className="rounded-full px-4 py-2 font-bold text-white hover:bg-white/10">生徒一覧</Link>
              <Link href="/manual" className="rounded-full px-4 py-2 font-bold text-white hover:bg-white/10">操作マニュアル</Link>
              <Link href="/admin/system" className="rounded-full px-4 py-2 font-bold text-white hover:bg-white/10">管理</Link>
              <Link href="/students/new" className="rounded-full bg-white px-4 py-2 font-bold text-[#123a5a]">生徒を登録</Link>
            </nav>
          </div>
        </header>
        <main className="page-shell py-8 sm:py-12">{children}</main>
        <footer className="mt-14 border-t border-[#dce7ef] bg-white/70 py-8">
          <div className="page-shell text-sm leading-7 text-[#60758a]">
            データはこのパソコンに保存されます。外部AIへの受け渡しは手動です。表示内容は合否判定ではありません。
          </div>
        </footer>
      </body>
    </html>
  );
}
