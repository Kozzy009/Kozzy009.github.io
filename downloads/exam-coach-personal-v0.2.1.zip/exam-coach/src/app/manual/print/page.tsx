import { MANUAL_CHAPTERS } from "@/domain/manual-content";
import { ManualPrintButton } from "@/components/manual-print-button";

const selected=[1,2,3,4,5,6,7,8,11,12,13,14,15,16,17,18,19,20];
export default function ManualPrintPage(){return <div className="print-document mx-auto max-w-[210mm] bg-white p-8 text-[#18324a]"><div className="print-controls mb-6 flex gap-3 print:hidden"><ManualPrintButton/><a className="btn-secondary" href="/manual">詳細マニュアルへ戻る</a></div><header className="border-b-2 pb-5"><p className="eyebrow">簡易版</p><h1 className="mt-2 text-3xl font-black">高校入試コーチ 操作ガイド</h1><p className="mt-3">起動・基本操作・バックアップの要点</p></header><div className="mt-6 grid gap-6">{selected.map((chapterNumber)=>{const[title,body]=MANUAL_CHAPTERS[chapterNumber-1];return <section className="break-inside-avoid" key={title}><h2 className="text-xl font-black">{title}</h2><p className="mt-2 leading-7">{body}</p></section>})}</div></div>}
