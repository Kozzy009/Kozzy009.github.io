"use client";

export default function ErrorPage({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return <div className="card card-pad mx-auto max-w-xl text-center"><p className="eyebrow">エラー</p><h1 className="mt-2 text-3xl font-black">読み込みに失敗しました</h1><p className="muted mt-3 leading-7">入力内容は変更せず、もう一度お試しください。続く場合は開発者へお知らせください。</p><button type="button" className="btn-primary mt-6" onClick={reset}>もう一度試す</button></div>;
}
