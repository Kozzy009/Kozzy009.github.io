import Link from "next/link";

export default function NotFound() {
  return <div className="card card-pad mx-auto max-w-xl text-center"><p className="eyebrow">ページ未検出</p><h1 className="mt-2 text-3xl font-black">ページが見つかりません</h1><p className="muted mt-3 leading-7">指定された生徒または記録が見つかりませんでした。</p><Link href="/" className="btn-primary mt-6">生徒一覧へ戻る</Link></div>;
}
