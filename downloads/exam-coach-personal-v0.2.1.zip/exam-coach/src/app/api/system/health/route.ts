import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  try {
    await prisma.$queryRaw`SELECT 1`;
    return NextResponse.json({ status: "ok", instanceId: process.env.EXAM_COACH_INSTANCE_ID, environment: process.env.APP_ENV ?? "development" });
  } catch {
    return NextResponse.json({ status: "error" }, { status: 503 });
  }
}
