import { prisma } from "@/lib/prisma";
import { storageProvider } from "@/lib/storage";

export async function GET(_: Request, { params }: { params: Promise<{ studentId: string; fileId: string }> }) {
  const { studentId, fileId } = await params;
  const file = await prisma.uploadedFile.findFirst({ where: { id: fileId, studentId } });
  if (!file) return new Response("Not found", { status: 404 });
  try {
    const bytes = await storageProvider.read(file.storagePath);
    await prisma.auditLog.create({ data: { studentId, action: "FILE_ACCESSED", entityType: "UploadedFile", entityId: file.id, metadata: { purpose: "REVIEW" } } });
    const body = bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) as ArrayBuffer;
    return new Response(body, { headers: { "Content-Type": file.mimeType, "Content-Length": String(file.sizeBytes), "Content-Disposition": `inline; filename*=UTF-8''${encodeURIComponent(file.originalFileName)}`, "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff" } });
  } catch {
    return new Response("File unavailable", { status: 404 });
  }
}
