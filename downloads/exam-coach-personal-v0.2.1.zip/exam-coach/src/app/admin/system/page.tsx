import Link from "next/link";
import { formatDate } from "@/lib/format";
import { formatBytes, getSystemStatus } from "@/lib/system-status";

export const dynamic = "force-dynamic";
export default async function SystemStatusPage() {
  const status = await getSystemStatus();
  const rows = [
    ["アプリバージョン", status.version], ["環境", status.environment],
    ["データベース接続", status.databaseConnected ? "正常" : "エラー"],
    ["データベースサイズ", formatBytes(status.databaseSizeBytes)], ["登録生徒数", `${status.studentCount}名`],
    ["学力テスト数", `${status.academicTestCount}件`], ["問題カルテ件数", `${status.problemCount}件`],
    ["復習カルテ件数", `${status.reviewCount}件`], ["問題集件数", `${status.workbookCount}件`],
    ["アップロードファイル数", `${status.uploadCount}件`],
    ["最新バックアップ日時", status.latestBackupAt ? formatDate(status.latestBackupAt) : "未実施"],
    ["最新バックアップ結果", status.latestBackupResult], ["ディスク空き容量", formatBytes(status.diskFreeBytes)],
    ["アプリ起動日時", status.appStartedAt.toLocaleString("ja-JP")],
  ];
  return <div><p className="eyebrow">管理</p><h1 className="mt-2 text-3xl font-black">システム状況</h1><p className="muted mt-3">秘密情報や保存先の実パスは表示しません。</p><dl className="card card-pad mt-6 grid gap-4 sm:grid-cols-2">{rows.map(([label,value])=><div className="rounded-xl bg-[#f3f8fb] p-4" key={label}><dt className="muted text-sm">{label}</dt><dd className="mt-1 font-black">{value}</dd></div>)}</dl><div className="mt-6 flex gap-3"><Link className="btn-primary" href="/admin/preflight">運用前チェック</Link><Link className="btn-secondary" href="/manual">操作マニュアル</Link></div></div>;
}
