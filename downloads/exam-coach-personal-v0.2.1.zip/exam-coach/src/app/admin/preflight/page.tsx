import Link from "next/link";
import { getPreflightChecks } from "@/lib/system-status";

export const dynamic = "force-dynamic";
export default async function PreflightPage() {
  const checks = await getPreflightChecks();
  const ready = checks.every((check) => check.ok);
  return <div><p className="eyebrow">管理</p><h1 className="mt-2 text-3xl font-black">運用前チェック</h1><div className={`mt-6 rounded-2xl p-5 font-black ${ready?"bg-[#dff4f2] text-[#145c58]":"bg-[#fff3c6] text-[#765d1d]"}`}>{ready?"試験運用を開始できます":"未完了の項目を確認してください"}</div><ul className="card card-pad mt-5 grid gap-3">{checks.map((check)=><li className="flex items-center gap-3" key={check.label}><span aria-hidden="true" className={`grid size-7 place-items-center rounded-full font-black ${check.ok?"bg-[#dff4f2] text-[#145c58]":"bg-[#ffe0d5] text-[#8a3b21]"}`}>{check.ok?"✓":"!"}</span><span>{check.label}</span></li>)}</ul><p className="muted mt-5 text-sm">「個人情報保護設定確認済み」は、運用者が方針を確認後に.env.production.localのPRIVACY_POLICY_CONFIRMEDをtrueへ変更します。</p><Link className="btn-secondary mt-6" href="/admin/system">システム状況へ戻る</Link></div>;
}
