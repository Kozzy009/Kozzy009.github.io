import Link from "next/link";
import { FirstRunGuide } from "@/components/first-run-guide";
import { GRADE_LABELS, formatDate } from "@/lib/format";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";
export default async function HomePage() {
  const now = new Date();
  const [students, pendingImports, pendingProblems, dueReviews, currentPlans, recentWorkbooks] = await Promise.all([
    prisma.student.findMany({
      include: {
        _count: { select: { academicTests: true, studySurveys: true, targetSchools: true } },
        analysisResults: { orderBy: { createdAt: "desc" }, take: 1, include: { subjectAnalyses: { orderBy: { priorityRank: "asc" }, take: 1 } } },
      },
      orderBy: { updatedAt: "desc" },
    }),
    prisma.manualAiImportSession.count({ where: { status: { in: ["RESULT_RECEIVED", "REVIEWING", "CONFIRMED"] } } }),
    prisma.generatedProblem.count({ where: { approvalStatus: "PENDING" } }),
    prisma.reviewProfile.count({ where: { status: "SCHEDULED", nextReviewOn: { lte: now } } }),
    prisma.weeklyStudyPlan.findMany({ where: { status: { in: ["CONFIRMED", "ACTIVE"] } }, orderBy: { weekStartOn: "desc" }, take: 4, include: { student: true } }),
    prisma.workbook.findMany({ orderBy: { createdAt: "desc" }, take: 4, include: { student: true, _count: { select: { items: true } } } }),
  ]);
  const recentStudent = students[0];
  const studentHref = (suffix: string) => recentStudent ? `/students/${recentStudent.id}${suffix}` : "/students/new";
  const shortcuts = [
    ["生徒を選ぶ", "#students"], ["新しい生徒を登録", "/students/new"],
    ["学力テストを登録", studentHref("/tests/new")], ["AI解析結果を取り込む", studentHref("/manual-ai/new")],
    ["学習プランを作成", studentHref("/plans")], ["個別問題集を作成", studentHref("/workbooks/new")],
  ];
  return <div>
    <section className="mb-7 rounded-[28px] bg-[#123a5a] p-6 text-white shadow-xl sm:p-9">
      <p className="text-xs font-black tracking-[.18em] text-[#9de2dc]">今日の学習支援をここから</p>
      <h1 className="mt-3 text-3xl font-black sm:text-5xl">高校入試コーチ</h1>
      <p className="mt-4 max-w-3xl leading-7 text-[#dceaf3]">地域を問わず、5教科の記録から次の一週間を整理。データは自分のパソコンに保存し、AIへの受け渡しは自分で確認して行います。</p>
      <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">{shortcuts.map(([label,href],index)=><Link className={`min-h-12 rounded-2xl px-5 py-3 font-black no-underline ${index===1?"bg-[#f28b66] text-white":"bg-white/10 text-white hover:bg-white/20"}`} href={href} key={label}>{label}</Link>)}</div>
    </section>
    <section className="mb-7 grid gap-4 sm:grid-cols-3" aria-label="このアプリの使い方">
      <article className="card card-pad"><h2 className="font-black">この端末に保存</h2><p className="muted mt-2 text-sm">成績・計画・添付資料は端末内に保存します。共有サーバーやアカウント登録は不要です。</p></article>
      <article className="card card-pad"><h2 className="font-black">AIは必要なときだけ</h2><p className="muted mt-2 text-sm">プロンプトを確認 → 自分のAIへ貼り付け → 回答JSONを読み込み → 確認・承認。基本の分析と計画はAIなしでも使えます。</p></article>
      <article className="card card-pad"><h2 className="font-black">自分でバックアップ</h2><p className="muted mt-2 text-sm">端末の故障に備えてバックアップを保管します。外部AIへ貼り付けた情報はそのサービスに渡ります。</p><Link className="mt-3 inline-block font-bold underline" href="/manual">保存・移行の手順を見る</Link></article>
    </section><FirstRunGuide/>
    <section className="mb-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {[["未確認のAI解析",pendingImports,"AI解析JSONを確認してください"],["未承認の生成問題",pendingProblems,"問題・正答・解説を確認してください"],["今日の復習予定",dueReviews,"生徒の復習カルテで確認できます"]].map(([label,count,note])=><article className="card card-pad" key={String(label)}><p className="muted text-sm font-bold">{label}</p><p className="mt-1 text-4xl font-black">{count}<span className="ml-1 text-base">件</span></p><p className="muted mt-2 text-sm">{note}</p></article>)}
    </section>
    <section className="mb-8 grid gap-5 lg:grid-cols-2">
      <div className="card card-pad"><h2 className="section-title">今週の学習プラン</h2><ul className="mt-4 grid gap-3">{currentPlans.length?currentPlans.map(plan=><li key={plan.id}><Link className="font-black text-[#1677a6]" href={`/students/${plan.studentId}/plans`}>{plan.student.displayName}・{formatDate(plan.weekStartOn)}開始</Link></li>):<li className="muted">現在の計画はありません。</li>}</ul></div>
      <div className="card card-pad"><h2 className="section-title">最近作成した問題集</h2><ul className="mt-4 grid gap-3">{recentWorkbooks.length?recentWorkbooks.map(workbook=><li key={workbook.id}><Link className="font-black text-[#1677a6]" href={`/students/${workbook.studentId}/workbooks/${workbook.id}`}>{workbook.name}</Link><span className="muted ml-2 text-sm">{workbook.student.displayName}・{workbook._count.items}問</span></li>):<li className="muted">問題集はまだありません。</li>}</ul></div>
    </section>
    <section id="students" className="scroll-mt-6"><p className="eyebrow">最近使用した生徒</p><h2 className="section-title mt-1">生徒を選ぶ</h2>{students.length===0?<div className="card card-pad mt-5 text-center"><p className="text-lg font-black">まだ生徒が登録されていません</p><Link className="btn-primary mt-5" href="/students/new">最初の生徒を登録</Link></div>:<div className="mt-5 grid gap-5 md:grid-cols-2">{students.map(student=>{const latest=student.analysisResults[0],top=latest?.subjectAnalyses[0];return <article className="card card-pad flex flex-col" key={student.id}><div className="flex items-start justify-between"><div><span className="pill">{GRADE_LABELS[student.grade]}</span><h3 className="mt-3 text-2xl font-black">{student.displayName}</h3><p className="muted text-sm">{student.schoolName??"学校名は未設定"}</p></div><span className="grid size-12 place-items-center rounded-2xl bg-[#dff4f2] text-xl font-black text-[#1677a6]">{student.displayName.slice(0,1)}</span></div><div className="my-5 grid grid-cols-3 gap-2 rounded-2xl bg-[#f3f8fb] p-3 text-center text-sm"><div><b className="block text-lg">{student._count.academicTests}</b>テスト</div><div><b className="block text-lg">{student._count.studySurveys}</b>回答</div><div><b className="block text-lg">{student._count.targetSchools}</b>志望校</div></div><p className="muted mb-4 text-sm">{top?`最新分析の優先候補 ${top.priorityRank}位を確認できます。`:"テストとアンケートを登録すると分析できます。"}</p><Link className="btn-primary mt-auto" href={`/students/${student.id}`}>この生徒を開く</Link></article>})}</div>}</section>
    <section className="mt-10 grid gap-4 sm:grid-cols-3"><Link className="card card-pad no-underline" href="/manual"><h2 className="font-black">操作マニュアル</h2><p className="muted mt-2 text-sm">日常操作と困ったときの確認方法</p></Link><Link className="card card-pad no-underline" href="/admin/system"><h2 className="font-black">システム状況</h2><p className="muted mt-2 text-sm">DB、件数、バックアップ、空き容量</p></Link><div className="card card-pad"><h2 className="font-black">バックアップ案内</h2><p className="muted mt-2 text-sm">起動メニューの「バックアップ」を使います。復元・更新の前にも現在の状態を保存します。</p></div></section>
  </div>;
}
