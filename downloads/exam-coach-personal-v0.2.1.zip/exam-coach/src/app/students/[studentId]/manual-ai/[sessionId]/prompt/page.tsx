import Link from "next/link";
import { notFound } from "next/navigation";
import { PageHeader } from "@/components/page-header";
import { PromptCopyButton } from "@/components/prompt-copy-button";
import { getManualAiSession } from "@/services/manual-ai-service";

export default async function Page({ params }: { params: Promise<{ studentId: string; sessionId: string }> }) {
  const { studentId, sessionId } = await params; const session = await getManualAiSession(studentId, sessionId); if (!session) notFound();
  return <div><PageHeader eyebrow="解析プロンプト" title="外部AIへ手動で渡す内容" description="問題資料と一緒に任意の汎用AIへ入力し、返されたJSONだけを次の画面へ貼り付けてください。" backHref={`/students/${studentId}/manual-ai`}/>
    <section className="notice-banner mb-5"><strong>個人情報を追加しないでください。</strong><p className="mt-2 text-sm">外部AIへ貼り付けた内容は、そのサービスへ送られます。テスト名・問題文・添付資料に氏名や学校名が残っていないか確認してください。</p><p className="mt-1 text-sm">このプロンプトには氏名を含めていません。外部サービスへ送る資料も、必要に応じて氏名部分を隠してください。</p></section>
    <section className="card card-pad"><dl className="mb-5 grid gap-3 text-sm sm:grid-cols-2"><div><dt className="muted">匿名ID</dt><dd className="break-all font-bold">{session.studentAnonymousId}</dd></div><div><dt className="muted">importToken</dt><dd className="break-all font-bold">{session.importToken}</dd></div></dl><textarea className="input min-h-[32rem] font-mono text-sm" readOnly value={session.generatedPrompt} aria-label="解析プロンプト"/><div className="mt-4 flex flex-wrap gap-3"><PromptCopyButton prompt={session.generatedPrompt} auditUrl={`/api/students/${studentId}/manual-ai/${sessionId}/copy`}/><Link className="btn-secondary" href={`/students/${studentId}/manual-ai/${sessionId}/result`}>AIのJSON結果を入力</Link></div></section>
  </div>;
}
