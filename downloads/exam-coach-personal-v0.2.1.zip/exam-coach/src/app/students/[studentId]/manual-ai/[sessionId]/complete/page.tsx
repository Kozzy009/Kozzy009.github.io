import Link from "next/link";
import { notFound } from "next/navigation";
import { PageHeader } from "@/components/page-header";
import { getManualAiSession } from "@/services/manual-ai-service";

export default async function Page({ params }: { params: Promise<{ studentId: string; sessionId: string }> }) { const {studentId,sessionId}=await params; const session=await getManualAiSession(studentId,sessionId); if(!session)notFound(); return <div><PageHeader eyebrow="取り込み完了" title="問題カルテへ反映しました" description="AI解析候補は人が確認した内容だけを反映しました。必要に応じて分析を更新してください。" backHref={`/students/${studentId}/manual-ai`}/><section className="card card-pad"><p className="text-lg font-black">{session.academicTest.name}・{session.questions.filter(q=>q.reviewStatus!=="EXCLUDED").length}問</p><div className="mt-5 flex flex-wrap gap-3"><Link className="btn-primary" href={`/students/${studentId}/problems`}>問題カルテを確認</Link><Link className="btn-secondary" href={`/students/${studentId}/reviews`}>復習カルテを確認</Link><Link className="btn-secondary" href={`/students/${studentId}/analysis`}>分析を更新・確認</Link></div></section></div>; }
