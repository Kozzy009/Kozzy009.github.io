import Link from "next/link";
import { notFound } from "next/navigation";
import { PageHeader } from "@/components/page-header";
import { StudentNav } from "@/components/student-nav";
import { MANUAL_AI_STATUS_LABELS } from "@/domain/manual-ai-labels";
import { formatDate, subjectLabel } from "@/lib/format";
import { getManualAiList } from "@/services/manual-ai-service";

export default async function Page({ params }: { params: Promise<{ studentId: string }> }) {
  const { studentId } = await params;
  const student = await getManualAiList(studentId);
  if (!student) notFound();
  return <div><StudentNav studentId={studentId}/><PageHeader eyebrow="外部AI・手動連携" title="AI解析取り込み" description="外部APIには接続しません。匿名化した依頼文とJSONを、人が受け渡して確認します。" backHref={`/students/${studentId}/files`}/>
    <div className="mb-6"><Link className="btn-primary" href={`/students/${studentId}/manual-ai/new`}>AI解析依頼を作成</Link></div>
    {student.manualAiImportSessions.length === 0 ? <section className="card card-pad text-center"><h2 className="text-xl font-black">解析依頼はありません</h2><p className="muted mt-2">対象テストと資料を選んで依頼文を作成してください。</p></section> : <div className="grid gap-4">{student.manualAiImportSessions.map((session) => {
      const next = session.status === "IMPORTED" ? "complete" : session.status === "CONFIRMED" ? "confirm" : session.status === "REVIEWING" ? "review" : session.status === "VALIDATION_FAILED" ? "result" : "prompt";
      return <article className="card card-pad" key={session.id}><div className="flex flex-wrap items-start justify-between gap-3"><div><p className="eyebrow">{subjectLabel(session.subject)}・{formatDate(session.createdAt)}</p><h2 className="mt-1 text-xl font-black">{session.academicTest.name}</h2><p className="muted mt-1 text-sm">候補 {session._count.questions}問</p></div><span className="pill">{MANUAL_AI_STATUS_LABELS[session.status] ?? session.status}</span></div><Link className="btn-secondary mt-4" href={`/students/${studentId}/manual-ai/${session.id}/${next}`}>続きを開く</Link></article>;
    })}</div>}
  </div>;
}
