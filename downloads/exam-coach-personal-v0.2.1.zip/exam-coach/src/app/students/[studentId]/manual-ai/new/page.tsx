import { notFound } from "next/navigation";
import { createManualAiRequest } from "@/app/manual-ai-actions";
import { PageHeader } from "@/components/page-header";
import { StudentNav } from "@/components/student-nav";
import { MANUAL_AI_SCHEMA_VERSION } from "@/domain/manual-ai-import";
import { SUBJECTS, SUBJECT_LABELS } from "@/domain/subjects";
import { FILE_TYPE_LABELS } from "@/domain/import-labels";
import { formatDate, GRADE_LABELS } from "@/lib/format";
import { getManualAiContext } from "@/services/manual-ai-service";

export default async function Page({ params, searchParams }: { params: Promise<{ studentId: string }>; searchParams: Promise<{ error?: string }> }) {
  const { studentId } = await params; const { error } = await searchParams;
  const student = await getManualAiContext(studentId); if (!student) notFound();
  return <div><StudentNav studentId={studentId}/><PageHeader eyebrow="AI解析依頼作成" title="解析する資料を指定" description="氏名は依頼文へ含めず、この依頼だけの匿名IDと照合トークンを発行します。" backHref={`/students/${studentId}/manual-ai`}/>{error ? <p className="error-banner mb-5">{error}</p> : null}
    <form action={createManualAiRequest} className="card card-pad grid gap-6"><input type="hidden" name="studentId" value={studentId}/>
      <div className="grid gap-5 sm:grid-cols-2"><div className="field"><label htmlFor="academicTestId">対象テスト</label><select id="academicTestId" name="academicTestId" required defaultValue=""><option value="" disabled>選択してください</option>{student.academicTests.map((test) => <option value={test.id} key={test.id}>{test.name}（{formatDate(test.takenOn)}）</option>)}</select></div><div className="field"><label htmlFor="subject">教科</label><select id="subject" name="subject" required defaultValue=""><option value="" disabled>選択してください</option>{SUBJECTS.map((s) => <option key={s} value={s}>{SUBJECT_LABELS[s]}</option>)}</select></div><div className="field"><label htmlFor="grade">学年</label><select id="grade" name="grade" defaultValue={student.grade}>{Object.entries(GRADE_LABELS).map(([key,label]) => <option key={key} value={key}>{label}</option>)}</select></div><div className="field"><label htmlFor="schemaVersion">出力スキーマ</label><select id="schemaVersion" name="schemaVersion" defaultValue={MANUAL_AI_SCHEMA_VERSION}><option value={MANUAL_AI_SCHEMA_VERSION}>{MANUAL_AI_SCHEMA_VERSION}</option></select></div></div>
      <fieldset><legend className="field-label">解析対象ファイル</legend><p className="help mt-1">対象テストに登録済みの資料だけが使用できます。</p><div className="mt-3 grid gap-3">{student.academicTests.flatMap((test) => test.uploadedFiles.map((file) => <label className="flex gap-3 rounded-xl border border-[#dce7ef] p-3" key={file.id}><input type="checkbox" name="fileIds" value={file.id}/><span><strong>{file.originalFileName}</strong><br/><span className="help">{test.name}・{FILE_TYPE_LABELS[file.fileType]}</span></span></label>))}</div></fieldset>
      <fieldset><legend className="field-label">使用する資料種別</legend><div className="mt-3 flex flex-wrap gap-4">{[["QUESTION_SHEET","問題用紙"],["STUDENT_ANSWER","本人解答"],["ANSWER_KEY","模範解答・採点基準"]].map(([value,label]) => <label className="flex items-center gap-2" key={value}><input type="checkbox" name="materialTypes" value={value}/>{label}</label>)}</div></fieldset>
      <button className="btn-primary justify-self-start" type="submit">プロンプトを作成</button>
    </form>
  </div>;
}
