import { notFound } from "next/navigation";
import { submitManualAiResult } from "@/app/manual-ai-actions";
import { PageHeader } from "@/components/page-header";
import { getManualAiSession } from "@/services/manual-ai-service";

export default async function Page({ params, searchParams }: { params: Promise<{ studentId: string; sessionId: string }>; searchParams: Promise<{ error?: string; invalid?: string }> }) {
  const { studentId, sessionId } = await params; const query = await searchParams; const session = await getManualAiSession(studentId, sessionId); if (!session) notFound(); const errors = Array.isArray(session.validationErrors) ? session.validationErrors.map(String) : [];
  return <div><PageHeader eyebrow="AI解析結果" title="JSONを検証" description="貼り付け、または5MB以内のapplication/json形式の.jsonファイルを使用できます。" backHref={`/students/${studentId}/manual-ai/${sessionId}/prompt`}/>{query.error ? <p className="error-banner mb-5">{query.error}</p> : null}{(query.invalid || errors.length > 0) ? <section className="error-banner mb-5"><p className="font-black">JSONを読み込めませんでした</p><ul className="mt-2 list-disc pl-5">{errors.map((e,i) => <li key={i}>{e}</li>)}</ul></section> : null}
    <form action={submitManualAiResult} className="card card-pad grid gap-5"><input type="hidden" name="studentId" value={studentId}/><input type="hidden" name="sessionId" value={sessionId}/><div className="field"><label htmlFor="jsonText">JSONを貼り付け</label><textarea id="jsonText" name="jsonText" className="min-h-[22rem] font-mono text-sm" defaultValue={session.status === "VALIDATION_FAILED" ? session.rawJson ?? "" : ""}/><p className="help">JSON全体だけのMarkdownコードブロックは自動で除去します。説明文が混在する場合はエラーになります。</p></div><div className="field"><label htmlFor="jsonFile">またはJSONファイル</label><input id="jsonFile" name="jsonFile" type="file" accept="application/json,.json"/><p className="help">貼り付けとファイルは同時に指定できません。</p></div><button className="btn-primary justify-self-start" type="submit">検証して確認画面へ</button></form>
  </div>;
}
