import { notFound } from "next/navigation";
import { cancelManualAiImport, importManualAiQuestions } from "@/app/manual-ai-actions";
import { PageHeader } from "@/components/page-header";
import { MANUAL_AI_JUDGMENT_LABELS } from "@/domain/manual-ai-labels";
import { getManualAiSession } from "@/services/manual-ai-service";

export default async function Page({ params, searchParams }: { params: Promise<{ studentId: string; sessionId: string }>; searchParams: Promise<{ error?: string }> }) {
  const { studentId, sessionId } = await params; const { error } = await searchParams; const session = await getManualAiSession(studentId, sessionId); if (!session) notFound(); const active=session.questions.filter(q=>q.reviewStatus!=="EXCLUDED");
  return <div><PageHeader eyebrow="問題カルテ反映確認" title="確認済み候補を取り込む" description="既存問題と一致した場合の扱いを選びます。無条件の上書きは行いません。" backHref={`/students/${studentId}/manual-ai/${sessionId}/review`}/>{error?<p className="error-banner mb-5">{error}</p>:null}{session.status!=="CONFIRMED"?<p className="error-banner">人による確認が完了していないため取り込めません。</p>:<>
    <section className="card card-pad"><h2 className="section-title">取り込み内容</h2><p className="muted mt-2">{session.academicTest.name}・{active.length}問（除外 {session.questions.length-active.length}問）</p><ul className="mt-4 grid gap-2">{active.map(q=><li className="rounded-xl border border-[#dce7ef] p-3" key={q.id}>大問 {q.majorQuestionNumber}{q.minorQuestionNumber?`・小問 ${q.minorQuestionNumber}`:""} ／ {MANUAL_AI_JUDGMENT_LABELS[q.judgment]??q.judgment}</li>)}</ul></section>
    <form action={importManualAiQuestions} className="card card-pad mt-6 grid gap-5"><input type="hidden" name="studentId" value={studentId}/><input type="hidden" name="sessionId" value={sessionId}/><fieldset><legend className="field-label">既存問題と重複した場合</legend><div className="mt-3 grid gap-3">{[["KEEP","既存を保持（重複候補を取り込まない）"],["UPDATE","確認済み候補で既存を更新"],["KEEP_BOTH","別問題として追加"],["CANCEL","重複があれば取り込み中止"]].map(([v,l])=><label className="rounded-xl border border-[#dce7ef] p-3" key={v}><input className="mr-2" type="radio" name="duplicateStrategy" value={v} required/>{l}</label>)}</div></fieldset><p className="notice-banner">不正解・無回答・部分正解は復習候補になります。要確認判定は自動確定せず「確認待ち」で作成します。</p><button className="btn-primary justify-self-start" type="submit">確認済みデータを取り込む</button></form>
    <form action={cancelManualAiImport} className="mt-4"><input type="hidden" name="studentId" value={studentId}/><input type="hidden" name="sessionId" value={sessionId}/><button className="btn-danger" type="submit">この取り込みを中止</button></form></>}
  </div>;
}
