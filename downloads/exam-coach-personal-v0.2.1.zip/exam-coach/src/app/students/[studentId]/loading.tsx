export default function Loading() {
  return <div className="card card-pad" role="status"><p className="font-black">カルテを読み込んでいます…</p><p className="muted mt-2 text-sm">登録データを安全にまとめています。</p></div>;
}
