import { notFound } from "next/navigation";
import { createStudySurvey } from "@/app/actions";
import { ErrorBanner } from "@/components/error-banner";
import { PageHeader } from "@/components/page-header";
import { StudentNav } from "@/components/student-nav";
import {
  CONFIDENCE_QUESTIONS, CONCENTRATION_QUESTIONS, DAY_OPTIONS, MOTIVATION_QUESTIONS,
  STUDY_METHOD_QUESTIONS, TIME_OF_DAY_OPTIONS,
} from "@/domain/learning-survey";
import { SUBJECTS, SUBJECT_LABELS } from "@/domain/subjects";
import { prisma } from "@/lib/prisma";
import { formatDate, toDateInput } from "@/lib/format";

function jsonScores(input: unknown): Record<string, number> {
  if (!input || typeof input !== "object" || Array.isArray(input)) return {};
  return Object.fromEntries(Object.entries(input).filter((entry): entry is [string, number] => typeof entry[1] === "number"));
}

function ScaleSection({ eyebrow, title, prefix, questions, previous }: {
  eyebrow: string; title: string; prefix: string; questions: Record<string, string>; previous: Record<string, number>;
}) {
  return <section className="card card-pad">
    <p className="eyebrow">{eyebrow}</p><h2 className="section-title mt-1">{title}</h2>
    <p className="help mt-2">1は「まだ当てはまらない」、5は「よく当てはまる」です。今の状態に近い値を選んでください。</p>
    <div className="mt-5 grid gap-3 sm:grid-cols-2">
      {Object.entries(questions).map(([key, label]) => <div key={key} className="field rounded-2xl border border-[#dce7ef] bg-[#f9fbfc] p-4">
        <label htmlFor={`${prefix}-${key}`}>{label}</label>
        <select id={`${prefix}-${key}`} name={`${prefix}-${key}`} defaultValue={previous[key] ?? 3} required>
          {[1, 2, 3, 4, 5].map((score) => <option key={score} value={score}>{score}</option>)}
        </select>
      </div>)}
    </div>
  </section>;
}

export default async function NewSurveyPage({ params, searchParams }: { params: Promise<{ studentId: string }>; searchParams: Promise<{ error?: string }> }) {
  const [{ studentId }, { error }] = await Promise.all([params, searchParams]);
  const student = await prisma.student.findUnique({
    where: { id: studentId },
    include: { studySurveys: { include: { subjects: true }, orderBy: [{ answeredOn: "desc" }, { createdAt: "desc" }], take: 1 } },
  });
  if (!student) notFound();
  const latest = student.studySurveys[0];
  const busyDays = Array.isArray(latest?.busyDays) ? latest.busyDays.map(String) : [];
  const availableDays = Array.isArray(latest?.availableDays) && latest.availableDays.length ? latest.availableDays.map(String) : DAY_OPTIONS.map(([key]) => key);
  const freeTextFields: Array<{ name: string; label: string; previous: string | null | undefined }> = [
    { name: "concern", label: "勉強で困っていること", previous: latest?.concern },
    { name: "recentAchievement", label: "最近できるようになったこと", previous: latest?.recentAchievement },
    { name: "anxiousSubjectsUnits", label: "特に不安な教科や単元", previous: latest?.anxiousSubjectsUnits },
    { name: "preferredStudyMethod", label: "希望する勉強方法", previous: latest?.preferredStudyMethod },
    { name: "familyConsideration", label: "家庭で配慮してほしいこと", previous: latest?.familyConsideration },
  ];
  return <div>
    <StudentNav studentId={student.id} />
    <PageHeader eyebrow="学習チェック" title="学習アンケート" description="時間だけでなく、意欲・自信・学び方・集中環境を組み合わせ、具体的な学習プランに反映します。" backHref={`/students/${student.id}`} />
    <ErrorBanner message={error} />
    {latest ? <p className="notice-banner mb-5">前回の回答は {formatDate(latest.answeredOn)} です。新しい回答を保存後、分析を実行してください。</p> : null}
    <form action={createStudySurvey} className="grid min-w-0 gap-6">
      <input type="hidden" name="studentId" value={student.id} />

      <section className="card card-pad">
        <div className="flex flex-wrap items-end justify-between gap-3"><div><p className="eyebrow">A．学習時間</p><h2 className="section-title mt-1">時間と曜日</h2></div><div className="field w-full sm:w-56"><label htmlFor="answeredOn">回答日</label><input id="answeredOn" name="answeredOn" type="date" max={toDateInput(new Date())} defaultValue={toDateInput(new Date())} required /></div></div>
        <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div className="field"><label htmlFor="currentWeekdayMinutes">現在の平日学習時間（分）</label><input id="currentWeekdayMinutes" name="currentWeekdayMinutes" type="number" min="0" max="600" defaultValue={latest?.currentWeekdayMinutes ?? 0} required /></div>
          <div className="field"><label htmlFor="currentWeekendMinutes">現在の休日学習時間（分）</label><input id="currentWeekendMinutes" name="currentWeekendMinutes" type="number" min="0" max="900" defaultValue={latest?.currentWeekendMinutes ?? 0} required /></div>
          <div className="field"><label htmlFor="weekdayAvailableMinutes">平日に無理なく確保できる時間（分）</label><input id="weekdayAvailableMinutes" name="weekdayAvailableMinutes" type="number" min="0" max="600" defaultValue={latest?.weekdayAvailableMinutes ?? 45} required /></div>
          <div className="field"><label htmlFor="weekendAvailableMinutes">休日に無理なく確保できる時間（分）</label><input id="weekendAvailableMinutes" name="weekendAvailableMinutes" type="number" min="0" max="900" defaultValue={latest?.weekendAvailableMinutes ?? 90} required /></div>
          <div className="field"><label htmlFor="concentrationMinutes">1回に集中できる時間（分）</label><input id="concentrationMinutes" name="concentrationMinutes" type="number" min="10" max="120" defaultValue={latest?.concentrationMinutes ?? 20} required /></div>
        </div>
        <fieldset className="mt-5"><legend className="field-label">学習できる曜日（1日以上）</legend><div className="mt-2 flex flex-wrap gap-3">{DAY_OPTIONS.map(([key, label]) => <label key={key} className="inline-flex items-center gap-2 rounded-xl border border-[#dce7ef] bg-white px-3 py-2 font-bold"><input type="checkbox" name="availableDays" value={key} defaultChecked={availableDays.includes(key)} />{label}</label>)}</div></fieldset>
        <fieldset className="mt-5"><legend className="field-label">部活動や習い事で忙しい曜日</legend><div className="mt-2 flex flex-wrap gap-3">{DAY_OPTIONS.map(([key, label]) => <label key={key} className="inline-flex items-center gap-2 rounded-xl border border-[#dce7ef] bg-white px-3 py-2 font-bold"><input type="checkbox" name="busyDays" value={key} defaultChecked={busyDays.includes(key)} />{label}</label>)}</div></fieldset>
        <div className="field mt-5 max-w-sm"><label htmlFor="preferredTimeOfDay">勉強しやすい時間帯</label><select id="preferredTimeOfDay" name="preferredTimeOfDay" defaultValue={latest?.preferredTimeOfDay ?? "EVENING"}>{TIME_OF_DAY_OPTIONS.map(([key, label]) => <option key={key} value={key}>{label}</option>)}</select></div>
      </section>

      <ScaleSection eyebrow="B．学習への意欲" title="取り組みたい気持ち" prefix="motivation" questions={MOTIVATION_QUESTIONS} previous={jsonScores(latest?.motivationAnswers)} />
      <ScaleSection eyebrow="C．学習への自信" title="できそうだと思う気持ち" prefix="confidence" questions={CONFIDENCE_QUESTIONS} previous={jsonScores(latest?.confidenceAnswers)} />
      <ScaleSection eyebrow="D．学習方法" title="普段の学び方" prefix="method" questions={STUDY_METHOD_QUESTIONS} previous={jsonScores(latest?.studyMethodAnswers)} />
      <ScaleSection eyebrow="E．集中と学習環境" title="集中しやすい状態" prefix="concentration" questions={CONCENTRATION_QUESTIONS} previous={jsonScores(latest?.concentrationAnswers)} />

      <section className="card card-pad min-w-0">
        <p className="eyebrow">F．教科ごとの感覚</p><h2 className="section-title mt-1">5教科の感じ方</h2>
        <p className="help mt-2">得意・苦手は、1「かなり苦手」〜5「かなり得意」の5段階です。分析では本人の認識と成績を分けて扱います。</p>
        <div className="table-wrap mt-5"><table className="data-table"><thead><tr><th>教科</th><th>直近7日の時間</th><th>好き</th><th>得意・苦手</th><th>自信</th><th>始めやすさ</th><th>何を学ぶか分かる</th><th>週の学習頻度</th></tr></thead><tbody>
          {SUBJECTS.map((subject) => { const prev = latest?.subjects.find((item) => item.subject === subject); return <tr key={subject}><td className="font-black">{SUBJECT_LABELS[subject]}</td>
            <td><input className="input min-w-24" aria-label={`${SUBJECT_LABELS[subject]}の学習時間`} name={`${subject}-weeklyStudyMinutes`} type="number" min="0" max="10080" defaultValue={prev?.weeklyStudyMinutes ?? 0} required /></td>
            <td><select className="input min-w-20" aria-label={`${SUBJECT_LABELS[subject]}の好き嫌い`} name={`${subject}-preferenceScore`} defaultValue={prev?.preferenceScore ?? 3}>{[1,2,3,4,5].map((n) => <option key={n}>{n}</option>)}</select></td>
            <td><select className="input min-w-28" aria-label={`${SUBJECT_LABELS[subject]}の得意・苦手`} name={`${subject}-selfEvaluationScore`} defaultValue={prev?.selfEvaluationScore ?? 3}><option value="1">1 かなり苦手</option><option value="2">2 やや苦手</option><option value="3">3 どちらでもない</option><option value="4">4 やや得意</option><option value="5">5 かなり得意</option></select></td>
            <td><select className="input min-w-20" aria-label={`${SUBJECT_LABELS[subject]}の自信`} name={`${subject}-confidenceLevel`} defaultValue={prev?.confidenceLevel ?? 3}>{[1,2,3,4,5].map((n) => <option key={n}>{n}</option>)}</select></td>
            <td><select className="input min-w-20" aria-label={`${SUBJECT_LABELS[subject]}の始めやすさ`} name={`${subject}-easeOfStartingScore`} defaultValue={prev?.easeOfStartingScore ?? 3}>{[1,2,3,4,5].map((n) => <option key={n}>{n}</option>)}</select></td>
            <td><select className="input min-w-20" aria-label={`${SUBJECT_LABELS[subject]}で何を学ぶか分かるか`} name={`${subject}-knowsWhatToStudyScore`} defaultValue={prev?.knowsWhatToStudyScore ?? 3}>{[1,2,3,4,5].map((n) => <option key={n}>{n}</option>)}</select></td>
            <td><select className="input min-w-24" aria-label={`${SUBJECT_LABELS[subject]}の学習頻度`} name={`${subject}-studyFrequencyPerWeek`} defaultValue={prev?.studyFrequencyPerWeek ?? 0}>{[0,1,2,3,4,5,6,7].map((n) => <option key={n} value={n}>週{n}日</option>)}</select></td>
          </tr>; })}
        </tbody></table></div>
      </section>

      <section className="card card-pad"><p className="eyebrow">G．自由記述</p><h2 className="section-title mt-1">伝えておきたいこと</h2><div className="mt-5 grid gap-5 sm:grid-cols-2">
        {freeTextFields.map(({ name, label, previous }) => <div className="field" key={name}><label htmlFor={name}>{label} <span className="muted text-sm font-normal">任意</span></label><textarea id={name} name={name} maxLength={1000} defaultValue={previous ?? ""} /></div>)}
      </div></section>
      <div className="flex justify-end"><button type="submit" className="btn-primary">回答を保存して分析へ</button></div>
    </form>
  </div>;
}
