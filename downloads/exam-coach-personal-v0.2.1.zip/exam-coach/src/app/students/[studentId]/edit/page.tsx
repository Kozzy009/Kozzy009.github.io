import Link from "next/link";
import { notFound } from "next/navigation";
import { updateStudent } from "@/app/actions";
import { ErrorBanner } from "@/components/error-banner";
import { PageHeader } from "@/components/page-header";
import { prisma } from "@/lib/prisma";

export default async function EditStudentPage({ params, searchParams }: { params: Promise<{ studentId: string }>; searchParams: Promise<{ error?: string }> }) {
  const [{ studentId }, { error }] = await Promise.all([params, searchParams]);
  const student = await prisma.student.findUnique({ where: { id: studentId } });
  if (!student) notFound();
  return (
    <div className="mx-auto max-w-2xl">
      <PageHeader eyebrow="プロフィール" title="プロフィール編集" description={`${student.displayName}さんの基本情報を更新します。`} backHref={`/students/${student.id}`} />
      <ErrorBanner message={error} />
      <form action={updateStudent} className="card card-pad grid gap-5">
        <input type="hidden" name="studentId" value={student.id} />
        <div className="grid gap-4 sm:grid-cols-2"><div className="field"><label htmlFor="displayName">ニックネーム</label><input id="displayName" name="displayName" defaultValue={student.displayName} maxLength={50} required /></div><div className="field"><label htmlFor="phoneticName">ふりがな</label><input id="phoneticName" name="phoneticName" defaultValue={student.phoneticName ?? ""} maxLength={100} /></div></div>
        <div className="field"><label htmlFor="grade">学年</label><select id="grade" name="grade" defaultValue={student.grade}><option value="JUNIOR_HIGH_1">中学1年</option><option value="JUNIOR_HIGH_2">中学2年</option><option value="JUNIOR_HIGH_3">中学3年</option></select></div>
        <div className="field"><label htmlFor="schoolName">中学校名</label><input id="schoolName" name="schoolName" defaultValue={student.schoolName ?? ""} maxLength={100} /></div>
        <div className="grid gap-4 sm:grid-cols-2"><div className="field"><label htmlFor="residenceArea">居住地域</label><input id="residenceArea" name="residenceArea" defaultValue={student.residenceArea ?? ""} maxLength={100} /></div><div className="field"><label htmlFor="examYear">受験予定年度</label><input id="examYear" name="examYear" type="number" min="2020" max="2100" defaultValue={student.examYear ?? ""} /></div><div className="field"><label htmlFor="clubActivity">部活動</label><input id="clubActivity" name="clubActivity" defaultValue={student.clubActivity ?? ""} maxLength={300} /></div><div className="field"><label htmlFor="lessons">習い事</label><input id="lessons" name="lessons" defaultValue={student.lessons ?? ""} maxLength={300} /></div></div>
        <div className="field"><label htmlFor="accommodations">配慮事項</label><textarea id="accommodations" name="accommodations" defaultValue={student.accommodations ?? ""} maxLength={1000} /></div>
        <div className="field"><label htmlFor="note">備考</label><textarea id="note" name="note" defaultValue={student.note ?? ""} maxLength={1000} /></div>
        <div className="flex flex-col-reverse gap-3 sm:flex-row sm:justify-end"><Link href={`/students/${student.id}`} className="btn-secondary">キャンセル</Link><button type="submit" className="btn-primary">更新する</button></div>
      </form>
    </div>
  );
}
