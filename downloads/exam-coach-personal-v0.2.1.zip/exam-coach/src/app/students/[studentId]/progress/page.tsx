import Link from "next/link";
import { notFound } from "next/navigation";
import { PageHeader } from "@/components/page-header";
import { ProgressChart, type ProgressPoint } from "@/components/progress-chart";
import { StudentNav } from "@/components/student-nav";
import { SUBJECTS, SUBJECT_LABELS, type SubjectKey } from "@/domain/subjects";
import { prisma } from "@/lib/prisma";
import { formatDate } from "@/lib/format";

export default async function ProgressPage({ params, searchParams }: { params: Promise<{ studentId: string }>; searchParams: Promise<{ updated?: string }> }) {
  const [{ studentId }, { updated }] = await Promise.all([params, searchParams]);
  const student = await prisma.student.findUnique({
    where: { id: studentId },
    include: {
      academicTests: { include: { scores: true }, orderBy: [{ takenOn: "asc" }, { createdAt: "asc" }] },
      analysisResults: { include: { subjectAnalyses: { orderBy: { priorityRank: "asc" }, take: 1 } }, orderBy: { createdAt: "desc" }, take: 1 },
    },
  });
  if (!student) notFound();
  const data: ProgressPoint[] = student.academicTests.map((test) => {
    const point: ProgressPoint = { label: formatDate(test.takenOn) };
    for (const subject of SUBJECTS) {
      const score = test.scores.find((item) => item.subject === subject);
      point[subject] = score ? (score.score / score.maxScore) * 100 : 0;
    }
    return point;
  });
  const top = student.analysisResults[0]?.subjectAnalyses[0]?.subject;
  const initialSubject: SubjectKey = SUBJECTS.includes(top as SubjectKey) ? top as SubjectKey : "MATH";

  return (
    <div>
      <StudentNav studentId={student.id} />
      <PageHeader eyebrow="成績推移" title="教科別成績推移" description="満点が違うテストも得点率にそろえて、変化を見やすくしています。テストの難易度差は補正していません。" backHref={`/students/${student.id}`} />
      {updated === "1" ? <p className="notice-banner mb-5">テスト結果を修正しました。学習傾向へ反映するには、分析画面で再分析してください。</p> : null}
      {data.length === 0 ? <div className="card card-pad text-center"><h2 className="text-xl font-black">テスト結果がまだありません</h2><p className="muted mt-2">テスト入力から5教科の結果を登録してください。</p></div> : <>
        {data.length === 1 ? <p className="notice-banner mb-5">1回分を表示しています。推移を確認するには2回以上の結果が必要です。</p> : null}
        <section className="card card-pad"><ProgressChart data={data} initialSubject={initialSubject} /></section>
        <section className="mt-7"><h2 className="mb-4 text-xl font-black">得点率の一覧</h2><div className="table-wrap"><table className="data-table"><thead><tr><th>テスト</th>{SUBJECTS.map((subject) => <th key={subject}>{SUBJECT_LABELS[subject]}</th>)}<th>操作</th></tr></thead><tbody>{student.academicTests.map((test) => <tr key={test.id}><td><span className="block font-bold">{test.name}</span><span className="muted text-xs">{formatDate(test.takenOn)}</span></td>{SUBJECTS.map((subject) => { const score = test.scores.find((item) => item.subject === subject); return <td key={subject}>{score ? `${((score.score / score.maxScore) * 100).toFixed(1)}%` : "—"}</td>; })}<td><Link className="font-black text-[#1677a6]" href={`/students/${student.id}/tests/${test.id}/edit`}>修正</Link></td></tr>)}</tbody></table></div></section>
      </>}
    </div>
  );
}
