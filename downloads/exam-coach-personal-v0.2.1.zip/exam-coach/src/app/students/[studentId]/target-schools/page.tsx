import { notFound } from "next/navigation";
import { deleteTargetSchool, saveTargetSchool } from "@/app/actions";
import { ErrorBanner } from "@/components/error-banner";
import { PageHeader } from "@/components/page-header";
import { StudentNav } from "@/components/student-nav";
import { prisma } from "@/lib/prisma";

export default async function TargetSchoolsPage({ params, searchParams }: { params: Promise<{ studentId: string }>; searchParams: Promise<{ error?: string }> }) {
  const [{ studentId }, { error }] = await Promise.all([params, searchParams]);
  const student = await prisma.student.findUnique({ where: { id: studentId }, include: { targetSchools: { orderBy: { preferenceRank: "asc" } } } });
  if (!student) notFound();
  return (
    <div>
      <StudentNav studentId={student.id} />
      <PageHeader eyebrow="志望校" title="志望校設定" description="志望順位と学校名を整理します。目標点は参考メモで、分析や合否判定には使いません。" backHref={`/students/${student.id}`} />
      <ErrorBanner message={error} />
      <div className="grid gap-6 lg:grid-cols-[.85fr_1.15fr]">
        <form action={saveTargetSchool} className="card card-pad grid content-start gap-4">
          <input type="hidden" name="studentId" value={student.id} />
          <h2 className="text-xl font-black">志望校を追加</h2>
          <div className="field"><label htmlFor="schoolName">学校名</label><input id="schoolName" name="schoolName" required maxLength={100} /></div>
          <div className="field"><label htmlFor="departmentName">学科</label><input id="departmentName" name="departmentName" maxLength={100} /></div>
          <div className="grid grid-cols-2 gap-3"><div className="field"><label htmlFor="preferenceRank">志望順位</label><input id="preferenceRank" name="preferenceRank" type="number" min="1" max="10" defaultValue="1" required /></div><div className="field"><label htmlFor="targetTotalScore">目標総合点</label><input id="targetTotalScore" name="targetTotalScore" type="number" min="0" max="500" /></div></div>
          <div className="field"><label htmlFor="note">メモ</label><textarea id="note" name="note" maxLength={500} /></div>
          <button type="submit" className="btn-primary">追加する</button>
        </form>
        <section>
          <h2 className="mb-4 text-xl font-black">登録済みの志望校</h2>
          {student.targetSchools.length === 0 ? <div className="card card-pad"><p className="muted">まだ志望校は登録されていません。</p></div> : <div className="grid gap-4">{student.targetSchools.map((school) => (
            <details key={school.id} className="card card-pad">
              <summary className="cursor-pointer list-none"><div className="flex items-center gap-3"><span className="grid size-10 place-items-center rounded-full bg-[#dff4f2] font-black text-[#1677a6]">{school.preferenceRank}</span><div><h3 className="font-black">{school.schoolName}{school.departmentName ? ` ${school.departmentName}` : ""}</h3><p className="muted text-sm">{school.targetTotalScore !== null ? `目標 ${school.targetTotalScore}点` : "目標点は未設定"}</p></div><span className="ml-auto text-sm font-bold text-[#1677a6]">編集</span></div></summary>
              <form action={saveTargetSchool} className="mt-5 grid gap-4 border-t border-[#dce7ef] pt-5">
                <input type="hidden" name="studentId" value={student.id} /><input type="hidden" name="targetSchoolId" value={school.id} />
                <div className="field"><label htmlFor={`school-${school.id}`}>学校名</label><input id={`school-${school.id}`} name="schoolName" defaultValue={school.schoolName} required /></div>
                <div className="field"><label htmlFor={`department-${school.id}`}>学科</label><input id={`department-${school.id}`} name="departmentName" defaultValue={school.departmentName ?? ""} /></div>
                <div className="grid grid-cols-2 gap-3"><div className="field"><label htmlFor={`rank-${school.id}`}>順位</label><input id={`rank-${school.id}`} name="preferenceRank" type="number" min="1" max="10" defaultValue={school.preferenceRank} required /></div><div className="field"><label htmlFor={`score-${school.id}`}>目標点</label><input id={`score-${school.id}`} name="targetTotalScore" type="number" min="0" max="500" defaultValue={school.targetTotalScore ?? ""} /></div></div>
                <div className="field"><label htmlFor={`note-${school.id}`}>メモ</label><textarea id={`note-${school.id}`} name="note" defaultValue={school.note ?? ""} /></div>
                <button type="submit" className="btn-secondary">変更を保存</button>
              </form>
              <form action={deleteTargetSchool} className="mt-3"><input type="hidden" name="studentId" value={student.id} /><input type="hidden" name="targetSchoolId" value={school.id} /><button type="submit" className="btn-danger">この志望校を削除</button></form>
            </details>
          ))}</div>}
        </section>
      </div>
    </div>
  );
}
