import Link from "next/link";
import { notFound } from "next/navigation";
import { deleteStudent, runAnalysis } from "@/app/actions";
import { StudentNav } from "@/components/student-nav";
import { SUBJECT_LABELS, type SubjectKey } from "@/domain/subjects";
import { GRADE_LABELS, formatDate } from "@/lib/format";
import { getOverviewKarte } from "@/services/karte-service";

function total(test: { scores: Array<{ score: number }> } | undefined) { return test?.scores.reduce((sum, score) => sum + score.score, 0) ?? null; }

export default async function StudentDetailPage({ params }: { params: Promise<{ studentId: string }> }) {
  const { studentId } = await params;
  const student = await getOverviewKarte(studentId);
  if (!student) notFound();
  const [latest, previous] = student.academicTests;
  const latestAnalysis = student.analysisResults[0];
  const priority = latestAnalysis?.subjectAnalyses[0];
  const survey = student.studySurveys[0];
  const plan = student.weeklyStudyPlans[0];
  const completed = plan?.items.filter((item) => item.studyRecord?.completed).length ?? 0;
  const completionRate = plan?.items.length ? Math.round(completed / plan.items.length * 100) : null;
  const latestTotal = total(latest); const previousTotal = total(previous);
  const strengths: string[] = [];
  const issues: string[] = [];
  for (const subject of latestAnalysis?.subjectAnalyses ?? []) {
    const rates = Array.isArray(subject.recentScoreRates) ? subject.recentScoreRates.filter((rate): rate is number => typeof rate === "number") : [];
    if (rates.length >= 3 && rates.at(-1)! > rates[0]) strengths.push(`${SUBJECT_LABELS[subject.subject as SubjectKey]}の得点が最近3回で上昇しています`);
    if (rates.length >= 3 && rates.at(-1)! < rates[0]) issues.push(`${SUBJECT_LABELS[subject.subject as SubjectKey]}の得点が最近3回で下降しています`);
  }
  if ((survey?.motivationScore ?? 0) >= 4) strengths.push("志望校への意欲が高い状態です");
  if ((survey?.reviewHabitScore ?? 5) < 3) issues.push("間違い直しの頻度を少しずつ増やす余地があります");
  if ((survey?.concentrationMinutes ?? 99) <= 20) issues.push("短い学習時間に区切る方が取り組みやすい可能性があります");
  return <div>
    <StudentNav studentId={student.id}/>
    <section className="mb-7 rounded-[28px] bg-[#123a5a] p-6 text-white sm:p-8"><div className="flex flex-col justify-between gap-5 lg:flex-row"><div><span className="pill bg-white/15 text-white">{GRADE_LABELS[student.grade]}</span><h1 className="mt-3 text-3xl font-black">{student.displayName}さんの受験カルテ</h1><p className="mt-2 text-[#dceaf3]">{student.schoolName ?? "中学校未設定"} ／ {student.examYear ? `${student.examYear}年度受験予定` : "受験年度未設定"}</p></div><Link className="btn-secondary self-start" href={`/students/${student.id}/edit`}>基本情報を編集</Link></div><dl className="mt-6 grid gap-3 border-t border-white/20 pt-5 text-sm sm:grid-cols-2 lg:grid-cols-4"><div><dt className="text-[#bcd4e4]">第一志望</dt><dd className="font-black">{student.targetSchools[0]?.schoolName ?? "未設定"}</dd></div><div><dt className="text-[#bcd4e4]">第二志望</dt><dd className="font-black">{student.targetSchools[1]?.schoolName ?? "未設定"}</dd></div><div><dt className="text-[#bcd4e4]">最新テスト／アンケート</dt><dd>{latest ? formatDate(latest.takenOn) : "未登録"} ／ {survey ? formatDate(survey.answeredOn) : "未回答"}</dd></div><div><dt className="text-[#bcd4e4]">今週の計画</dt><dd>{completionRate === null ? "未作成" : `完了率 ${completionRate}%`}</dd></div></dl></section>
    <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{[["最新テスト合計", latestTotal === null ? "未登録" : `${latestTotal}点`], ["前回との差", latestTotal === null || previousTotal === null ? "—" : `${latestTotal - previousTotal >= 0 ? "+" : ""}${latestTotal - previousTotal}点`], ["最新の自信度", survey ? `${survey.confidenceScore.toFixed(1)} / 5` : "未回答"], ["今週の完了率", completionRate === null ? "未作成" : `${completionRate}%`]].map(([label, value]) => <div className="card card-pad" key={label}><p className="muted text-sm">{label}</p><p className="mt-2 text-2xl font-black">{value}</p></div>)}</section>
    <div className="mt-7 grid gap-6 lg:grid-cols-2"><section className="card card-pad"><p className="eyebrow">今週の優先事項</p><h2 className="section-title mt-1">次に取り組む候補</h2>{priority ? <dl className="mt-4 grid gap-3"><div><dt className="muted text-sm">最優先教科・単元</dt><dd className="font-black">{SUBJECT_LABELS[priority.subject as SubjectKey]} ／ {priority.priorityUnit ?? "基礎・前回の誤答"}</dd></div><div><dt className="muted text-sm">理由</dt><dd>{priority.analysisComment}</dd></div><div><dt className="muted text-sm">推奨量</dt><dd>{survey ? `1回${Math.min(survey.concentrationMinutes, survey.confidenceScore < 3 ? 15 : 25)}分、3〜5問から` : "アンケート回答後に提案"}</dd></div><div><dt className="muted text-sm">次回復習</dt><dd>{student.reviewProfiles[0] ? `${formatDate(student.reviewProfiles[0].nextReviewOn)}・${student.reviewProfiles[0].problemProfile.unit}` : "復習対象なし"}</dd></div></dl> : <p className="notice-banner mt-4">分析を更新すると、優先教科と理由が表示されます。</p>}</section><section className="card card-pad"><p className="eyebrow">次に行うこと</p><h2 className="section-title mt-1">データに合わせた操作</h2><div className="mt-4 grid gap-3">{!latest && <Link className="btn-secondary" href={`/students/${student.id}/tests/new`}>学力テストを登録する</Link>}{!survey && <Link className="btn-secondary" href={`/students/${student.id}/surveys/new`}>学習アンケートに回答する</Link>}{(latest || survey) && <form action={runAnalysis}><input type="hidden" name="studentId" value={student.id}/><button className="btn-primary w-full" type="submit">分析を更新する</button></form>}{latestAnalysis && survey && <Link className="btn-secondary" href={`/students/${student.id}/plans?analysisId=${latestAnalysis.id}&surveyId=${survey.id}`}>学習プランを作成する</Link>}{plan && <Link className="btn-secondary" href={`/students/${student.id}/records`}>学習記録を入力する</Link>}{student.reviewProfiles[0] && <Link className="btn-secondary" href={`/students/${student.id}/reviews`}>復習を実施する</Link>}</div></section></div>
    <div className="mt-7 grid gap-6 lg:grid-cols-2"><section className="card card-pad"><h2 className="section-title">強みとして活かせそうな点</h2>{strengths.length ? <ul className="mt-4 grid gap-2">{strengths.slice(0,3).map((text) => <li key={text}>✓ {text}</li>)}</ul> : <p className="muted mt-4">データが増えると、強みの候補を表示します。</p>}</section><section className="card card-pad"><h2 className="section-title">現在の課題として見守る点</h2>{issues.length ? <ul className="mt-4 grid gap-2">{issues.slice(0,3).map((text) => <li key={text}>・{text}</li>)}</ul> : <p className="muted mt-4">現在、強く表示する課題はありません。</p>}</section></div>
    <section className="mt-8 border-t border-[#dce7ef] pt-6"><details><summary className="cursor-pointer font-bold text-[#8d3428]">生徒データを削除する</summary><div className="error-banner mt-4"><p className="mb-3 text-sm">関連する全カルテも削除され、元に戻せません。</p><form action={deleteStudent}><input type="hidden" name="studentId" value={student.id}/><button className="btn-danger" type="submit">すべて削除する</button></form></div></details></section>
  </div>;
}
