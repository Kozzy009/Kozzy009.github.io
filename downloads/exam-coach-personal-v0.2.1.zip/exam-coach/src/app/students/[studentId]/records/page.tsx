import Link from "next/link";
import { notFound } from "next/navigation";
import { PageHeader } from "@/components/page-header";
import { StudentNav } from "@/components/student-nav";
import { SUBJECT_LABELS } from "@/domain/subjects";
import { formatDate } from "@/lib/format";
import { getStudyRecordsKarte } from "@/services/karte-service";

export default async function RecordsPage({params}:{params:Promise<{studentId:string}>}){const{studentId}=await params;const student=await getStudyRecordsKarte(studentId);if(!student)notFound();const rows=student.weeklyStudyPlans.flatMap((plan)=>plan.items.filter((item)=>item.studyRecord).map((item)=>({plan,item,record:item.studyRecord!})));return <div><StudentNav studentId={student.id}/><PageHeader eyebrow="学習記録" title="実施結果の一覧" description="確定した週間プランで入力した時間、問題数、正答数をまとめます。" backHref={`/students/${student.id}`}/>{rows.length===0?<div className="card card-pad text-center"><h2 className="text-xl font-black">学習記録はまだありません</h2><p className="muted mt-2">学習プランを確定し、各項目の実施結果を入力してください。</p><Link className="btn-primary mt-4" href={`/students/${student.id}/plans`}>学習プランを確認する</Link></div>:<div className="table-wrap"><table className="data-table"><thead><tr><th>日付</th><th>教科・単元</th><th>実施</th><th>時間</th><th>問題数</th><th>正答</th><th>コメント</th></tr></thead><tbody>{rows.map(({item,record})=><tr key={record.id}><td>{formatDate(item.plannedOn)}</td><td><span className="font-black">{SUBJECT_LABELS[item.subject]}</span><br/><span className="muted text-xs">{item.unit}</span></td><td>{record.completed?"実施済み":"未完了"}</td><td>{record.actualMinutes}分</td><td>{record.attemptedCount}問</td><td>{record.correctCount}問</td><td>{record.studentComment??"—"}</td></tr>)}</tbody></table></div>}</div>}
