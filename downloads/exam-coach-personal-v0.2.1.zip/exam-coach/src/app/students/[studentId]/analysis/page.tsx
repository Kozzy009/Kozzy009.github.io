import Link from "next/link";
import { notFound } from "next/navigation";
import { z } from "zod";
import { runAnalysis } from "@/app/actions";
import { ErrorBanner } from "@/components/error-banner";
import { PageHeader } from "@/components/page-header";
import { StudentNav } from "@/components/student-nav";
import { TENDENCY_LABELS, type LearningTendencyType } from "@/domain/learning-analysis";
import { SUBJECT_LABELS, type SubjectKey } from "@/domain/subjects";
import { prisma } from "@/lib/prisma";
import { formatDate } from "@/lib/format";

const reasonsSchema = z.array(z.object({ category: z.string(), points: z.number(), text: z.string() }));
const summarySchema = z.object({
  currentWeeklyMinutes: z.number(), weeklyAvailableMinutes: z.number(), recommendedSessionMinutes: z.number(), recommendedDays: z.number(),
  motivationScore: z.number(), confidenceScore: z.number(), studyHabitScore: z.number(), reviewHabitScore: z.number(),
  concentrationScore: z.number(), environmentScore: z.number(), strengths: z.array(z.string()), challenges: z.array(z.string()),
  recommendedMethods: z.array(z.string()), notes: z.array(z.string()),
});

function stringArray(value: unknown): string[] {
  return Array.isArray(value) ? value.map(String) : [];
}
function recommendation(value: unknown): { statement: string; items: string[] } {
  if (!value || typeof value !== "object" || Array.isArray(value)) return { statement: "", items: [] };
  const record = value as Record<string, unknown>;
  return { statement: String(record.statement ?? ""), items: stringArray(record.items) };
}

function snapshotUpdatedAt(value: unknown, key: "testUpdatedAt" | "surveyUpdatedAt"): string | null {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const found = (value as Record<string, unknown>)[key];
  return typeof found === "string" ? found : null;
}

function snapshotTests(value: unknown): Array<{ id: string; updatedAt: string }> {
  if (!value || typeof value !== "object" || Array.isArray(value)) return [];
  const tests = (value as Record<string, unknown>).academicTests;
  if (!Array.isArray(tests)) return [];
  return tests.flatMap((test) => test && typeof test === "object" && !Array.isArray(test) && typeof test.id === "string" && typeof test.updatedAt === "string" ? [{ id: test.id, updatedAt: test.updatedAt }] : []);
}

function selfEvaluationLabel(value: number | null): string {
  return value === null ? "未回答" : ["", "かなり苦手", "やや苦手", "どちらともいえない", "やや得意", "かなり得意"][value] ?? "未回答";
}

export default async function AnalysisPage({ params, searchParams }: { params: Promise<{ studentId: string }>; searchParams: Promise<{ error?: string }> }) {
  const [{ studentId }, { error }] = await Promise.all([params, searchParams]);
  const student = await prisma.student.findUnique({
    where: { id: studentId },
    include: {
      academicTests: { orderBy: [{ takenOn: "desc" }, { createdAt: "desc" }], take: 3 },
      studySurveys: { orderBy: [{ answeredOn: "desc" }, { createdAt: "desc" }], take: 1 },
      analysisResults: { orderBy: { createdAt: "desc" }, take: 1, include: { academicTest: true, studySurvey: true, learningTendencies: { orderBy: { score: "desc" } }, subjectAnalyses: { orderBy: { priorityRank: "asc" } } } },
    },
  });
  if (!student) notFound();
  const analysis = student.analysisResults[0];
  const summary = analysis ? summarySchema.safeParse(analysis.summarySnapshot) : null;
  const recordedTests = analysis ? snapshotTests(analysis.inputSnapshot) : [];
  const recentTestsChanged = recordedTests.length > 0 && (recordedTests.length !== student.academicTests.length || recordedTests.some((test, index) => test.id !== student.academicTests[index]?.id || test.updatedAt !== student.academicTests[index]?.updatedAt.toISOString()));
  const isStale = Boolean(analysis && (
    analysis.academicTestId !== student.academicTests[0]?.id ||
    analysis.studySurveyId !== student.studySurveys[0]?.id ||
    (student.academicTests[0] && snapshotUpdatedAt(analysis.inputSnapshot, "testUpdatedAt") !== student.academicTests[0].updatedAt.toISOString()) ||
    (student.studySurveys[0] && snapshotUpdatedAt(analysis.inputSnapshot, "surveyUpdatedAt") !== student.studySurveys[0].updatedAt.toISOString())
    || recentTestsChanged
  ));
  const canRun = student.academicTests.length > 0 || student.studySurveys.length > 0;
  return <div>
    <StudentNav studentId={student.id} />
    <PageHeader eyebrow="学習の見通し" title="学習傾向・学習タイプ・優先教科" description="アンケートと成績を固定ルールで組み合わせます。結果は可能性を示す学習支援で、合否や能力の判定ではありません。" backHref={`/students/${student.id}`} />
    <ErrorBanner message={error} />
    <section className="card card-pad mb-7 flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-center"><div><h2 className="text-lg font-black">最新データで分析</h2><p className="muted mt-1 text-sm">新しいテスト、アンケート、学習実績を追加したら再分析してください。</p></div><form action={runAnalysis}><input type="hidden" name="studentId" value={student.id} /><button type="submit" className="btn-primary" disabled={!canRun}>{analysis ? "もう一度分析する" : "分析を実行する"}</button></form></section>
    {!canRun ? <p className="notice-banner">テスト結果またはアンケートを先に登録してください。</p> : null}
    {isStale ? <p className="notice-banner mb-5">新しい入力があります。再分析すると最新の状態を反映できます。</p> : null}
    {analysis ? <>
      <div className="mb-5 flex flex-wrap items-center gap-3"><span className="pill">{analysis.status === "COMPLETE" ? "通常判定" : "暫定判定"}</span><span className="muted text-sm">分析日 {formatDate(analysis.createdAt)} ／ {analysis.ruleVersion}</span></div>

      {summary?.success ? <section className="card card-pad mb-7"><p className="eyebrow">学習状況のまとめ</p><h2 className="section-title mt-1">今の学び方の目安</h2>
        <dl className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {[ ["現在の週間学習時間", `${summary.data.currentWeeklyMinutes}分`], ["無理なく確保可能", `${summary.data.weeklyAvailableMinutes}分`], ["1回の目安", `${summary.data.recommendedSessionMinutes}分`], ["推奨日数", `週${summary.data.recommendedDays}日`], ["学習意欲", `${summary.data.motivationScore.toFixed(1)} / 5`], ["学習への自信", `${summary.data.confidenceScore.toFixed(1)} / 5`], ["学習習慣", `${summary.data.studyHabitScore.toFixed(1)} / 5`], ["解き直し習慣", `${summary.data.reviewHabitScore.toFixed(1)} / 5`] ].map(([label, value]) => <div key={label} className="rounded-2xl bg-[#f3f8fb] p-4"><dt className="muted text-sm">{label}</dt><dd className="mt-1 text-xl font-black">{value}</dd></div>)}
        </dl>
        <div className="mt-6 grid gap-5 lg:grid-cols-2"><div><h3 className="font-black text-[#1677a6]">強み</h3><ul className="mt-2 grid gap-2">{summary.data.strengths.map((item) => <li key={item}>✓ {item}</li>)}</ul></div><div><h3 className="font-black text-[#a05b1d]">現在の課題</h3><ul className="mt-2 grid gap-2">{summary.data.challenges.map((item) => <li key={item}>・{item}</li>)}</ul></div></div>
        <div className="mt-6 rounded-2xl bg-[#eaf7f5] p-5"><h3 className="font-black">推奨する学習方法</h3><ul className="mt-2 grid gap-2">{summary.data.recommendedMethods.length ? summary.data.recommendedMethods.map((item) => <li key={item}>・{item}</li>) : <li>・まず学習実績を記録し、次回の分析材料を増やしましょう</li>}</ul></div>
        <div className="mt-4 text-sm text-[#60758a]">{summary.data.notes.map((item) => <p key={item}>※ {item}</p>)}</div>
      </section> : null}

      <section className="mb-7"><p className="eyebrow">学習タイプ</p><h2 className="section-title mt-1">当てはまる可能性がある傾向</h2>
        {analysis.learningTendencies.length ? <div className="mt-4 grid gap-4 lg:grid-cols-2">{analysis.learningTendencies.map((item) => { const rec = recommendation(item.recommendation); return <article key={item.id} className="card card-pad"><div className="flex justify-between gap-3"><h3 className="text-lg font-black">{TENDENCY_LABELS[item.tendencyType as LearningTendencyType] ?? item.tendencyType}</h3><span className="pill">根拠 {item.score}点</span></div><p className="mt-3 leading-7">{rec.statement}</p><p className="muted mt-3 text-sm">{stringArray(item.evidence).join("／")}</p><ul className="mt-3 grid gap-1 text-sm">{rec.items.map((recommend) => <li key={recommend}>・{recommend}</li>)}</ul></article>; })}</div> : <p className="notice-banner mt-4">現時点では強く当てはまる学習タイプがありません。回答や成績が増えると再判定されます。</p>}
      </section>

      <section id="priority-subjects"><p className="eyebrow">優先教科</p><h2 className="section-title mt-1">本人の認識と成績を並べた5教科分析</h2><div className="mt-4 grid gap-5 lg:grid-cols-2">{analysis.subjectAnalyses.map((item, index) => { const reasons = reasonsSchema.safeParse(item.reasonsSnapshot); const rates = Array.isArray(item.recentScoreRates) ? item.recentScoreRates.filter((rate): rate is number => typeof rate === "number") : []; return <article key={item.id} className={`card card-pad ${index === 0 ? "border-[#e7cf79] bg-[#fffdf4]" : ""}`}><div className="flex items-start justify-between gap-4"><div><p className="text-sm font-black text-[#1677a6]">優先候補 {item.priorityRank}位</p><h3 className="mt-1 text-2xl font-black">{SUBJECT_LABELS[item.subject as SubjectKey]}</h3></div><div className="text-right"><span className="text-3xl font-black">{item.priorityScore}</span><span className="muted text-sm">点</span></div></div><dl className="mt-4 grid gap-3 rounded-2xl bg-[#f3f8fb] p-4 text-sm sm:grid-cols-2"><div><dt className="muted">本人の認識</dt><dd className="mt-1 font-black">{selfEvaluationLabel(item.selfEvaluationScore)}</dd></div><div><dt className="muted">自信</dt><dd className="mt-1 font-black">{item.confidenceLevel === null ? "未回答" : `${item.confidenceLevel}/5`}</dd></div><div><dt className="muted">最近3回の得点率</dt><dd className="mt-1 font-black">{rates.length ? rates.map((rate) => `${rate.toFixed(1)}%`).join(" → ") : "データなし"}</dd></div><div><dt className="muted">判定区分</dt><dd className="mt-1 font-black">{item.recognitionLabel}</dd></div></dl><p className="mt-4 rounded-xl bg-white p-4 leading-7"><span className="font-black">分析：</span>{item.analysisComment}</p><details className="mt-4"><summary className="cursor-pointer font-black text-[#1677a6]">優先順位の詳しい理由</summary><div className="mt-3 grid gap-2">{reasons.success ? reasons.data.map((reason, reasonIndex) => <div key={`${reason.category}-${reasonIndex}`} className="flex gap-3 text-sm leading-6"><span className={`mt-1 inline-flex h-6 min-w-9 items-center justify-center rounded-full text-xs font-black ${reason.points > 0 ? "bg-[#fff3c6] text-[#765d1d]" : "bg-[#edf3f6] text-[#60758a]"}`}>+{reason.points}</span><p>{reason.text}</p></div>) : <p className="muted">分析理由を読み込めませんでした。</p>}</div></details></article>; })}</div></section>
      <div className="mt-7 flex flex-col items-start justify-between gap-4 rounded-2xl bg-[#123a5a] p-6 text-white sm:flex-row sm:items-center"><div><h2 className="text-xl font-black">分析を学習プランへ反映</h2><p className="mt-1 text-sm text-[#dceaf3]">自動提案を確認・編集してから確定できます。</p></div>{analysis.studySurveyId ? <Link className="btn-secondary" href={`/students/${student.id}/plans?analysisId=${analysis.id}&surveyId=${analysis.studySurveyId}`}>この分析結果から学習プランを作成する</Link> : <Link className="btn-secondary" href={`/students/${student.id}/surveys/new`}>学習アンケートに回答する</Link>}</div>
      <div className="mt-7 rounded-2xl border border-[#dce7ef] bg-white p-5 text-sm leading-7"><p className="font-black">使用データ</p><p className="muted mt-1">テスト: {analysis.academicTest ? `${analysis.academicTest.name}（${formatDate(analysis.academicTest.takenOn)}）` : "なし"} ／ アンケート: {analysis.studySurvey ? formatDate(analysis.studySurvey.answeredOn) : "なし"}</p></div>
    </> : null}
  </div>;
}
