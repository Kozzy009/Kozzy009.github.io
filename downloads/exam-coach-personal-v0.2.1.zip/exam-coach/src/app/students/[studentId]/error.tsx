"use client";

export default function KarteError({ reset }: { error: Error; reset: () => void }) {
  return <div className="error-banner"><h2 className="font-black">カルテを表示できませんでした</h2><p className="mt-2 text-sm">時間をおいてもう一度お試しください。入力済みデータは削除されません。</p><button className="btn-secondary mt-4" type="button" onClick={reset}>もう一度読み込む</button></div>;
}
