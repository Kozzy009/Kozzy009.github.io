/* eslint-disable @next/next/no-img-element -- preview dimensions are unknown and the protected source must not pass through the public image optimizer */
import Link from "next/link";
import { notFound } from "next/navigation";
import { bulkReviewCandidates, deleteImportCandidate, saveExtractedItem, saveImportCandidate } from "@/app/import-actions";
import { ErrorBanner } from "@/components/error-banner";
import { PageHeader } from "@/components/page-header";
import { StudentNav } from "@/components/student-nav";
import { GRADING_LABELS, REVIEW_LABELS } from "@/domain/import-labels";
import { SUBJECTS, SUBJECT_LABELS } from "@/domain/subjects";
import { getImportSession } from "@/services/file-import-service";

const statuses = ["CONFIRMED", "CORRECTED", "EXCLUDED", "UNDETERMINED"];
type Session = NonNullable<Awaited<ReturnType<typeof getImportSession>>>;
type Candidate = Session["candidates"][number];

function CandidateForm({ studentId, sessionId, candidate }: { studentId: string; sessionId: string; candidate?: Candidate }) {
  return <form action={saveImportCandidate} className="mt-4 grid gap-3">
    <input type="hidden" name="studentId" value={studentId}/><input type="hidden" name="sessionId" value={sessionId}/>
    {candidate ? <input type="hidden" name="candidateId" value={candidate.id}/> : null}
    <div className="grid gap-3 sm:grid-cols-4">
      <label className="field"><span>教科</span><select name="subject" defaultValue={candidate?.subject ?? "MATH"}>{SUBJECTS.map(subject => <option value={subject} key={subject}>{SUBJECT_LABELS[subject]}</option>)}</select></label>
      <label className="field"><span>大問</span><input name="majorQuestionNumber" required defaultValue={candidate?.majorQuestionNumber}/></label>
      <label className="field"><span>小問</span><input name="minorQuestionNumber" defaultValue={candidate?.minorQuestionNumber ?? ""}/></label>
      <label className="field"><span>ページ</span><input value={candidate?.pageNumber ?? "—"} readOnly/></label>
    </div>
    <label className="field"><span>問題文</span><textarea name="questionText" defaultValue={candidate?.questionText ?? ""}/></label>
    <div className="grid gap-3 sm:grid-cols-2"><label className="field"><span>本人解答</span><textarea name="answerText" defaultValue={candidate?.answerText ?? ""}/></label><label className="field"><span>正答</span><textarea name="correctAnswer" defaultValue={candidate?.correctAnswer ?? ""}/></label></div>
    <div className="grid gap-3 sm:grid-cols-4">
      <label className="field"><span>分野</span><input name="field" defaultValue={candidate?.field ?? ""}/></label><label className="field"><span>単元</span><input name="unit" defaultValue={candidate?.unit ?? ""}/></label>
      <label className="field"><span>問題形式</span><input name="questionType" defaultValue={candidate?.questionType ?? "短答"}/></label><label className="field"><span>配点</span><input name="score" type="number" min="0" max="100" defaultValue={candidate?.score ?? 0}/></label>
      <label className="field"><span>難易度</span><select name="difficulty" defaultValue={candidate?.difficulty ?? "BASIC"}><option value="BASIC">基礎</option><option value="STANDARD">標準</option><option value="ADVANCED">応用</option></select></label>
      <label className="field"><span>正誤判定</span><select name="gradingStatus" defaultValue={candidate?.gradingStatus ?? "NEEDS_REVIEW"}>{Object.entries(GRADING_LABELS).map(([value,label]) => <option value={value} key={value}>{label}</option>)}</select></label>
      <label className="field"><span>確認状態</span><select name="reviewStatus" defaultValue={candidate?.reviewStatus === "UNREVIEWED" ? "CONFIRMED" : candidate?.reviewStatus ?? "CORRECTED"}>{statuses.map(value => <option value={value} key={value}>{REVIEW_LABELS[value]}</option>)}</select></label>
      <label className="field"><span>確信度</span><input value={candidate?.confidence == null ? "—" : `${Math.round(candidate.confidence * 100)}%`} readOnly/></label>
    </div>
    {candidate?.hasFigure ? <p className="notice-banner">図表あり・確認が必要</p> : null}
    {candidate?.matchStatus === "NEEDS_CONFIRMATION" ? <p className="error-banner">対応付け確認が必要です。</p> : null}
    <label className="field"><span>修正メモ</span><input name="correctionNotes" defaultValue={candidate?.correctionNotes ?? ""}/></label>
    <button className="btn-secondary" type="submit">{candidate ? "保存して続ける" : "行を追加"}</button>
  </form>;
}

export default async function Page({ params, searchParams }: { params: Promise<{ studentId: string; sessionId: string }>; searchParams: Promise<{ error?: string; saved?: string }> }) {
  const [{ studentId, sessionId }, query] = await Promise.all([params, searchParams]); const session = await getImportSession(studentId, sessionId); if (!session) notFound();
  const scoreItems = session.uploadedFiles.flatMap(file => file.ocrJobs.flatMap(job => job.extractedItems)).filter(item => item.itemType === "SCORE_FIELD"); const preview = session.uploadedFiles[0];
  return <div><StudentNav studentId={studentId}/><PageHeader eyebrow="読み取り確認" title="候補を確認・修正" description="確信度にかかわらず、人が確認するまで確定できません。" backHref={`/students/${studentId}/files`}/><ErrorBanner message={query.error}/>{query.saved ? <p className="notice-banner mb-4">修正内容を保存しました。</p> : null}
    <div className="grid gap-6 lg:grid-cols-[minmax(0,0.85fr)_minmax(0,1.15fr)]">
      <aside className="card card-pad lg:sticky lg:top-4 lg:self-start"><h2 className="section-title">元ファイル</h2>{preview ? <><p className="mt-2 break-all text-sm">{preview.originalFileName}</p>{preview.mimeType.startsWith("image/") ? <img className="mt-4 max-h-[70vh] w-full object-contain" alt="確認用の元ファイル" src={`/api/students/${studentId}/files/${preview.id}`}/> : <iframe className="mt-4 h-[65vh] w-full" title="確認用PDF" src={`/api/students/${studentId}/files/${preview.id}`}/>}</> : <p>元ファイルがありません。</p>}</aside>
      <main className="min-w-0"><div className="mb-4 flex flex-wrap gap-3"><Link className="btn-secondary" href={`/students/${studentId}/imports/${sessionId}/mapping`}>問題対応付け</Link><Link className="btn-primary" href={`/students/${studentId}/imports/${sessionId}/confirm`}>取り込み確認へ</Link></div>
        {scoreItems.length ? <section className="card card-pad mb-5"><h2 className="section-title">成績表の項目候補</h2><div className="mt-4 grid gap-3">{scoreItems.map(item => <form action={saveExtractedItem} className="grid gap-2 rounded-xl border border-[#dce7ef] p-3 sm:grid-cols-[1fr_2fr_1fr_auto]" key={item.id}><input type="hidden" name="studentId" value={studentId}/><input type="hidden" name="sessionId" value={sessionId}/><input type="hidden" name="itemId" value={item.id}/><label className="field"><span>項目</span><input value={item.fieldName} readOnly/></label><label className="field"><span>修正後の値</span><input name="correctedValue" defaultValue={item.correctedValue ?? item.normalizedValue ?? item.rawValue ?? ""}/></label><label className="field"><span>状態</span><select name="reviewStatus" defaultValue={item.reviewStatus === "UNREVIEWED" ? "CONFIRMED" : item.reviewStatus}>{statuses.map(value => <option value={value} key={value}>{REVIEW_LABELS[value]}</option>)}</select></label><button className="btn-secondary self-end">保存</button></form>)}</div></section> : null}
        {session.candidates.length ? <form action={bulkReviewCandidates} className="card card-pad mb-5"><input type="hidden" name="studentId" value={studentId}/><input type="hidden" name="sessionId" value={sessionId}/><h2 className="section-title">複数選択</h2><div className="mt-3 grid gap-2">{session.candidates.map(candidate => <label key={candidate.id}><input className="mr-2" type="checkbox" name="candidateIds" value={candidate.id}/>{SUBJECT_LABELS[candidate.subject]} 大問{candidate.majorQuestionNumber}-{candidate.minorQuestionNumber}（{REVIEW_LABELS[candidate.reviewStatus]}）</label>)}</div><div className="mt-4 flex flex-wrap gap-3"><button className="btn-secondary" name="bulkAction" value="confirm">選択を一括確認</button><button className="btn-secondary" name="bulkAction" value="exclude">選択を一括除外</button></div></form> : <p className="card card-pad">候補はまだありません。下のフォームから手入力できます。</p>}
        <div className="grid gap-4">{session.candidates.map(candidate => <article className="card card-pad" key={candidate.id}><h2 className="font-black">{SUBJECT_LABELS[candidate.subject]} 大問{candidate.majorQuestionNumber}-{candidate.minorQuestionNumber}</h2><p className="muted mt-1 text-sm">{REVIEW_LABELS[candidate.reviewStatus]} ／ {GRADING_LABELS[candidate.gradingStatus]}</p><CandidateForm studentId={studentId} sessionId={sessionId} candidate={candidate}/><form action={deleteImportCandidate} className="mt-3"><input type="hidden" name="studentId" value={studentId}/><input type="hidden" name="sessionId" value={sessionId}/><input type="hidden" name="candidateId" value={candidate.id}/><button className="btn-danger">この候補行を削除</button></form></article>)}</div>
        <details className="card card-pad mt-5"><summary className="cursor-pointer font-black">行を追加</summary><CandidateForm studentId={studentId} sessionId={sessionId}/></details>
      </main>
    </div>
  </div>;
}
