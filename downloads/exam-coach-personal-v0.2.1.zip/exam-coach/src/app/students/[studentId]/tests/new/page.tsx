import Link from "next/link";
import { notFound } from "next/navigation";
import { createAcademicTest } from "@/app/actions";
import { ErrorBanner } from "@/components/error-banner";
import { PageHeader } from "@/components/page-header";
import { StudentNav } from "@/components/student-nav";
import { SUBJECTS, SUBJECT_LABELS } from "@/domain/subjects";
import { prisma } from "@/lib/prisma";
import { toDateInput } from "@/lib/format";

export default async function NewTestPage({ params, searchParams }: { params: Promise<{ studentId: string }>; searchParams: Promise<{ error?: string }> }) {
  const [{ studentId }, { error }] = await Promise.all([params, searchParams]);
  const student = await prisma.student.findUnique({
    where: { id: studentId },
    include: { academicTests: { include: { scores: true }, orderBy: [{ takenOn: "desc" }, { createdAt: "desc" }], take: 5 } },
  });
  if (!student) notFound();
  return (
    <div>
      <StudentNav studentId={student.id} />
      <PageHeader eyebrow="テスト結果" title="学力テスト結果を入力" description="結果は学習の順番を考える材料です。点数だけで学力を決めつけることはありません。" backHref={`/students/${student.id}`} />
      <ErrorBanner message={error} />
      <div className="grid gap-6 xl:grid-cols-[1.1fr_.9fr]">
        <form action={createAcademicTest} className="card card-pad grid gap-5">
          <input type="hidden" name="studentId" value={student.id} />
          <div className="grid gap-4 sm:grid-cols-2"><div className="field"><label htmlFor="name">テスト名</label><input id="name" name="name" placeholder="例：第3回 学力確認テスト" required maxLength={100} /></div><div className="field"><label htmlFor="takenOn">受験日</label><input id="takenOn" name="takenOn" type="date" max={toDateInput(new Date())} defaultValue={toDateInput(new Date())} required /></div></div>
          <fieldset><legend className="mb-3 text-lg font-black">5教科の得点</legend><p className="help mb-4">平均点と無回答率は分かる場合だけ入力してください。</p><div className="grid gap-3">{SUBJECTS.map((subject) => <div key={subject} className="grid gap-3 rounded-2xl bg-[#f3f8fb] p-3 sm:grid-cols-4"><div className="field"><label htmlFor={`${subject}-score`}>{SUBJECT_LABELS[subject]}の得点</label><input id={`${subject}-score`} name={`${subject}-score`} type="number" min="0" defaultValue="0" required /></div><div className="field"><label htmlFor={`${subject}-maxScore`}>満点</label><input id={`${subject}-maxScore`} name={`${subject}-maxScore`} type="number" min="1" max="500" defaultValue="100" required /></div><div className="field"><label htmlFor={`${subject}-averageScore`}>平均点（任意）</label><input id={`${subject}-averageScore`} name={`${subject}-averageScore`} type="number" min="0" max="500" step="0.1" /></div><div className="field"><label htmlFor={`${subject}-unansweredRate`}>無回答率%（任意）</label><input id={`${subject}-unansweredRate`} name={`${subject}-unansweredRate`} type="number" min="0" max="100" step="0.1" /></div></div>)}</div></fieldset>
          <div className="field"><label htmlFor="note">メモ <span className="muted text-sm font-normal">任意</span></label><textarea id="note" name="note" maxLength={500} placeholder="テストを受けたときに気づいたこと" /></div>
          <button type="submit" className="btn-primary">結果を保存する</button>
        </form>
        <section><h2 className="mb-4 text-xl font-black">最近のテスト</h2>{student.academicTests.length === 0 ? <div className="card card-pad"><p className="muted">まだテスト結果はありません。</p></div> : <div className="grid gap-3">{student.academicTests.map((test) => { const total = test.scores.reduce((sum, score) => sum + score.score, 0); const max = test.scores.reduce((sum, score) => sum + score.maxScore, 0); return <article key={test.id} className="card p-5"><div className="flex justify-between gap-3"><div><h3 className="font-black">{test.name}</h3><p className="muted mt-1 text-sm">{toDateInput(test.takenOn)}</p><Link className="mt-3 inline-flex text-sm font-black text-[#1677a6]" href={`/students/${student.id}/tests/${test.id}/edit`}>結果を修正する →</Link></div><p className="text-right"><span className="block text-xl font-black">{((total / max) * 100).toFixed(1)}%</span><span className="muted text-xs">5教科得点率</span></p></div></article>; })}</div>}</section>
      </div>
    </div>
  );
}
