import { notFound } from "next/navigation";
import { updateAcademicTest } from "@/app/actions";
import { ErrorBanner } from "@/components/error-banner";
import { PageHeader } from "@/components/page-header";
import { StudentNav } from "@/components/student-nav";
import { SUBJECTS, SUBJECT_LABELS } from "@/domain/subjects";
import { toDateInput } from "@/lib/format";
import { prisma } from "@/lib/prisma";

export default async function EditTestPage({ params, searchParams }: {
  params: Promise<{ studentId: string; testId: string }>;
  searchParams: Promise<{ error?: string }>;
}) {
  const [{ studentId, testId }, { error }] = await Promise.all([params, searchParams]);
  const [student, test] = await Promise.all([
    prisma.student.findUnique({ where: { id: studentId } }),
    prisma.academicTest.findFirst({ where: { id: testId, studentId }, include: { scores: true } }),
  ]);
  if (!student || !test) notFound();
  return <div>
    <StudentNav studentId={student.id} />
    <PageHeader eyebrow="テスト結果" title="学力テスト結果を修正" description="修正後は、最新の内容で学習傾向をもう一度分析してください。" backHref={`/students/${student.id}/progress`} />
    <ErrorBanner message={error} />
    <p className="notice-banner mb-5">このテストを使った分析結果は自動で書き換えません。保存後、分析画面で再分析してください。</p>
    <form action={updateAcademicTest} className="card card-pad grid gap-5">
      <input type="hidden" name="studentId" value={student.id} />
      <input type="hidden" name="testId" value={test.id} />
      <div className="grid gap-4 sm:grid-cols-2"><div className="field"><label htmlFor="name">テスト名</label><input id="name" name="name" defaultValue={test.name} required maxLength={100} /></div><div className="field"><label htmlFor="takenOn">受験日</label><input id="takenOn" name="takenOn" type="date" max={toDateInput(new Date())} defaultValue={toDateInput(test.takenOn)} required /></div></div>
      <fieldset><legend className="mb-3 text-lg font-black">5教科の得点</legend><p className="help mb-4">平均点と無回答率は分かる場合だけ入力してください。</p><div className="grid gap-3">{SUBJECTS.map((subject) => { const current = test.scores.find((score) => score.subject === subject); return <div key={subject} className="grid gap-3 rounded-2xl bg-[#f3f8fb] p-3 sm:grid-cols-4"><div className="field"><label htmlFor={`${subject}-score`}>{SUBJECT_LABELS[subject]}の得点</label><input id={`${subject}-score`} name={`${subject}-score`} type="number" min="0" defaultValue={current?.score ?? 0} required /></div><div className="field"><label htmlFor={`${subject}-maxScore`}>満点</label><input id={`${subject}-maxScore`} name={`${subject}-maxScore`} type="number" min="1" max="500" defaultValue={current?.maxScore ?? 100} required /></div><div className="field"><label htmlFor={`${subject}-averageScore`}>平均点（任意）</label><input id={`${subject}-averageScore`} name={`${subject}-averageScore`} type="number" min="0" max="500" step="0.1" defaultValue={current?.averageScore ?? ""} /></div><div className="field"><label htmlFor={`${subject}-unansweredRate`}>無回答率%（任意）</label><input id={`${subject}-unansweredRate`} name={`${subject}-unansweredRate`} type="number" min="0" max="100" step="0.1" defaultValue={current?.unansweredRate ?? ""} /></div></div>; })}</div></fieldset>
      <div className="field"><label htmlFor="note">メモ <span className="muted text-sm font-normal">任意</span></label><textarea id="note" name="note" maxLength={500} defaultValue={test.note ?? ""} /></div>
      <div className="flex flex-col gap-3 sm:flex-row sm:justify-end"><a className="btn-secondary" href={`/students/${student.id}/progress`}>キャンセル</a><button type="submit" className="btn-primary">修正内容を保存する</button></div>
    </form>
  </div>;
}
