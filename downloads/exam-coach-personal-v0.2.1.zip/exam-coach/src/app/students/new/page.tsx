import Link from "next/link";
import { createStudent } from "@/app/actions";
import { ErrorBanner } from "@/components/error-banner";
import { PageHeader } from "@/components/page-header";

export default async function NewStudentPage({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  const { error } = await searchParams;
  return (
    <div className="mx-auto max-w-2xl">
      <PageHeader eyebrow="基本情報" title="生徒を登録" description="変化しにくい基本情報と志望校だけを登録します。学習時間や得意・苦手は学習アンケートで回答します。" backHref="/" />
      <ErrorBanner message={error} />
      <form action={createStudent} className="card card-pad grid gap-5">
        <div className="grid gap-4 sm:grid-cols-2"><div className="field"><label htmlFor="displayName">ニックネーム <span className="text-[#b14436]">必須</span></label><input id="displayName" name="displayName" maxLength={50} required autoComplete="off" /></div><div className="field"><label htmlFor="phoneticName">ふりがな</label><input id="phoneticName" name="phoneticName" maxLength={100} autoComplete="off" /></div></div>
        <div className="field"><label htmlFor="grade">学年</label><select id="grade" name="grade" defaultValue="JUNIOR_HIGH_3"><option value="JUNIOR_HIGH_1">中学1年</option><option value="JUNIOR_HIGH_2">中学2年</option><option value="JUNIOR_HIGH_3">中学3年</option></select></div>
        <div className="field"><label htmlFor="schoolName">中学校名 <span className="muted text-sm font-normal">任意</span></label><input id="schoolName" name="schoolName" maxLength={100} autoComplete="organization" /><p className="help">学校名は省略できます。実名よりニックネームをおすすめします。</p></div>
        <div className="grid gap-4 sm:grid-cols-2"><div className="field"><label htmlFor="residenceArea">居住地域</label><input id="residenceArea" name="residenceArea" maxLength={100} placeholder="例：お住まいの都道府県" /></div><div className="field"><label htmlFor="examYear">受験予定年度</label><input id="examYear" name="examYear" type="number" min="2020" max="2100" defaultValue={new Date().getFullYear() + 1} /></div></div>
        <fieldset className="rounded-2xl border border-[#dce7ef] p-4"><legend className="font-black">志望校</legend><div className="mt-2 grid gap-4 sm:grid-cols-2"><div className="field"><label htmlFor="firstChoiceSchool">第一志望校</label><input id="firstChoiceSchool" name="firstChoiceSchool" maxLength={100} /></div><div className="field"><label htmlFor="firstChoiceDepartment">第一志望学科</label><input id="firstChoiceDepartment" name="firstChoiceDepartment" maxLength={100} /></div><div className="field"><label htmlFor="secondChoiceSchool">第二志望校</label><input id="secondChoiceSchool" name="secondChoiceSchool" maxLength={100} /></div><div className="field"><label htmlFor="secondChoiceDepartment">第二志望学科</label><input id="secondChoiceDepartment" name="secondChoiceDepartment" maxLength={100} /></div></div></fieldset>
        <div className="grid gap-4 sm:grid-cols-2"><div className="field"><label htmlFor="clubActivity">部活動</label><input id="clubActivity" name="clubActivity" maxLength={300} /></div><div className="field"><label htmlFor="lessons">習い事</label><input id="lessons" name="lessons" maxLength={300} /></div></div>
        <div className="field"><label htmlFor="accommodations">配慮事項</label><textarea id="accommodations" name="accommodations" maxLength={1000} /></div>
        <div className="field"><label htmlFor="note">備考</label><textarea id="note" name="note" maxLength={1000} /></div>
        <div className="mt-2 flex flex-col-reverse gap-3 sm:flex-row sm:justify-end"><Link href="/" className="btn-secondary">キャンセル</Link><button className="btn-primary" type="submit">登録する</button></div>
      </form>
    </div>
  );
}
