"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { calculatePriorities, ANALYSIS_RULE_VERSION, type SubjectPriority } from "@/domain/analysis";
import { analyzeLearningTendencies, buildLearningSummary } from "@/domain/learning-analysis";
import {
  CONFIDENCE_QUESTIONS,
  CONCENTRATION_QUESTIONS,
  MOTIVATION_QUESTIONS,
  STUDY_METHOD_QUESTIONS,
  surveyScores,
  type LearningSurveyProfile,
  type ScaleAnswers,
} from "@/domain/learning-survey";
import { generateStudyPlan, PLAN_RULE_VERSION } from "@/domain/study-plan";
import { initialReviewDate, nextReviewSchedule } from "@/domain/review-schedule";
import { priorityUnits } from "@/domain/karte-analysis";
import { isSubject, SUBJECTS, type SubjectKey } from "@/domain/subjects";
import { addDays } from "@/lib/format";
import { prisma } from "@/lib/prisma";
import { academicTestSchema, planItemSchema, problemProfileSchema, reviewAttemptSchema, studentRegistrationSchema, studentSchema, studyRecordSchema, surveySchema, targetSchoolSchema } from "@/lib/validation";

function value(formData: FormData, key: string): string {
  const found = formData.get(key);
  return typeof found === "string" ? found : "";
}

function scaleAnswers(formData: FormData, prefix: string, questions: Record<string, string>): ScaleAnswers {
  return Object.fromEntries(Object.keys(questions).map((key) => [key, Number(value(formData, `${prefix}-${key}`))]));
}

function jsonObject(input: unknown): ScaleAnswers {
  if (!input || typeof input !== "object" || Array.isArray(input)) return {};
  return Object.fromEntries(Object.entries(input).filter((entry): entry is [string, number] => typeof entry[1] === "number"));
}

function surveyProfile(survey: {
  currentWeekdayMinutes: number; currentWeekendMinutes: number;
  weekdayAvailableMinutes: number; weekendAvailableMinutes: number; concentrationMinutes: number;
  availableDaysPerWeek: number; availableDays: unknown; busyDays: unknown; preferredTimeOfDay: string; anxiousSubjectsUnits: string | null;
  motivationAnswers: unknown; confidenceAnswers: unknown; studyMethodAnswers: unknown; concentrationAnswers: unknown;
  motivationScore: number; confidenceScore: number; studyHabitScore: number; reviewHabitScore: number;
  concentrationScore: number; environmentScore: number;
  subjects: Array<{ subject: string; weeklyStudyMinutes: number; confidenceLevel: number; selfEvaluationScore: number; studyFrequencyPerWeek: number; preferenceScore: number; difficultyScore: number; easeOfStartingScore: number; knowsWhatToStudyScore: number }>;
}): LearningSurveyProfile {
  return {
    currentWeekdayMinutes: survey.currentWeekdayMinutes,
    currentWeekendMinutes: survey.currentWeekendMinutes,
    weekdayAvailableMinutes: survey.weekdayAvailableMinutes,
    weekendAvailableMinutes: survey.weekendAvailableMinutes,
    concentrationMinutes: survey.concentrationMinutes,
    availableDaysPerWeek: survey.availableDaysPerWeek,
    availableDays: Array.isArray(survey.availableDays) ? survey.availableDays.filter((item): item is LearningSurveyProfile["availableDays"][number] => typeof item === "string" && ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"].includes(item)) : [],
    busyDays: Array.isArray(survey.busyDays) ? survey.busyDays.filter((item): item is LearningSurveyProfile["busyDays"][number] => typeof item === "string" && ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"].includes(item)) : [],
    preferredTimeOfDay: survey.preferredTimeOfDay,
    anxiousSubjectsUnits: survey.anxiousSubjectsUnits,
    motivationAnswers: jsonObject(survey.motivationAnswers),
    confidenceAnswers: jsonObject(survey.confidenceAnswers),
    studyMethodAnswers: jsonObject(survey.studyMethodAnswers),
    concentrationAnswers: jsonObject(survey.concentrationAnswers),
    motivationScore: survey.motivationScore,
    confidenceScore: survey.confidenceScore,
    studyHabitScore: survey.studyHabitScore,
    reviewHabitScore: survey.reviewHabitScore,
    concentrationScore: survey.concentrationScore,
    environmentScore: survey.environmentScore,
    subjects: survey.subjects.filter((item) => isSubject(item.subject)).map((item) => ({ ...item, subject: item.subject as SubjectKey })),
  };
}

function safeMessage(error: unknown): string {
  if (error instanceof Error && error.message.includes("Unique constraint")) {
    return "同じ順位の志望校がすでに登録されています。";
  }
  return "入力内容を確認して、もう一度お試しください。";
}

function fail(path: string, message: string): never {
  redirect(`${path}?error=${encodeURIComponent(message)}`);
}

export async function createStudent(formData: FormData): Promise<void> {
  const parsed = studentRegistrationSchema.safeParse({
    displayName: value(formData, "displayName"),
    phoneticName: value(formData, "phoneticName"),
    grade: value(formData, "grade"),
    schoolName: value(formData, "schoolName"),
    residenceArea: value(formData, "residenceArea"),
    examYear: value(formData, "examYear"),
    firstChoiceSchool: value(formData, "firstChoiceSchool"),
    firstChoiceDepartment: value(formData, "firstChoiceDepartment"),
    secondChoiceSchool: value(formData, "secondChoiceSchool"),
    secondChoiceDepartment: value(formData, "secondChoiceDepartment"),
    clubActivity: value(formData, "clubActivity"),
    lessons: value(formData, "lessons"),
    accommodations: value(formData, "accommodations"),
    note: value(formData, "note"),
  });
  if (!parsed.success) fail("/students/new", parsed.error.issues[0]?.message ?? "入力内容を確認してください。");
  const { firstChoiceSchool, firstChoiceDepartment, secondChoiceSchool, secondChoiceDepartment, ...studentData } = parsed.data;
  const targetSchools = [
    firstChoiceSchool ? { schoolName: firstChoiceSchool, departmentName: firstChoiceDepartment, preferenceRank: 1 } : null,
    secondChoiceSchool ? { schoolName: secondChoiceSchool, departmentName: secondChoiceDepartment, preferenceRank: 2 } : null,
  ].filter((school): school is NonNullable<typeof school> => school !== null);
  const student = await prisma.student.create({ data: { ...studentData, targetSchools: { create: targetSchools } } });
  revalidatePath("/");
  redirect(`/students/${student.id}`);
}

export async function updateStudent(formData: FormData): Promise<void> {
  const studentId = value(formData, "studentId");
  const parsed = studentSchema.safeParse({
    displayName: value(formData, "displayName"),
    phoneticName: value(formData, "phoneticName"),
    grade: value(formData, "grade"),
    schoolName: value(formData, "schoolName"),
    residenceArea: value(formData, "residenceArea"),
    examYear: value(formData, "examYear"),
    clubActivity: value(formData, "clubActivity"),
    lessons: value(formData, "lessons"),
    accommodations: value(formData, "accommodations"),
    note: value(formData, "note"),
  });
  if (!parsed.success) fail(`/students/${studentId}/edit`, parsed.error.issues[0]?.message ?? "入力内容を確認してください。");
  await prisma.student.update({ where: { id: studentId }, data: parsed.data });
  revalidatePath("/");
  redirect(`/students/${studentId}`);
}

export async function deleteStudent(formData: FormData): Promise<void> {
  const studentId = value(formData, "studentId");
  await prisma.student.delete({ where: { id: studentId } });
  revalidatePath("/");
  redirect("/");
}

export async function saveTargetSchool(formData: FormData): Promise<void> {
  const studentId = value(formData, "studentId");
  const targetSchoolId = value(formData, "targetSchoolId");
  const path = `/students/${studentId}/target-schools`;
  const setOn = value(formData, "setOn");
  const hasSubjectGoals = SUBJECTS.every((subject) => formData.has(`${subject}-targetScore`));
  const parsed = targetSchoolSchema.safeParse({
    schoolName: value(formData, "schoolName"),
    departmentName: value(formData, "departmentName"),
    preferenceRank: value(formData, "preferenceRank"),
    targetTotalScore: value(formData, "targetTotalScore"),
    note: value(formData, "note"),
    ...(setOn ? { setOn } : {}),
    instructorComment: value(formData, "instructorComment"),
    ...(hasSubjectGoals ? { subjectGoals: SUBJECTS.map((subject) => ({ subject, targetScore: value(formData, `${subject}-targetScore`) })) } : {}),
  });
  if (!parsed.success) fail(path, parsed.error.issues[0]?.message ?? "入力内容を確認してください。");
  try {
    const { subjectGoals = [], ...schoolData } = parsed.data;
    await prisma.$transaction(async (tx) => {
      if (targetSchoolId) {
        const existing = await tx.targetSchool.findFirst({ where: { id: targetSchoolId, studentId }, include: { subjectGoals: true } });
        if (!existing) throw new Error("Target school not found");
        await tx.targetSchoolHistory.create({ data: { targetSchoolId, snapshot: { schoolName: existing.schoolName, departmentName: existing.departmentName, preferenceRank: existing.preferenceRank, targetTotalScore: existing.targetTotalScore, setOn: existing.setOn.toISOString(), instructorComment: existing.instructorComment, note: existing.note, subjectGoals: existing.subjectGoals.map((goal) => ({ subject: goal.subject, targetScore: goal.targetScore })) } } });
        await tx.targetSchool.update({ where: { id: targetSchoolId }, data: { ...schoolData, ...(hasSubjectGoals ? { subjectGoals: { deleteMany: {}, create: subjectGoals } } : {}) } });
      } else {
        const created = await tx.targetSchool.create({ data: { studentId, ...schoolData, subjectGoals: { create: subjectGoals } } });
        await tx.targetSchoolHistory.create({ data: { targetSchoolId: created.id, snapshot: { ...schoolData, subjectGoals } } });
      }
    });
  } catch (error) {
    fail(path, safeMessage(error));
  }
  revalidatePath(path);
  redirect(path);
}

export async function deleteTargetSchool(formData: FormData): Promise<void> {
  const studentId = value(formData, "studentId");
  const targetSchoolId = value(formData, "targetSchoolId");
  await prisma.targetSchool.delete({ where: { id: targetSchoolId, studentId } });
  const path = `/students/${studentId}/target-schools`;
  revalidatePath(path);
  redirect(path);
}

export async function createAcademicTest(formData: FormData): Promise<void> {
  const studentId = value(formData, "studentId");
  const path = `/students/${studentId}/tests/new`;
  const parsed = academicTestSchema.safeParse({
    name: value(formData, "name"),
    takenOn: value(formData, "takenOn"),
    note: value(formData, "note"),
    scores: SUBJECTS.map((subject) => ({
      subject,
      score: value(formData, `${subject}-score`),
      maxScore: value(formData, `${subject}-maxScore`),
      averageScore: value(formData, `${subject}-averageScore`),
      unansweredRate: value(formData, `${subject}-unansweredRate`),
    })),
  });
  if (!parsed.success) fail(path, parsed.error.issues[0]?.message ?? "入力内容を確認してください。");
  await prisma.academicTest.create({
    data: {
      studentId,
      name: parsed.data.name,
      takenOn: parsed.data.takenOn,
      note: parsed.data.note,
      scores: { create: parsed.data.scores },
    },
  });
  revalidatePath(`/students/${studentId}`);
  redirect(`/students/${studentId}/progress`);
}

export async function updateAcademicTest(formData: FormData): Promise<void> {
  const studentId = value(formData, "studentId");
  const testId = value(formData, "testId");
  const path = `/students/${studentId}/tests/${testId}/edit`;
  const parsed = academicTestSchema.safeParse({
    name: value(formData, "name"),
    takenOn: value(formData, "takenOn"),
    note: value(formData, "note"),
    scores: SUBJECTS.map((subject) => ({
      subject,
      score: value(formData, `${subject}-score`),
      maxScore: value(formData, `${subject}-maxScore`),
      averageScore: value(formData, `${subject}-averageScore`),
      unansweredRate: value(formData, `${subject}-unansweredRate`),
    })),
  });
  if (!parsed.success) fail(path, parsed.error.issues[0]?.message ?? "入力内容を確認してください。");
  const existing = await prisma.academicTest.findFirst({ where: { id: testId, studentId } });
  if (!existing) fail(`/students/${studentId}/progress`, "編集するテスト結果が見つかりません。");
  await prisma.$transaction(async (tx) => {
    await tx.academicTest.update({
      where: { id: testId },
      data: { name: parsed.data.name, takenOn: parsed.data.takenOn, note: parsed.data.note },
    });
    await tx.academicTestScore.deleteMany({ where: { academicTestId: testId } });
    await tx.academicTestScore.createMany({
      data: parsed.data.scores.map((score) => ({ academicTestId: testId, ...score })),
    });
  });
  revalidatePath(`/students/${studentId}`);
  revalidatePath(`/students/${studentId}/progress`);
  revalidatePath(`/students/${studentId}/analysis`);
  redirect(`/students/${studentId}/progress?updated=1`);
}

export async function createStudySurvey(formData: FormData): Promise<void> {
  const studentId = value(formData, "studentId");
  const path = `/students/${studentId}/surveys/new`;
  const motivationAnswers = scaleAnswers(formData, "motivation", MOTIVATION_QUESTIONS);
  const confidenceAnswers = scaleAnswers(formData, "confidence", CONFIDENCE_QUESTIONS);
  const studyMethodAnswers = scaleAnswers(formData, "method", STUDY_METHOD_QUESTIONS);
  const concentrationAnswers = scaleAnswers(formData, "concentration", CONCENTRATION_QUESTIONS);
  const parsed = surveySchema.safeParse({
    answeredOn: value(formData, "answeredOn"),
    currentWeekdayMinutes: value(formData, "currentWeekdayMinutes"),
    currentWeekendMinutes: value(formData, "currentWeekendMinutes"),
    weekdayAvailableMinutes: value(formData, "weekdayAvailableMinutes"),
    weekendAvailableMinutes: value(formData, "weekendAvailableMinutes"),
    concentrationMinutes: value(formData, "concentrationMinutes"),
    availableDaysPerWeek: formData.getAll("availableDays").length,
    availableDays: formData.getAll("availableDays").filter((item): item is string => typeof item === "string"),
    busyDays: formData.getAll("busyDays").filter((item): item is string => typeof item === "string"),
    preferredTimeOfDay: value(formData, "preferredTimeOfDay"),
    motivationAnswers,
    confidenceAnswers,
    studyMethodAnswers,
    concentrationAnswers,
    concern: value(formData, "concern"),
    recentAchievement: value(formData, "recentAchievement"),
    anxiousSubjectsUnits: value(formData, "anxiousSubjectsUnits"),
    preferredStudyMethod: value(formData, "preferredStudyMethod"),
    familyConsideration: value(formData, "familyConsideration"),
    subjects: SUBJECTS.map((subject) => ({
      subject,
      weeklyStudyMinutes: value(formData, `${subject}-weeklyStudyMinutes`),
      confidenceLevel: value(formData, `${subject}-confidenceLevel`),
      selfEvaluationScore: value(formData, `${subject}-selfEvaluationScore`),
      studyFrequencyPerWeek: value(formData, `${subject}-studyFrequencyPerWeek`),
      preferenceScore: value(formData, `${subject}-preferenceScore`),
      difficultyScore: String(6 - Number(value(formData, `${subject}-selfEvaluationScore`))),
      easeOfStartingScore: value(formData, `${subject}-easeOfStartingScore`),
      knowsWhatToStudyScore: value(formData, `${subject}-knowsWhatToStudyScore`),
    })),
  });
  if (!parsed.success) fail(path, parsed.error.issues[0]?.message ?? "入力内容を確認してください。");
  const derived = surveyScores({ motivationAnswers, confidenceAnswers, studyMethodAnswers, concentrationAnswers });
  await prisma.studySurvey.create({
    data: {
      studentId,
      answeredOn: parsed.data.answeredOn,
      currentWeekdayMinutes: parsed.data.currentWeekdayMinutes,
      currentWeekendMinutes: parsed.data.currentWeekendMinutes,
      weekdayAvailableMinutes: parsed.data.weekdayAvailableMinutes,
      weekendAvailableMinutes: parsed.data.weekendAvailableMinutes,
      concentrationMinutes: parsed.data.concentrationMinutes,
      availableDaysPerWeek: parsed.data.availableDaysPerWeek,
      availableDays: parsed.data.availableDays,
      busyDays: parsed.data.busyDays,
      preferredTimeOfDay: parsed.data.preferredTimeOfDay,
      ...derived,
      motivationAnswers: parsed.data.motivationAnswers,
      confidenceAnswers: parsed.data.confidenceAnswers,
      studyMethodAnswers: parsed.data.studyMethodAnswers,
      concentrationAnswers: parsed.data.concentrationAnswers,
      concern: parsed.data.concern,
      recentAchievement: parsed.data.recentAchievement,
      anxiousSubjectsUnits: parsed.data.anxiousSubjectsUnits,
      preferredStudyMethod: parsed.data.preferredStudyMethod,
      familyConsideration: parsed.data.familyConsideration,
      subjects: { create: parsed.data.subjects },
    },
  });
  revalidatePath(`/students/${studentId}`);
  redirect(`/students/${studentId}/analysis`);
}

export async function runAnalysis(formData: FormData): Promise<void> {
  const studentId = value(formData, "studentId");
  const path = `/students/${studentId}/analysis`;
  const [tests, survey, problems] = await Promise.all([
    prisma.academicTest.findMany({
      where: { studentId },
      include: { scores: true },
      orderBy: [{ takenOn: "desc" }, { createdAt: "desc" }],
      take: 3,
    }),
    prisma.studySurvey.findFirst({
      where: { studentId },
      include: { subjects: true },
      orderBy: [{ answeredOn: "desc" }, { createdAt: "desc" }],
    }),
    prisma.problemProfile.findMany({ where: { studentId }, include: { reviewProfile: true }, orderBy: { attemptedOn: "desc" }, take: 200 }),
  ]);
  if (!tests[0] && !survey) fail(path, "テスト結果またはアンケートを先に登録してください。");

  const toScores = (test: (typeof tests)[number] | undefined) =>
    test?.scores.filter((item): item is typeof item & { subject: SubjectKey } => isSubject(item.subject));
  const priorities = calculatePriorities({
    currentScores: toScores(tests[0]),
    previousScores: toScores(tests[1]),
    recentScores: tests.map((test) => toScores(test) ?? []),
    surveySubjects: survey?.subjects.filter(
      (item): item is typeof item & { subject: SubjectKey } => isSubject(item.subject),
    ),
  });
  const profile = survey ? surveyProfile(survey) : null;
  const analysisInput = {
    currentScores: toScores(tests[0]),
    previousScores: toScores(tests[1]),
    recentScores: tests.map((test) => toScores(test) ?? []),
    surveySubjects: profile?.subjects,
  };
  const tendencies = analyzeLearningTendencies(profile, analysisInput);
  const summary = buildLearningSummary(profile, priorities, tendencies);
  const unitMap = priorityUnits(problems.filter((item): item is typeof item & { subject: SubjectKey } => isSubject(item.subject)).map((item) => ({ ...item, nextReviewOn: item.reviewProfile?.nextReviewOn })));

  await prisma.analysisResult.create({
    data: {
      studentId,
      academicTestId: tests[0]?.id,
      previousAcademicTestId: tests[1]?.id,
      studySurveyId: survey?.id,
      status: tests[0] && survey ? "COMPLETE" : "PROVISIONAL",
      ruleVersion: ANALYSIS_RULE_VERSION,
      inputSnapshot: {
        schemaVersion: 3,
        academicTestIds: tests.map((test) => test.id),
        academicTests: tests.map((test) => ({ id: test.id, updatedAt: test.updatedAt.toISOString() })),
        studySurveyId: survey?.id ?? null,
        testUpdatedAt: tests[0]?.updatedAt.toISOString() ?? null,
        surveyUpdatedAt: survey?.updatedAt.toISOString() ?? null,
        problemProfileIds: problems.map((problem) => problem.id),
      },
      summarySnapshot: { ...(summary ?? {}), priorityUnits: Object.fromEntries(unitMap), reviewCandidateIds: problems.filter((problem) => problem.isReviewTarget).map((problem) => problem.id) },
      subjectAnalyses: {
        create: priorities.map((priority) => ({
          subject: priority.subject,
          priorityScore: priority.priorityScore,
          priorityRank: priority.priorityRank,
          latestScoreRate: priority.latestScoreRate,
          scoreRateDelta: priority.scoreRateDelta,
          recentScoreRates: priority.recentScoreRates,
          selfEvaluationScore: priority.selfEvaluationScore,
          confidenceLevel: priority.confidenceLevel,
          recognitionLabel: priority.recognitionLabel,
          analysisComment: priority.analysisComment,
          priorityUnit: unitMap.get(priority.subject)?.unit ?? (priority.priorityRank <= 2 ? survey?.anxiousSubjectsUnits : null),
          reasonsSnapshot: priority.reasons,
        })),
      },
      learningTendencies: {
        create: tendencies.map((tendency) => ({
          tendencyType: tendency.tendencyType,
          score: tendency.score,
          evidence: tendency.evidence,
          recommendation: { statement: tendency.statement, items: tendency.recommendations },
        })),
      },
    },
  });
  revalidatePath(path);
  redirect(path);
}

export async function createWeeklyPlan(formData: FormData): Promise<void> {
  const studentId = value(formData, "studentId");
  const path = `/students/${studentId}/plans`;
  const requestedAnalysisId = value(formData, "analysisId");
  const requestedSurveyId = value(formData, "surveyId");
  const weekStartOn = new Date(value(formData, "weekStartOn"));
  if (Number.isNaN(weekStartOn.getTime()) || weekStartOn.getUTCDay() !== 1) {
    fail(path, "対象週の月曜日を選んでください。");
  }
  const analysis = await prisma.analysisResult.findFirst({
    where: { studentId, ...(requestedAnalysisId ? { id: requestedAnalysisId } : {}) },
    include: { subjectAnalyses: { orderBy: { priorityRank: "asc" } }, learningTendencies: { orderBy: { score: "desc" } }, studySurvey: { include: { subjects: true } } },
    orderBy: { createdAt: "desc" },
  });
  if (!analysis) fail(path, "先に学習傾向を分析してください。");
  if (!analysis.studySurvey) fail(path, "学習可能時間を使うため、アンケートを登録して再分析してください。");
  if (requestedSurveyId && analysis.studySurvey.id !== requestedSurveyId) fail(path, "指定されたアンケートと分析結果の組み合わせを確認できませんでした。");
  if (!analysis.academicTestId && value(formData, "allowProvisional") !== "1") fail(path, "テスト未登録の暫定プランであることを確認してください。");

  const priorities: SubjectPriority[] = analysis.subjectAnalyses.map((item) => ({
    subject: item.subject as SubjectKey,
    priorityScore: item.priorityScore,
    priorityRank: item.priorityRank,
    latestScoreRate: item.latestScoreRate,
    scoreRateDelta: item.scoreRateDelta,
    recentScoreRates: Array.isArray(item.recentScoreRates) ? item.recentScoreRates.filter((rate): rate is number => typeof rate === "number") : [],
    selfEvaluationScore: item.selfEvaluationScore,
    confidenceLevel: item.confidenceLevel,
    recognitionLabel: item.recognitionLabel,
    analysisComment: item.analysisComment,
    reasons: Array.isArray(item.reasonsSnapshot) ? item.reasonsSnapshot as SubjectPriority["reasons"] : [],
  }));
  const tendencies = analysis.learningTendencies.map((item) => ({
    tendencyType: item.tendencyType as import("@/domain/learning-analysis").LearningTendencyType,
    score: item.score,
    statement: typeof item.recommendation === "object" && item.recommendation && !Array.isArray(item.recommendation) && "statement" in item.recommendation ? String(item.recommendation.statement) : "",
    evidence: Array.isArray(item.evidence) ? item.evidence.map(String) : [],
    recommendations: typeof item.recommendation === "object" && item.recommendation && !Array.isArray(item.recommendation) && "items" in item.recommendation && Array.isArray(item.recommendation.items) ? item.recommendation.items.map(String) : [],
  }));
  const previousPlan = await prisma.weeklyStudyPlan.findFirst({
    where: { studentId, weekStartOn: { lt: weekStartOn }, status: { in: ["CONFIRMED", "ACTIVE"] } },
    include: { items: { include: { studyRecord: true } } },
    orderBy: { weekStartOn: "desc" },
  });
  const records = previousPlan?.items.flatMap((item) => item.studyRecord ? [{ item, record: item.studyRecord }] : []) ?? [];
  const attempted = records.reduce((sum, item) => sum + item.record.attemptedCount, 0);
  const previousWeek = previousPlan ? {
    completionRate: previousPlan.items.length ? records.filter((item) => item.record.completed).length / previousPlan.items.length : 0,
    correctRate: attempted ? records.reduce((sum, item) => sum + item.record.correctCount, 0) / attempted : null,
    averageTimeRatio: records.length ? records.reduce((sum, item) => sum + item.record.actualMinutes / Math.max(1, item.item.durationMinutes), 0) / records.length : null,
    concentrationAverage: records.filter((item) => item.record.concentrationRating).length ? records.reduce((sum, item) => sum + (item.record.concentrationRating ?? 0), 0) / records.filter((item) => item.record.concentrationRating).length : null,
    recurringMistakes: records.filter((item) => Array.isArray(item.record.mistakeTypes) && item.record.mistakeTypes.length > 0).length >= 2,
  } : null;
  const dueReviews = await prisma.reviewProfile.findMany({
    where: { studentId, nextReviewOn: { lte: addDays(weekStartOn, 6) }, status: { not: "STABLE" } },
    include: { problemProfile: true },
    orderBy: { nextReviewOn: "asc" },
    take: 20,
  });
  const draft = generateStudyPlan({
    priorities,
    survey: surveyProfile(analysis.studySurvey),
    tendencies,
    previousWeek,
    priorityUnits: Object.fromEntries(analysis.subjectAnalyses.filter((item) => item.priorityUnit).map((item) => [item.subject, item.priorityUnit as string])),
    dueReviews: dueReviews.filter((item): item is typeof item & { problemProfile: typeof item.problemProfile & { subject: SubjectKey } } => isSubject(item.problemProfile.subject)).map((item) => ({ subject: item.problemProfile.subject, unit: item.problemProfile.unit })),
  });
  const previous = await prisma.weeklyStudyPlan.findFirst({
    where: { studentId, weekStartOn },
    orderBy: { version: "desc" },
  });
  const version = (previous?.version ?? 0) + 1;

  const plan = await prisma.$transaction(async (tx) => {
    await tx.weeklyStudyPlan.updateMany({
      where: { studentId, weekStartOn, status: "DRAFT" },
      data: { status: "SUPERSEDED" },
    });
    return tx.weeklyStudyPlan.create({
      data: {
        studentId,
        analysisResultId: analysis.id,
        weekStartOn,
        version,
        status: "DRAFT",
        availableMinutesSnapshot: draft.availableMinutes,
        plannedMinutes: draft.plannedMinutes,
        ruleVersion: PLAN_RULE_VERSION,
        weeklyGoal: draft.weeklyGoal,
        recommendedDays: draft.recommendedDays,
        recommendedSessionMinutes: draft.recommendedSessionMinutes,
        generatedBy: "RULE",
        items: {
          create: draft.items.map((item) => ({
            plannedOn: addDays(weekStartOn, item.dayOffset),
            sequence: item.sequence,
            subject: item.subject,
            durationMinutes: item.durationMinutes,
            guidance: item.guidance,
            unit: item.unit,
            purpose: item.purpose,
            activity: item.activity,
            problemCount: item.problemCount,
            difficulty: item.difficulty,
            studyMethod: item.studyMethod,
            completionCriteria: item.completionCriteria,
            reason: item.reason,
          })),
        },
      },
    });
  });
  revalidatePath(path);
  redirect(`${path}#plan-${plan.id}`);
}

export async function saveProblemProfile(formData: FormData): Promise<void> {
  const studentId = value(formData, "studentId");
  const problemId = value(formData, "problemId");
  const path = `/students/${studentId}/problems`;
  const parsed = problemProfileSchema.safeParse({
    testName: value(formData, "testName"), attemptedOn: value(formData, "attemptedOn"), subject: value(formData, "subject"),
    majorNumber: value(formData, "majorNumber"), minorNumber: value(formData, "minorNumber"), area: value(formData, "area"), unit: value(formData, "unit"),
    questionFormat: value(formData, "questionFormat"), difficulty: value(formData, "difficulty"), points: value(formData, "points"),
    studentAnswer: value(formData, "studentAnswer"), correctAnswer: value(formData, "correctAnswer"), isCorrect: value(formData, "isCorrect") === "1",
    answerSeconds: value(formData, "answerSeconds"), isUnanswered: value(formData, "isUnanswered") === "on",
    mistakeTypes: formData.getAll("mistakeTypes").filter((item): item is string => typeof item === "string"),
    instructorComment: value(formData, "instructorComment"), isReviewTarget: value(formData, "isReviewTarget") === "on",
  });
  if (!parsed.success) fail(path, parsed.error.issues[0]?.message ?? "問題の入力内容を確認してください。");
  await prisma.$transaction(async (tx) => {
    const problem = problemId
      ? await tx.problemProfile.update({ where: { id: problemId, studentId }, data: parsed.data })
      : await tx.problemProfile.create({ data: { studentId, ...parsed.data } });
    if (parsed.data.isReviewTarget) {
      await tx.reviewProfile.upsert({
        where: { problemProfileId: problem.id },
        create: { studentId, problemProfileId: problem.id, status: "SCHEDULED", nextReviewOn: initialReviewDate(problem.attemptedOn) },
        update: {},
      });
    } else {
      await tx.reviewProfile.deleteMany({ where: { problemProfileId: problem.id, studentId } });
    }
  });
  revalidatePath(`/students/${studentId}`);
  revalidatePath(path);
  revalidatePath(`/students/${studentId}/reviews`);
  redirect(`${path}?saved=1`);
}

export async function deleteProblemProfile(formData: FormData): Promise<void> {
  const studentId = value(formData, "studentId");
  const problemId = value(formData, "problemId");
  await prisma.problemProfile.delete({ where: { id: problemId, studentId } });
  revalidatePath(`/students/${studentId}/problems`);
  revalidatePath(`/students/${studentId}/reviews`);
  redirect(`/students/${studentId}/problems?deleted=1`);
}

export async function saveReviewAttempt(formData: FormData): Promise<void> {
  const studentId = value(formData, "studentId");
  const reviewId = value(formData, "reviewId");
  const path = `/students/${studentId}/reviews`;
  const parsed = reviewAttemptSchema.safeParse({ reviewedOn: value(formData, "reviewedOn"), isCorrect: value(formData, "isCorrect") === "1", note: value(formData, "note") });
  if (!parsed.success) fail(path, parsed.error.issues[0]?.message ?? "復習結果を確認してください。");
  const review = await prisma.reviewProfile.findFirst({ where: { id: reviewId, studentId } });
  if (!review) fail(path, "復習対象が見つかりません。");
  const next = nextReviewSchedule({ reviewedOn: parsed.data.reviewedOn, isCorrect: parsed.data.isCorrect, consecutiveCorrect: review.consecutiveCorrect });
  await prisma.$transaction([
    prisma.reviewAttempt.create({ data: { reviewProfileId: review.id, ...parsed.data } }),
    prisma.reviewProfile.update({ where: { id: review.id }, data: next }),
  ]);
  revalidatePath(path);
  revalidatePath(`/students/${studentId}`);
  redirect(`${path}?saved=1`);
}

export async function updateStudyPlanItem(formData: FormData): Promise<void> {
  const studentId = value(formData, "studentId");
  const planId = value(formData, "planId");
  const itemId = value(formData, "itemId");
  const path = `/students/${studentId}/plans#plan-${planId}`;
  const parsed = planItemSchema.safeParse({
    plannedOn: value(formData, "plannedOn"), subject: value(formData, "subject"),
    durationMinutes: value(formData, "durationMinutes"), unit: value(formData, "unit"),
    purpose: value(formData, "purpose"), activity: value(formData, "activity"),
    problemCount: value(formData, "problemCount"), difficulty: value(formData, "difficulty"),
    studyMethod: value(formData, "studyMethod"), completionCriteria: value(formData, "completionCriteria"),
  });
  if (!parsed.success) fail(path, parsed.error.issues[0]?.message ?? "計画内容を確認してください。");
  const plan = await prisma.weeklyStudyPlan.findFirst({ where: { id: planId, studentId, status: "DRAFT" } });
  if (!plan) fail(path, "編集できる下書きが見つかりません。");
  await prisma.studyPlanItem.update({ where: { id: itemId, weeklyStudyPlanId: plan.id }, data: parsed.data });
  const aggregate = await prisma.studyPlanItem.aggregate({ where: { weeklyStudyPlanId: plan.id }, _sum: { durationMinutes: true } });
  await prisma.weeklyStudyPlan.update({ where: { id: plan.id }, data: { plannedMinutes: aggregate._sum.durationMinutes ?? 0 } });
  revalidatePath(`/students/${studentId}/plans`);
  redirect(path);
}

export async function confirmWeeklyPlan(formData: FormData): Promise<void> {
  const studentId = value(formData, "studentId");
  const planId = value(formData, "planId");
  const path = `/students/${studentId}/plans#plan-${planId}`;
  const plan = await prisma.weeklyStudyPlan.findFirst({ where: { id: planId, studentId, status: "DRAFT" } });
  if (!plan) fail(path, "確定できる下書きが見つかりません。");
  await prisma.$transaction([
    prisma.weeklyStudyPlan.updateMany({ where: { studentId, weekStartOn: plan.weekStartOn, status: { in: ["CONFIRMED", "ACTIVE"] } }, data: { status: "SUPERSEDED" } }),
    prisma.weeklyStudyPlan.update({ where: { id: plan.id }, data: { status: "CONFIRMED", confirmedAt: new Date() } }),
  ]);
  revalidatePath(`/students/${studentId}/plans`);
  redirect(path);
}

export async function saveStudyRecord(formData: FormData): Promise<void> {
  const studentId = value(formData, "studentId");
  const planId = value(formData, "planId");
  const itemId = value(formData, "itemId");
  const path = `/students/${studentId}/plans#plan-${planId}`;
  const parsed = studyRecordSchema.safeParse({
    completed: value(formData, "completed") === "on", actualMinutes: value(formData, "actualMinutes"),
    attemptedCount: value(formData, "attemptedCount"), correctCount: value(formData, "correctCount"),
    difficultyRating: value(formData, "difficultyRating"), concentrationRating: value(formData, "concentrationRating"),
    retryPreference: value(formData, "retryPreference") === "on",
    mistakeTypes: formData.getAll("mistakeTypes").filter((item): item is string => typeof item === "string"),
    studentComment: value(formData, "studentComment"),
  });
  if (!parsed.success) fail(path, parsed.error.issues[0]?.message ?? "振り返りを確認してください。");
  const item = await prisma.studyPlanItem.findFirst({ where: { id: itemId, weeklyStudyPlan: { id: planId, studentId } } });
  if (!item) fail(path, "学習項目が見つかりません。");
  await prisma.studyRecord.upsert({ where: { studyPlanItemId: item.id }, create: { studyPlanItemId: item.id, ...parsed.data }, update: parsed.data });
  revalidatePath(`/students/${studentId}/plans`);
  redirect(path);
}
