import type { MetadataRoute } from "next";
export default function manifest():MetadataRoute.Manifest{return{name:"高校入試コーチ",short_name:"入試コーチ",description:"全国の中学生向けローカル学習支援アプリ",start_url:"/",display:"standalone",background_color:"#f3f8fb",theme_color:"#123a5a",lang:"ja",icons:[{src:"/icon.svg",sizes:"any",type:"image/svg+xml",purpose:"any"}]}}
