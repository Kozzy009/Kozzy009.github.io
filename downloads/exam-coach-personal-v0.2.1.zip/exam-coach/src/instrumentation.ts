import type { Instrumentation } from "next";

export const onRequestError: Instrumentation.onRequestError = async (error, _request, context) => {
  if (process.env.NEXT_RUNTIME !== "nodejs") return;
  const { writeSanitizedAppError } = await import("@/lib/app-error-log");
  await writeSanitizedAppError(error, context.routeType, context.routePath);
};
