import Link from "next/link";

export function PageHeader({
  eyebrow,
  title,
  description,
  backHref,
}: {
  eyebrow: string;
  title: string;
  description?: string;
  backHref?: string;
}) {
  return (
    <div className="mb-7">
      {backHref ? <Link href={backHref} className="mb-4 inline-flex font-bold text-[#1677a6]">← 戻る</Link> : null}
      <p className="eyebrow">{eyebrow}</p>
      <h1 className="mt-2 text-3xl font-black tracking-[-.04em] sm:text-4xl">{title}</h1>
      {description ? <p className="muted mt-3 max-w-3xl leading-7">{description}</p> : null}
    </div>
  );
}
