import { SUBJECT_LABELS, type SubjectKey } from "@/domain/subjects";

type SourceProblem = {
  id: string;
  subject: SubjectKey;
  unit: string;
  majorNumber: string;
  minorNumber: string | null;
  isCorrect: boolean;
  isReviewTarget: boolean;
};

export function ProblemGenerationSourcePicker({ studentId, problems }: { studentId: string; problems: SourceProblem[] }) {
  const units = Array.from(new Map(problems.map((problem) => [`${problem.subject}:${problem.unit}`, problem])).values());
  const action = `/students/${studentId}/generations/new`;

  return <section className="card card-pad mb-7">
    <h2 className="section-title">類似問題の元問題を選ぶ</h2>
    <p className="muted mt-2 text-sm">1問または複数問題を選択できます。AI取込由来でconfidenceが低い問題は、次の画面で自動除外します。</p>
    <form action={action} className="mt-4 grid gap-3">
      <div className="grid gap-2 sm:grid-cols-2">{problems.map((problem) => <label className="rounded-xl border border-[#dce7ef] p-3" key={problem.id}>
        <input className="mr-2" name="problemId" type="checkbox" value={problem.id}/>
        <strong>{SUBJECT_LABELS[problem.subject]}・{problem.unit}</strong> 大問{problem.majorNumber}{problem.minorNumber ? `-${problem.minorNumber}` : ""}{!problem.isCorrect ? "（誤答）" : ""}{problem.isReviewTarget ? "（復習予定）" : ""}
      </label>)}</div>
      <button className="btn-primary justify-self-start" type="submit">選択した問題から類似問題を作る</button>
    </form>
    <div className="mt-4 flex flex-wrap gap-3">
      <a className="btn-secondary" href={`${action}?scope=incorrect`}>誤答問題だけ選択</a>
      <a className="btn-secondary" href={`${action}?scope=review`}>復習予定問題だけ選択</a>
    </div>
    <form action={action} className="mt-4 flex flex-wrap items-end gap-3">
      <input name="scope" type="hidden" value="unit"/>
      <label className="field min-w-64"><span>単元で選択</span><select name="unitKey" required><option value="">選択してください</option>{units.map((problem) => <option key={`${problem.subject}:${problem.unit}`} value={`${problem.subject}:${problem.unit}`}>{SUBJECT_LABELS[problem.subject]}・{problem.unit}</option>)}</select></label>
      <button className="btn-secondary" type="submit">この単元を選択</button>
    </form>
  </section>;
}
