"use client";

import { useState } from "react";
import { CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { SUBJECTS, SUBJECT_LABELS, type SubjectKey } from "@/domain/subjects";

export type ProgressPoint = { label: string; [key: string]: string | number };

export function ProgressChart({ data, initialSubject }: { data: ProgressPoint[]; initialSubject: SubjectKey }) {
  const [subject, setSubject] = useState<SubjectKey>(initialSubject);
  return (
    <div>
      <div className="mb-5 flex flex-wrap gap-2" role="group" aria-label="表示する教科">
        {SUBJECTS.map((key) => <button key={key} type="button" onClick={() => setSubject(key)} aria-pressed={subject === key} className={`min-h-11 rounded-full border px-4 font-bold ${subject === key ? "border-[#123a5a] bg-[#123a5a] text-white" : "border-[#b8ccd9] bg-white text-[#35546c]"}`}>{SUBJECT_LABELS[key]}</button>)}
      </div>
      <div className="h-80 w-full" aria-label={`${SUBJECT_LABELS[subject]}の得点率グラフ`} role="img">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 10, right: 14, left: -16, bottom: 5 }}>
            <CartesianGrid strokeDasharray="4 4" stroke="#dce7ef" />
            <XAxis dataKey="label" tick={{ fill: "#60758a", fontSize: 12 }} />
            <YAxis domain={[0, 100]} unit="%" tick={{ fill: "#60758a", fontSize: 12 }} />
            <Tooltip formatter={(value) => [`${Number(value).toFixed(1)}%`, SUBJECT_LABELS[subject]]} />
            <Line type="monotone" dataKey={subject} stroke="#1677a6" strokeWidth={4} dot={{ r: 5, fill: "#f28b66", strokeWidth: 2 }} activeDot={{ r: 7 }} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
