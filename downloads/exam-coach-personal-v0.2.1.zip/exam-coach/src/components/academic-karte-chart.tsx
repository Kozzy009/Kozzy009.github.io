"use client";

import { useState } from "react";
import { CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { SUBJECTS, SUBJECT_LABELS, type SubjectKey } from "@/domain/subjects";

type Point = { label: string; total: number; [key: string]: string | number | null };
const COLORS: Record<SubjectKey, string> = { JAPANESE: "#1677a6", MATH: "#d65f45", ENGLISH: "#7057a8", SCIENCE: "#24816f", SOCIAL_STUDIES: "#a06a1b" };

export function AcademicKarteChart({ data, hasAverage }: { data: Point[]; hasAverage: boolean }) {
  const [mode, setMode] = useState<"all" | "subject" | "total" | "average">("all");
  const [subject, setSubject] = useState<SubjectKey>("MATH");
  const controls: Array<["all" | "subject" | "total" | "average", string]> = [["all", "5教科すべて"], ["subject", "教科別"], ["total", "合計点"]];
  if (hasAverage) controls.push(["average", "平均点との差"]);
  const keys = mode === "all" ? SUBJECTS : mode === "subject" ? [subject] : mode === "total" ? ["total"] : SUBJECTS.map((key) => `${key}AverageDiff`);
  return <div>
    <div className="mb-4 flex flex-wrap gap-2" role="group" aria-label="グラフ表示切替">{controls.map(([key, label]) => <button key={key} type="button" aria-pressed={mode === key} onClick={() => setMode(key)} className={`min-h-11 rounded-full border px-4 font-bold ${mode === key ? "border-[#123a5a] bg-[#123a5a] text-white" : "border-[#b8ccd9] bg-white"}`}>{label}</button>)}</div>
    {mode === "subject" ? <label className="field mb-4 max-w-xs"><span>表示教科</span><select value={subject} onChange={(event) => setSubject(event.target.value as SubjectKey)}>{SUBJECTS.map((key) => <option key={key} value={key}>{SUBJECT_LABELS[key]}</option>)}</select></label> : null}
    <div className="h-80 w-full" role="img" aria-label="教科別得点推移グラフ"><ResponsiveContainer><LineChart data={data} margin={{ top: 8, right: 16, left: -12, bottom: 6 }}><CartesianGrid strokeDasharray="4 4" stroke="#dce7ef"/><XAxis dataKey="label" tick={{ fontSize: 11 }}/><YAxis domain={mode === "average" ? ["auto", "auto"] : mode === "total" ? [0, 500] : [0, 100]}/><Tooltip formatter={(value, name) => [`${Number(value).toFixed(1)}点`, name === "total" ? "5教科合計" : SUBJECT_LABELS[String(name).replace("AverageDiff", "") as SubjectKey] ?? String(name)]}/><Legend/>{keys.map((key) => { const subjectKey = String(key).replace("AverageDiff", "") as SubjectKey; return <Line key={key} type="monotone" connectNulls dataKey={key} name={key === "total" ? "5教科合計" : SUBJECT_LABELS[subjectKey]} stroke={key === "total" ? "#123a5a" : COLORS[subjectKey]} strokeWidth={3} dot={{ r: 4 }} />; })}</LineChart></ResponsiveContainer></div>
    <p className="help mt-3">偏差値は入力データがないため表示していません。グラフと同じ数値は下の一覧でも確認できます。</p>
  </div>;
}
