export function ErrorBanner({ message }: { message?: string }) {
  return message ? <p role="alert" className="error-banner mb-5">{message}</p> : null;
}
