"use client";
import { useState } from "react";
export function PromptCopyButton({prompt,auditUrl}:{prompt:string;auditUrl:string}){const[copied,setCopied]=useState(false);async function copy(){await navigator.clipboard.writeText(prompt);await fetch(auditUrl,{method:"POST"});setCopied(true);}return <button className="btn-primary" type="button" onClick={copy}>{copied?"コピーしました":"プロンプトをコピー"}</button>}
