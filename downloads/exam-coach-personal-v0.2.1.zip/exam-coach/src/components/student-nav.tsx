import Link from "next/link";

const links = [
  ["概要", ""],
  ["学力カルテ", "/academic"],
  ["学習カルテ", "/learning"],
  ["受験カルテ", "/exam"],
  ["問題カルテ", "/problems"],
  ["復習カルテ", "/reviews"],
  ["学習プラン", "/plans"],
  ["学習記録", "/records"],
  ["類似問題を作る", "/generations/new"],
  ["個別問題集", "/workbooks"],
] as const;

export function StudentNav({ studentId }: { studentId: string }) {
  return (
    <nav aria-label="生徒メニュー" className="mb-8 overflow-x-auto rounded-2xl border border-[#dce7ef] bg-white p-2 shadow-sm">
      <div className="flex min-w-max gap-1">
        {links.map(([label, suffix]) => (
          <Link key={label} href={`/students/${studentId}${suffix}`} className="rounded-xl px-4 py-2.5 text-sm font-extrabold text-[#35546c] no-underline hover:bg-[#eaf7f5]">
            {label}
          </Link>
        ))}
      </div>
    </nav>
  );
}
