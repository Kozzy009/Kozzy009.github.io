"use client";
export function ManualPrintButton(){return <button className="btn-primary" onClick={()=>window.print()} type="button">印刷／PDFとして保存</button>}
