"use client";
import { useEffect, useState } from "react";

const steps=["生徒を登録","志望校を設定","学力テスト結果を入力","学習アンケートに回答","分析結果を確認","学習プランを作成","必要に応じてAI解析JSONを取り込む","類似問題と個別問題集を作成"];
export function FirstRunGuide(){const[visible,setVisible]=useState(false);useEffect(()=>{const timer=window.setTimeout(()=>setVisible(localStorage.getItem("iwaki-hide-first-guide")!=="1"),0);return()=>window.clearTimeout(timer)},[]);if(!visible)return null;return <section className="card card-pad mb-7 border-[#9bd4cf]"><div className="flex flex-wrap items-start justify-between gap-3"><div><p className="eyebrow">はじめての方へ</p><h2 className="section-title mt-1">基本の利用順</h2></div><button className="btn-secondary" onClick={()=>{localStorage.setItem("iwaki-hide-first-guide","1");setVisible(false)}} type="button">次回から表示しない</button></div><ol className="mt-5 grid gap-2 sm:grid-cols-2">{steps.map((step,index)=><li key={step}><span className="mr-2 font-black text-[#1677a6]">{index+1}.</span>{step}</li>)}</ol></section>}
