import { prisma } from "@/lib/prisma";

const latestFirst = [{ takenOn: "desc" as const }, { createdAt: "desc" as const }];

export async function getKarteHeader(studentId: string) {
  return prisma.student.findUnique({
    where: { id: studentId },
    include: {
      targetSchools: { orderBy: { preferenceRank: "asc" }, take: 2 },
      academicTests: { orderBy: latestFirst, take: 1 },
      studySurveys: { orderBy: [{ answeredOn: "desc" }, { createdAt: "desc" }], take: 1 },
      weeklyStudyPlans: { orderBy: [{ weekStartOn: "desc" }, { version: "desc" }], take: 1, include: { items: { include: { studyRecord: true } } } },
    },
  });
}

export async function getOverviewKarte(studentId: string) {
  return prisma.student.findUnique({
    where: { id: studentId },
    include: {
      targetSchools: { orderBy: { preferenceRank: "asc" }, take: 2 },
      academicTests: { orderBy: latestFirst, take: 3, include: { scores: true } },
      studySurveys: { orderBy: [{ answeredOn: "desc" }, { createdAt: "desc" }], take: 1, include: { subjects: true } },
      analysisResults: { orderBy: { createdAt: "desc" }, take: 1, include: { subjectAnalyses: { orderBy: { priorityRank: "asc" } }, learningTendencies: { orderBy: { score: "desc" } } } },
      weeklyStudyPlans: { orderBy: [{ weekStartOn: "desc" }, { version: "desc" }], take: 1, include: { items: { include: { studyRecord: true } } } },
      reviewProfiles: { orderBy: { nextReviewOn: "asc" }, take: 1, include: { problemProfile: true } },
    },
  });
}

export async function getAcademicKarte(studentId: string) {
  return prisma.student.findUnique({
    where: { id: studentId },
    include: {
      academicTests: { orderBy: [{ takenOn: "asc" }, { createdAt: "asc" }], include: { scores: true } },
      studySurveys: { orderBy: [{ answeredOn: "desc" }, { createdAt: "desc" }], take: 1, include: { subjects: true } },
      analysisResults: { orderBy: { createdAt: "desc" }, take: 1, include: { subjectAnalyses: { orderBy: { priorityRank: "asc" } } } },
      problemProfiles: { orderBy: { attemptedOn: "desc" } },
    },
  });
}

export async function getLearningKarte(studentId: string) {
  return prisma.student.findUnique({
    where: { id: studentId },
    include: {
      studySurveys: { orderBy: [{ answeredOn: "desc" }, { createdAt: "desc" }], take: 2, include: { subjects: true } },
      analysisResults: { orderBy: { createdAt: "desc" }, take: 1, include: { learningTendencies: { orderBy: { score: "desc" } } } },
    },
  });
}

export async function getExamKarte(studentId: string) {
  return prisma.student.findUnique({
    where: { id: studentId },
    include: {
      targetSchools: { orderBy: { preferenceRank: "asc" }, include: { subjectGoals: true, histories: { orderBy: { changedAt: "desc" }, take: 20 } } },
      academicTests: { orderBy: latestFirst, take: 1, include: { scores: true } },
    },
  });
}

export type ProblemFilters = { subject?: string; unit?: string; correctness?: string; mistake?: string; test?: string; review?: string };

export async function getProblemKarte(studentId: string, filters: ProblemFilters = {}) {
  const where = {
    studentId,
    ...(filters.subject ? { subject: filters.subject as "JAPANESE" | "MATH" | "ENGLISH" | "SCIENCE" | "SOCIAL_STUDIES" } : {}),
    ...(filters.unit ? { unit: { contains: filters.unit } } : {}),
    ...(filters.correctness === "correct" ? { isCorrect: true } : filters.correctness === "incorrect" ? { isCorrect: false } : {}),
    ...(filters.test ? { testName: { contains: filters.test } } : {}),
    ...(filters.review === "yes" ? { isReviewTarget: true } : filters.review === "no" ? { isReviewTarget: false } : {}),
  };
  const [student, problems] = await Promise.all([
    prisma.student.findUnique({ where: { id: studentId }, select: { id: true, displayName: true } }),
    prisma.problemProfile.findMany({ where, include: { reviewProfile: { include: { attempts: { orderBy: { reviewedOn: "desc" } } } }, manualAiImportQuestion: true }, orderBy: [{ attemptedOn: "desc" }, { createdAt: "desc" }] }),
  ]);
  const mistake = filters.mistake;
  const filtered = mistake ? problems.filter((problem) => Array.isArray(problem.mistakeTypes) && problem.mistakeTypes.includes(mistake)) : problems;
  return student ? { student, problems: filtered } : null;
}

export async function getReviewKarte(studentId: string) {
  const [student, reviews] = await Promise.all([
    prisma.student.findUnique({ where: { id: studentId }, select: { id: true, displayName: true } }),
    prisma.reviewProfile.findMany({ where: { studentId }, include: { problemProfile: true, attempts: { orderBy: { reviewedOn: "asc" } } }, orderBy: [{ nextReviewOn: "asc" }, { createdAt: "asc" }] }),
  ]);
  return student ? { student, reviews } : null;
}

export async function getStudyRecordsKarte(studentId: string) {
  return prisma.student.findUnique({ where: { id: studentId }, include: { weeklyStudyPlans: { include: { items: { include: { studyRecord: true }, orderBy: [{ plannedOn: "desc" }, { sequence: "asc" }] } }, orderBy: [{ weekStartOn: "desc" }, { version: "desc" }], take: 12 } } });
}
