import "server-only";
import { prisma } from "@/lib/prisma";

export function getFileList(studentId: string) {
  return prisma.student.findUnique({ where: { id: studentId }, include: { academicTests: { orderBy: { takenOn: "desc" }, include: { uploadedFiles: { orderBy: { uploadedAt: "desc" }, include: { importSession: true } } } } } });
}
export function getUploadContext(studentId: string) {
  return prisma.student.findUnique({ where: { id: studentId }, include: { academicTests: { orderBy: { takenOn: "desc" } } } });
}
export function getUploadedFile(studentId: string, fileId: string) {
  return prisma.uploadedFile.findFirst({ where: { id: fileId, studentId }, include: { academicTest: true, importSession: true, ocrJobs: { orderBy: { createdAt: "desc" }, include: { pages: true, extractedItems: true } } } });
}
export function getImportSession(studentId: string, sessionId: string) {
  return prisma.importSession.findFirst({
    where: { id: sessionId, studentId },
    include: {
      student: true, academicTest: true,
      uploadedFiles: { orderBy: { uploadedAt: "asc" }, include: { ocrJobs: { orderBy: { createdAt: "desc" }, include: { extractedItems: { orderBy: [{ pageNumber: "asc" }, { fieldName: "asc" }] } } } } },
      candidates: { orderBy: [{ subject: "asc" }, { majorQuestionNumber: "asc" }, { minorQuestionNumber: "asc" }] },
    },
  });
}
