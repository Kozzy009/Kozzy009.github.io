import "server-only";
import { prisma } from "@/lib/prisma";

export function getManualAiList(studentId:string){return prisma.student.findUnique({where:{id:studentId},include:{manualAiImportSessions:{orderBy:{createdAt:"desc"},include:{academicTest:true,_count:{select:{questions:true}}}}}});}
export function getManualAiContext(studentId:string){return prisma.student.findUnique({where:{id:studentId},include:{academicTests:{orderBy:{takenOn:"desc"},include:{uploadedFiles:{orderBy:{uploadedAt:"desc"}}}}}});}
export function getManualAiSession(studentId:string,sessionId:string){return prisma.manualAiImportSession.findFirst({where:{id:sessionId,studentId},include:{student:true,academicTest:true,questions:{orderBy:[{majorQuestionNumber:"asc"},{minorQuestionNumber:"asc"}]},summary:true}});}
