import { describe, expect, it } from "vitest";
import type { SubjectPriority } from "@/domain/analysis";
import type { LearningSurveyProfile } from "@/domain/learning-survey";
import { generateStudyPlan } from "@/domain/study-plan";
import { PRIORITY_TIE_ORDER } from "@/domain/subjects";

const priorities: SubjectPriority[] = PRIORITY_TIE_ORDER.map((subject, index) => ({
  subject, priorityScore: 10 - index * 2, priorityRank: index + 1,
  latestScoreRate: 55 + index * 10, scoreRateDelta: index === 0 ? -8 : 1, reasons: [],
  recentScoreRates: index === 0 ? [60, 58, 55] : [55 + index * 10, 56 + index * 10, 57 + index * 10], selfEvaluationScore: index === 0 ? 1 : 4,
  confidenceLevel: index === 0 ? 2 : 4, recognitionLabel: "テスト用", analysisComment: "テスト用の分析です。",
}));

function profile(overrides: Partial<LearningSurveyProfile> = {}): LearningSurveyProfile {
  return {
    currentWeekdayMinutes: 10, currentWeekendMinutes: 20,
    weekdayAvailableMinutes: 45, weekendAvailableMinutes: 90, concentrationMinutes: 20,
    availableDaysPerWeek: 5, availableDays: ["MON", "TUE", "WED", "THU", "SAT"], busyDays: [], preferredTimeOfDay: "EVENING",
    motivationAnswers: { targetSchool: 5, improveGrades: 5, selfStart: 4, followPlan: 4, faceWeakSubjects: 3 },
    confidenceAnswers: { effortWorks: 3, achievement: 3, improveWeakness: 3, improveTest: 3, solveUnknown: 3 },
    studyMethodAnswers: { reviewMistakes: 3, timedPractice: 3, solveProblems: 3 },
    concentrationAnswers: { sustainFocus: 3, stopDevices: 3, quietPlace: 4, independentStart: 3, shortWhenTired: 3 },
    motivationScore: 4.2, confidenceScore: 3, studyHabitScore: 3, reviewHabitScore: 3,
    concentrationScore: 3, environmentScore: 3.5,
    subjects: priorities.map((item, index) => ({ subject: item.subject, weeklyStudyMinutes: 60 - index * 5, confidenceLevel: index === 0 ? 2 : 4, selfEvaluationScore: index === 0 ? 1 : 4, studyFrequencyPerWeek: index === 0 ? 1 : 3, preferenceScore: index === 0 ? 1 : 4, difficultyScore: index === 0 ? 5 : 2, easeOfStartingScore: index === 0 ? 1 : 4, knowsWhatToStudyScore: index === 0 ? 2 : 4 })),
    ...overrides,
  };
}

describe("generateStudyPlan", () => {
  it("自信が低い生徒には短時間・少量の計画を作る", () => {
    const plan = generateStudyPlan({ priorities, survey: profile({ confidenceScore: 2.2, concentrationMinutes: 30 }) });
    expect(plan.recommendedSessionMinutes).toBe(15);
    expect(plan.items.every((item) => item.durationMinutes <= 15 && item.problemCount >= 3 && item.problemCount <= 5)).toBe(true);
  });

  it("学習時間が少ない場合は優先教科を2教科以内に絞る", () => {
    const plan = generateStudyPlan({ priorities, survey: profile({ weekdayAvailableMinutes: 10, weekendAvailableMinutes: 15, availableDaysPerWeek: 3 }) });
    expect(plan.focusSubjects).toHaveLength(2);
    expect(plan.adjustments.some((item) => item.includes("最大2教科"))).toBe(true);
  });

  it("苦手教科だけで埋めず、得点が安定した教科も含める", () => {
    const plan = generateStudyPlan({ priorities, survey: profile() });
    expect(plan.items.some((item) => item.subject === "SOCIAL_STUDIES")).toBe(true);
    const firstCount = plan.items.filter((item) => item.subject === priorities[0].subject).length;
    expect(firstCount / plan.items.length).toBeLessThanOrEqual(0.4);
  });

  it("1日の計画時間が可能時間を超えない", () => {
    const survey = profile();
    const plan = generateStudyPlan({ priorities, survey });
    for (let day = 0; day < 7; day += 1) {
      const minutes = plan.items.filter((item) => item.dayOffset === day).reduce((sum, item) => sum + item.durationMinutes, 0);
      expect(minutes).toBeLessThanOrEqual(day < 5 ? survey.weekdayAvailableMinutes : survey.weekendAvailableMinutes);
    }
  });

  it("忙しい曜日には課題を設定しない", () => {
    const plan = generateStudyPlan({ priorities, survey: profile({ busyDays: ["TUE", "THU"] }) });
    expect(plan.items.some((item) => item.dayOffset === 1 || item.dayOffset === 3)).toBe(false);
  });

  it("前週の完了率が低い場合は次週の課題量を減らす", () => {
    const normal = generateStudyPlan({ priorities, survey: profile() });
    const reduced = generateStudyPlan({ priorities, survey: profile(), previousWeek: { completionRate: 0.4, correctRate: 0.7, averageTimeRatio: 1, concentrationAverage: 3, recurringMistakes: false } });
    expect(reduced.plannedMinutes).toBeLessThan(normal.plannedMinutes);
  });

  it("正答率が高い場合は難易度を上げる", () => {
    const plan = generateStudyPlan({ priorities, survey: profile({ confidenceScore: 4 }), previousWeek: { completionRate: 1, correctRate: 0.9, averageTimeRatio: 1, concentrationAverage: 4, recurringMistakes: false } });
    expect(plan.items.some((item) => item.difficulty === "ADVANCED")).toBe(true);
  });

  it("確保時間0分でも空の有効な計画を返す", () => {
    const plan = generateStudyPlan({ priorities, survey: profile({ weekdayAvailableMinutes: 0, weekendAvailableMinutes: 0 }) });
    expect(plan.items).toEqual([]);
    expect(plan.plannedMinutes).toBe(0);
  });

  it("現在10分・確保30分・集中15分では週4日、短時間で得意教科も組み合わせる", () => {
    const survey = profile({
      currentWeekdayMinutes: 10,
      weekdayAvailableMinutes: 30,
      weekendAvailableMinutes: 60,
      concentrationMinutes: 15,
      availableDaysPerWeek: 4,
      availableDays: ["MON", "TUE", "THU", "SAT"],
      confidenceScore: 2,
      reviewHabitScore: 1,
    });
    const plan = generateStudyPlan({ priorities, survey, tendencies: [{ tendencyType: "CARELESS_REVIEW", score: 4, statement: "", evidence: [], recommendations: [] }] });
    expect(plan.recommendedDays).toBe(4);
    expect(plan.recommendedSessionMinutes).toBe(15);
    expect(plan.items.every((item) => item.durationMinutes <= 15)).toBe(true);
    expect(plan.items.filter((item) => item.subject === "MATH").length).toBeLessThan(plan.items.length);
    expect(plan.items.some((item) => item.activity.includes("間違い直し"))).toBe(true);
  });
});
