import { describe, expect, it } from "vitest";
import { ManualEntryProvider, MockOcrProvider, gradeCandidate, normalizeAnswer, parseQuestionField } from "@/domain/file-import";

describe("OCR候補と正誤候補", () => {
  it("Mockプロバイダーが問題用紙7問の候補を返す", async () => {
    const output = await new MockOcrProvider().extractText({ fileType: "QUESTION_PAPER", subject: "MATH" });
    expect(output.pages).toHaveLength(1); expect(output.items.filter(item => item.fieldName.endsWith("questionText"))).toHaveLength(7);
  });
  it("本人解答と模範解答の候補を返す", async () => {
    const provider = new MockOcrProvider();
    expect((await provider.extractText({ fileType: "STUDENT_ANSWER", subject: "MATH" })).items).toHaveLength(7);
    expect((await provider.extractText({ fileType: "MODEL_ANSWER", subject: "MATH" })).items).toHaveLength(14);
  });
  it("手入力プロバイダーは自動候補を確定しない", async () => {
    expect((await new ManualEntryProvider().extractText({ fileType: "OTHER", subject: "UNCLASSIFIED" })).items).toEqual([]);
  });
  it("番号付きフィールドを対応付けキーへ分解する", () => {
    expect(parseQuestionField("question.2.3.answerText")).toEqual({ major: "2", minor: "3", field: "answerText" });
    expect(parseQuestionField("unknown")).toBeNull();
  });
  it("空白・全半角・英字大小を正規化して一致判定する", () => {
    expect(normalizeAnswer(" ＡＢＣ  ")).toBe("abc");
    expect(gradeCandidate({ answerText: " １２ ", correctAnswer: "12", questionType: "短答" })).toBe("CORRECT");
  });
  it("無回答・記述・正答不足を自動確定しない", () => {
    expect(gradeCandidate({ answerText: "", correctAnswer: "1" })).toBe("UNANSWERED");
    expect(gradeCandidate({ answerText: "理由", correctAnswer: "理由", questionType: "記述" })).toBe("NEEDS_REVIEW");
    expect(gradeCandidate({ answerText: "1", correctAnswer: "" })).toBe("UNDETERMINED");
  });
});
