import { describe, expect, it } from "vitest";
import { initialReviewDate, nextReviewSchedule } from "@/domain/review-schedule";

describe("復習スケジュール", () => {
  const date = new Date("2026-08-04T00:00:00+09:00");

  it("初回誤答の翌日を初期予定にする", () => {
    expect(initialReviewDate(date).getDate()).toBe(5);
  });

  it("連続正解で3日、7日、14日、30日へ間隔を延ばす", () => {
    const expected = [3, 7, 14, 30];
    expected.forEach((days, consecutiveCorrect) => {
      const result = nextReviewSchedule({ reviewedOn: date, isCorrect: true, consecutiveCorrect });
      expect((result.nextReviewOn.getTime() - date.getTime()) / 86_400_000).toBe(days);
    });
  });

  it("再度間違えた場合は翌日に戻す", () => {
    const result = nextReviewSchedule({ reviewedOn: date, isCorrect: false, consecutiveCorrect: 3 });
    expect(result.consecutiveCorrect).toBe(0);
    expect(result.status).toBe("RECHECK_NEEDED");
    expect((result.nextReviewOn.getTime() - date.getTime()) / 86_400_000).toBe(1);
  });
});
