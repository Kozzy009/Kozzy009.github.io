import { describe, expect, it } from "vitest";
import { priorityUnits, scoreTrend } from "@/domain/karte-analysis";

describe("カルテ分析", () => {
  it("誤答と期限到来の復習から優先単元を選ぶ", () => {
    const result = priorityUnits([
      { subject: "MATH", unit: "一次方程式", isCorrect: false, isUnanswered: false, mistakeTypes: ["CALCULATION"], isReviewTarget: true, nextReviewOn: new Date("2026-08-03") },
      { subject: "MATH", unit: "図形", isCorrect: false, isUnanswered: false, mistakeTypes: ["METHOD"], isReviewTarget: false },
    ], new Date("2026-08-04"));
    expect(result.get("MATH")?.unit).toBe("一次方程式");
  });

  it("得点推移を6区分で返す", () => {
    expect(scoreTrend([48, 42, 36])).toBe("下降傾向");
    expect(scoreTrend([70, 72, 74])).toBe("やや上昇");
    expect(scoreTrend([70])).toBe("データ不足");
  });
});
