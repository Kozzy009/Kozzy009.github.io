import { describe, expect, it } from "vitest";
import { analyzeLearningTendencies, buildLearningSummary } from "@/domain/learning-analysis";
import type { LearningSurveyProfile } from "@/domain/learning-survey";
import { SUBJECTS } from "@/domain/subjects";

function survey(): LearningSurveyProfile {
  return {
    currentWeekdayMinutes: 10, currentWeekendMinutes: 20,
    weekdayAvailableMinutes: 30, weekendAvailableMinutes: 60, concentrationMinutes: 20, availableDaysPerWeek: 5,
    availableDays: ["MON", "WED", "THU", "FRI", "SAT"],
    busyDays: ["TUE"], preferredTimeOfDay: "EVENING",
    motivationAnswers: { targetSchool: 5, improveGrades: 5, selfStart: 4, followPlan: 5, faceWeakSubjects: 3 },
    confidenceAnswers: { effortWorks: 3, achievement: 3, improveWeakness: 3, improveTest: 3, solveUnknown: 2 },
    studyMethodAnswers: { planBeforeTests: 1, reviewMistakes: 1, readExplanations: 4, solveProblems: 2, timedPractice: 1, repeatProblems: 2 },
    concentrationAnswers: { sustainFocus: 3, stopDevices: 3, quietPlace: 4, independentStart: 3, shortWhenTired: 4 },
    motivationScore: 4.4, confidenceScore: 2.8, studyHabitScore: 2.4, reviewHabitScore: 2.3, concentrationScore: 3.3, environmentScore: 3.5,
    subjects: SUBJECTS.map((subject, index) => ({ subject, weeklyStudyMinutes: index === 0 ? 10 : 60, confidenceLevel: index === 0 ? 2 : 3, selfEvaluationScore: index === 0 ? 1 : 3, studyFrequencyPerWeek: index === 0 ? 1 : 3, preferenceScore: index === 0 ? 1 : 3, difficultyScore: index === 0 ? 5 : 3, easeOfStartingScore: index === 0 ? 1 : 3, knowsWhatToStudyScore: index === 0 ? 1 : 3 })),
  };
}

describe("learning tendency analysis", () => {
  it("意欲は高いが方法が分からない場合に具体化タイプを判定する", () => {
    const result = analyzeLearningTendencies(survey(), {});
    const tendency = result.find((item) => item.tendencyType === "NEEDS_METHOD");
    expect(tendency).toBeDefined();
    expect(tendency?.recommendations.join(" ")).toContain("問題数");
  });

  it("長時間学習で成績が伸びない場合に問題演習を推奨する", () => {
    const input = survey();
    input.subjects = input.subjects.map((item) => ({ ...item, weeklyStudyMinutes: 100 }));
    const currentScores = SUBJECTS.map((subject) => ({ subject, score: 60, maxScore: 100 }));
    const previousScores = SUBJECTS.map((subject) => ({ subject, score: 65, maxScore: 100 }));
    const result = analyzeLearningTendencies(input, { currentScores, previousScores });
    expect(result.find((item) => item.tendencyType === "EFFORT_NOT_CONVERTING")?.recommendations.join(" ")).toContain("問題演習");
  });

  it("空データでもエラーにせず空結果を返す", () => {
    expect(analyzeLearningTendencies(null, {})).toEqual([]);
    expect(buildLearningSummary(null, [], [])).toBeNull();
  });
});
