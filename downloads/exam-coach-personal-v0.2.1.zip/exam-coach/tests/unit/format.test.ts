import { describe, expect, it } from "vitest";
import { startOfWeek, toDateInput } from "@/lib/format";

describe("startOfWeek", () => {
  it("Asia/Tokyo基準で対象週の月曜日を返す", () => {
    expect(toDateInput(startOfWeek(new Date("2026-08-09T22:00:00+09:00")))).toBe("2026-08-03");
    expect(toDateInput(startOfWeek(new Date("2026-08-03T08:00:00+09:00")))).toBe("2026-08-03");
  });
});
