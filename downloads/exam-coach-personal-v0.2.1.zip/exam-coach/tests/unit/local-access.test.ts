import { describe, expect, it } from "vitest";
import { isLocalRequest } from "@/domain/local-access";

describe("個人端末アクセス", () => {
  it("localhostでの閲覧と同一originの変更を許可する", () => {
    expect(isLocalRequest("127.0.0.1:3000", null, "none")).toBe(true);
    expect(isLocalRequest("localhost:3000", "http://localhost:3000", "same-origin")).toBe(true);
    expect(isLocalRequest("[::1]:3000", null, null)).toBe(true);
  });
  it("外部サイトからのリクエストとDNS rebinding用Hostを拒否する", () => {
    for (const host of [null, "evil.example:3000", "localhost.evil.example", "localhost:3000/path", "user@localhost:3000"]) {
      expect(isLocalRequest(host, null, null)).toBe(false);
    }
    expect(isLocalRequest("localhost:3000", "https://evil.example", null)).toBe(false);
    expect(isLocalRequest("localhost:3000", null, "cross-site")).toBe(false);
    expect(isLocalRequest("localhost:3000", "null", null)).toBe(false);
    expect(isLocalRequest("localhost:3000", "http://localhost:4000", null)).toBe(false);
  });
});
