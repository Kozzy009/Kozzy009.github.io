import { describe, expect, it } from "vitest";
import { problemProfileSchema } from "@/lib/validation";

const valid = { testName: "確認テスト", attemptedOn: "2026-08-01", subject: "MATH", majorNumber: "1", minorNumber: "(1)", area: "数と式", unit: "一次方程式", questionFormat: "短答", difficulty: "BASIC", points: "5", studentAnswer: "x=2", correctAnswer: "x=3", isCorrect: false, answerSeconds: "120", isUnanswered: false, mistakeTypes: ["CALCULATION"], instructorComment: "途中式を確認", isReviewTarget: true };

describe("問題カルテ入力", () => {
  it("正しい手入力を受理する", () => expect(problemProfileSchema.safeParse(valid).success).toBe(true));
  it("無回答かつ正解の矛盾を拒否する", () => expect(problemProfileSchema.safeParse({ ...valid, isUnanswered: true, isCorrect: true }).success).toBe(false));
  it("未知のミス種別を拒否する", () => expect(problemProfileSchema.safeParse({ ...valid, mistakeTypes: ["INVALID"] }).success).toBe(false));
});
