import { describe, expect, it } from "vitest";
import { validateUpload } from "@/lib/upload-validation";

describe("アップロードファイル検証", () => {
  it("PDFの拡張子・MIME・実体を検証する", () => {
    const result = validateUpload({ name: "結果.pdf", type: "application/pdf", bytes: new TextEncoder().encode("%PDF-1.7 sample") });
    expect(result.extension).toBe("pdf"); expect(result.fileHash).toHaveLength(64);
  });
  it("PNGのシグネチャを許可する", () => {
    const bytes = new Uint8Array([137,80,78,71,13,10,26,10,1]);
    expect(validateUpload({ name: "answer.PNG", type: "image/png", bytes }).mimeType).toBe("image/png");
  });
  it("JPEGのシグネチャを許可する", () => {
    expect(validateUpload({ name: "answer.jpg", type: "image/jpeg", bytes: new Uint8Array([255,216,255,1]) }).extension).toBe("jpg");
  });
  it("不正形式とMIME不一致を拒否する", () => {
    expect(() => validateUpload({ name: "x.txt", type: "text/plain", bytes: new Uint8Array([1]) })).toThrow("PDF、PNG、JPEG");
    expect(() => validateUpload({ name: "x.pdf", type: "image/png", bytes: new TextEncoder().encode("%PDF-") })).toThrow("MIMEタイプ");
  });
  it("実体と拡張子の不一致を拒否する", () => {
    expect(() => validateUpload({ name: "x.png", type: "image/png", bytes: new TextEncoder().encode("not png") })).toThrow("実体と拡張子");
  });
  it("0バイトと上限超過を拒否する", () => {
    expect(() => validateUpload({ name: "x.pdf", type: "application/pdf", bytes: new Uint8Array() })).toThrow("0バイト");
    expect(() => validateUpload({ name: "x.pdf", type: "application/pdf", bytes: new TextEncoder().encode("%PDF-123") }, 5)).toThrow("ファイルサイズ");
  });
  it("危険なファイル名を拒否する", () => {
    expect(() => validateUpload({ name: "../x.pdf", type: "application/pdf", bytes: new TextEncoder().encode("%PDF-") })).toThrow("ファイル名");
  });
});
