import { describe, expect, it } from "vitest";
import { calculatePriorities, type ScoreInput, type SurveySubjectInput } from "@/domain/analysis";
import { SUBJECTS } from "@/domain/subjects";

const scores = (values: number[]): ScoreInput[] => SUBJECTS.map((subject, index) => ({ subject, score: values[index], maxScore: 100 }));
const survey = (minutes: number[], confidence: number[]): SurveySubjectInput[] => SUBJECTS.map((subject, index) => ({ subject, weeklyStudyMinutes: minutes[index], confidenceLevel: confidence[index] }));

describe("calculatePriorities", () => {
  it("得点率・低下・自信度・学習時間を説明可能な点数にする", () => {
    const result = calculatePriorities({
      currentScores: scores([55, 65, 75, 80, 90]),
      previousScores: scores([70, 70, 80, 82, 91]),
      surveySubjects: survey([10, 20, 30, 40, 50], [2, 3, 4, 5, 5]),
    });
    const japanese = result.find((item) => item.subject === "JAPANESE");
    expect(japanese?.priorityScore).toBe(10);
    expect(japanese?.priorityRank).toBe(1);
    expect(japanese?.reasons.filter((reason) => reason.points > 0)).toHaveLength(4);
  });

  it("得点率の境界値60・70・80を正しく扱う", () => {
    const result = calculatePriorities({ currentScores: scores([59, 60, 70, 80, 90]) });
    const bySubject = new Map(result.map((item) => [item.subject, item.priorityScore]));
    expect(bySubject.get("JAPANESE")).toBe(4);
    expect(bySubject.get("MATH")).toBe(3);
    expect(bySubject.get("ENGLISH")).toBe(2);
    expect(bySubject.get("SCIENCE")).toBe(0);
  });

  it("前回差の境界値-5・-10ポイントを正しく扱う", () => {
    const result = calculatePriorities({
      currentScores: scores([90, 85, 80, 79, 78]),
      previousScores: scores([90, 90, 90, 80, 80]),
    });
    const math = result.find((item) => item.subject === "MATH");
    const english = result.find((item) => item.subject === "ENGLISH");
    expect(math?.reasons.find((reason) => reason.category === "trend")?.points).toBe(1);
    expect(english?.reasons.find((reason) => reason.category === "trend")?.points).toBe(2);
  });

  it("入力が同じなら固定順で同じ結果を返す", () => {
    const input = { surveySubjects: survey([30, 30, 30, 30, 30], [5, 5, 5, 5, 5]) };
    const first = calculatePriorities(input).map((item) => item.subject);
    const second = calculatePriorities(input).map((item) => item.subject);
    expect(first).toEqual(["MATH", "ENGLISH", "JAPANESE", "SCIENCE", "SOCIAL_STUDIES"]);
    expect(second).toEqual(first);
  });

  it("分析元がない場合は明示的に失敗する", () => {
    expect(() => calculatePriorities({})).toThrow("テスト結果またはアンケート");
  });

  it("苦手感・始めにくさ・学ぶ内容の不明確さを優先理由へ加える", () => {
    const input = survey([10, 50, 60, 70, 80], [2, 4, 4, 4, 4]);
    input[0] = { ...input[0], difficultyScore: 5, easeOfStartingScore: 1, knowsWhatToStudyScore: 1 };
    const japanese = calculatePriorities({ surveySubjects: input }).find((item) => item.subject === "JAPANESE");
    expect(japanese?.reasons.find((reason) => reason.category === "avoidance")?.points).toBe(2);
    expect(japanese?.reasons.find((reason) => reason.category === "clarity")?.points).toBe(1);
  });

  it("本人の認識と最近3回の推移を区別して説明する", () => {
    const surveySubjects = survey([30, 20, 30, 25, 50], [3, 1, 3, 3, 4]);
    surveySubjects[1] = { ...surveySubjects[1], selfEvaluationScore: 1, easeOfStartingScore: 2, knowsWhatToStudyScore: 1, studyFrequencyPerWeek: 1 };
    surveySubjects[4] = { ...surveySubjects[4], selfEvaluationScore: 5, easeOfStartingScore: 5, knowsWhatToStudyScore: 4, studyFrequencyPerWeek: 2 };
    const result = calculatePriorities({
      recentScores: [scores([67, 36, 64, 65, 74]), scores([66, 42, 62, 64, 72]), scores([65, 48, 60, 62, 70])],
      surveySubjects,
    });
    const math = result.find((item) => item.subject === "MATH");
    const social = result.find((item) => item.subject === "SOCIAL_STUDIES");
    expect(math?.recentScoreRates).toEqual([48, 42, 36]);
    expect(math?.analysisComment).toContain("苦手");
    expect(math?.analysisComment).toContain("下降");
    expect(social?.recentScoreRates).toEqual([70, 72, 74]);
    expect(social?.analysisComment).toContain("一致");
  });
});
