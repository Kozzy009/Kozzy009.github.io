import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const read=(name:string)=>readFileSync(new URL(`../../${name}`,import.meta.url),"utf8");
describe("試験運用スクリプト",()=>{
  it("危険なDB初期化やシードを本番スクリプトから呼ばない",()=>{
    const scripts=["scripts/setup-production.sh","scripts/start-production.sh","scripts/stop-production.sh","scripts/backup.sh","scripts/restore.sh"].map(read).join("\n");
    expect(scripts).not.toMatch(/prisma\s+migrate\s+reset/);
    expect(scripts).not.toMatch(/prisma\s+db\s+push/);
    expect(scripts).not.toMatch(/db:seed|prisma\s+db\s+seed/);
  });
  it("本番既定値はデモ・開発ツール・LANを無効化する",()=>{
    const setup=read("scripts/setup-production.sh");
    expect(setup).toContain('ENABLE_DEMO_DATA="false"');
    expect(setup).toContain('ENABLE_DEV_TOOLS="false"');
    expect(setup).toContain('ENABLE_LAN_ACCESS="false"');
  });
  it("実データと秘密設定をGit対象外にする",()=>{
    const ignore=read(".gitignore");
    expect(ignore).toContain(".env*");
    expect(ignore).toContain("iwaki-exam-coach-data/");
    expect(ignore).toContain("/.data/backups");
  });
  it("停止はPIDとプロセス所有関係を検証しkillallを使わない",()=>{
    const common=read("scripts/common.sh"),stop=read("scripts/stop-production.sh");
    expect(common).toContain("is_app_process");
    expect(stop).not.toContain("killall");
    expect(stop).toContain('kill -TERM "$APP_PID"');
  });
});
