import { describe, expect, it, vi } from 'vitest';
import { selectPort } from '../../scripts/local-port.mjs';

describe('起動用ポートの自動選択', () => {
  it('希望ポートが空いていればそのまま使う', async () => {
    const probe = vi.fn(async port => port);
    expect(await selectPort(3000, probe)).toBe(3000);
    expect(probe).toHaveBeenCalledExactlyOnceWith(3000);
  });
  it('使用中のポートを順に飛ばす', async () => {
    const probe = vi.fn(async port => port < 3002 ? null : port);
    expect(await selectPort(3000, probe)).toBe(3002);
    expect(probe.mock.calls.flat()).toEqual([3000, 3001, 3002]);
  });
  it('10個使用中ならOSによる割当へ切り替える', async () => {
    const probe = vi.fn(async port => port === 0 ? 49152 : null);
    expect(await selectPort(3130, probe)).toBe(49152);
    expect(probe.mock.calls.flat()).toEqual([...Array.from({length:10}, (_, i) => 3130+i), 0]);
  });
  it('65535を越えずOSの割当へ切り替える', async () => {
    const probe = vi.fn(async port => port === 0 ? 49153 : null);
    expect(await selectPort(65535, probe)).toBe(49153);
    expect(probe.mock.calls.flat()).toEqual([65535, 0]);
  });
  it('不正な希望ポートを拒否する', async () => {
    for (const port of [0, 1023, 65536, 3000.5, NaN]) await expect(selectPort(port)).rejects.toThrow('整数');
  });
  it('権限など競合以外のエラーを使用中扱いにしない', async () => {
    const probe = vi.fn(async () => { throw new Error('権限エラー'); });
    await expect(selectPort(3000, probe)).rejects.toThrow('権限エラー');
    expect(probe).toHaveBeenCalledTimes(1);
  });
  it('OS割当も失敗した場合は終了する', async () => {
    await expect(selectPort(3000, async () => null)).rejects.toThrow('空きポート');
  });
});
