import { describe, it, expect, afterEach } from 'vitest';
import { mkdtemp, writeFile, readFile, rm, readdir, symlink } from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { DatabaseSync } from 'node:sqlite';
import { initialize, acquireLock, createBackup, restoreBackup, validateBackup } from '../../scripts/local-data.mjs';

const roots = [];
async function fixture() {
  const root = await mkdtemp(path.join(os.tmpdir(), 'exam-coach-test-'));
  roots.push(root);
  await initialize(root);
  const db = new DatabaseSync(path.join(root, 'current/app.db'));
  db.exec("CREATE TABLE test_record (value TEXT); INSERT INTO test_record VALUES ('fictional-original')");
  db.close();
  await writeFile(path.join(root, 'current/uploads/sample.pdf'), 'fictional attachment');
  await writeFile(path.join(root, 'current/exports/sample.txt'), 'fictional export');
  return root;
}
afterEach(async () => { for (const root of roots.splice(0)) await rm(root, { recursive: true, force: true }); });

describe('個人端末データ管理', () => {
  it('起動と復元を排他し、解放後に再利用できる', async () => {
    const root = await fixture();
    const release = await acquireLock(root);
    await expect(acquireLock(root)).rejects.toThrow('操作中');
    await release();
    await (await acquireLock(root))();
  });
  it('DB・添付資料・出力物を復元し、復元前の状態も保持する', async () => {
    const root = await fixture();
    const name = await createBackup(root);
    await validateBackup(path.join(root, 'backups', name));
    const db = new DatabaseSync(path.join(root, 'current/app.db'));
    db.exec("UPDATE test_record SET value = 'fictional-updated'"); db.close();
    await writeFile(path.join(root, 'current/uploads/sample.pdf'), 'changed');
    const emergency = await restoreBackup(root, name);
    const restored = new DatabaseSync(path.join(root, 'current/app.db'));
    expect(restored.prepare('SELECT value FROM test_record').get().value).toBe('fictional-original'); restored.close();
    expect(await readFile(path.join(root, 'current/uploads/sample.pdf'), 'utf8')).toBe('fictional attachment');
    expect(await readFile(path.join(root, 'current/exports/sample.txt'), 'utf8')).toBe('fictional export');
    const previous = new DatabaseSync(path.join(root, 'backups', emergency, 'data/app.db'));
    expect(previous.prepare('SELECT value FROM test_record').get().value).toBe('fictional-updated'); previous.close();
  });
  it('破損したバックアップを復元せず、現在データを維持する', async () => {
    const root = await fixture(), name = await createBackup(root);
    await writeFile(path.join(root, 'backups', name, 'data/uploads/sample.pdf'), 'tampered');
    await expect(restoreBackup(root, name)).rejects.toThrow('欠損または変更');
    expect(await readFile(path.join(root, 'current/uploads/sample.pdf'), 'utf8')).toBe('fictional attachment');
    expect(await readdir(path.join(root, 'backups'))).toHaveLength(1);
    await expect(restoreBackup(root, '../outside')).rejects.toThrow('不正');
  });
  it.skipIf(process.platform === 'win32')('外部を参照するリンクをバックアップしない', async () => {
    const root = await fixture();
    await symlink(path.join(root, 'current/app.db'), path.join(root, 'current/uploads/link'));
    await expect(createBackup(root)).rejects.toThrow('シンボリックリンク');
    expect(await readdir(path.join(root, 'backups'))).toHaveLength(0);
  });
});
