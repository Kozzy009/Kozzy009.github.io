import { it, expect } from 'vitest';
import { mkdtemp, mkdir, copyFile, writeFile, readFile, rm, readdir } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { once } from 'node:events';
import { createServer } from 'node:net';
import { DatabaseSync } from 'node:sqlite';
import { initialize } from '../../scripts/local-data.mjs';

it('実ポート競合と起動直前の競合を避け、選択したURLで起動して正常終了する', async () => {
  const folder = await mkdtemp(path.join(tmpdir(), 'exam-coach-port-'));
  const project = path.join(folder, 'app'), data = path.join(folder, 'private-data');
  const blocker = createServer();
  let child;
  try {
    blocker.listen({host:'127.0.0.1',port:0});
    await once(blocker, 'listening');
    const preferred = blocker.address().port;
    await mkdir(path.join(project, 'scripts'), {recursive:true});
    await mkdir(path.join(project, '.next'), {recursive:true});
    await mkdir(path.join(project, 'node_modules/next/dist/bin'), {recursive:true});
    for (const file of ['local-app.mjs','local-data.mjs','local-port.mjs']) await copyFile(new URL(`../../scripts/${file}`, import.meta.url), path.join(project, 'scripts', file));
    await writeFile(path.join(project, '.next/BUILD_ID'), 'test-only');
    await writeFile(path.join(project, 'package.json'), '{"type":"module"}');
    await initialize(data);
    const db = new DatabaseSync(path.join(data, 'current/app.db'));
    db.exec('CREATE TABLE fictional_record (id INTEGER)'); db.close();
    // 最初の起動は空き確認直後の競合を再現し、次の起動でヘルス応答を返す。
    await writeFile(path.join(project, 'node_modules/next/dist/bin/next'), `
      const fs = require('node:fs');
      const http = require('node:http');
      const record = 'attempts.json';
      const attempts = fs.existsSync(record) ? JSON.parse(fs.readFileSync(record)) : [];
      const port = Number(process.argv[process.argv.indexOf('--port') + 1]);
      attempts.push({ port, url: process.env.APP_BASE_URL, host: process.argv[process.argv.indexOf('--hostname') + 1] });
      fs.writeFileSync(record, JSON.stringify(attempts));
      if (attempts.length === 1) { console.error('EADDRINUSE' + 'x'.repeat(1000)); process.exit(1); }
      const server = http.createServer((req,res) => { res.setHeader('Content-Type','application/json'); res.end(JSON.stringify({instanceId:process.env.EXAM_COACH_INSTANCE_ID})); });
      server.listen(port,'127.0.0.1');
      process.on('SIGTERM', () => server.close(() => process.exit(0)));
    `);
    child = spawn(process.execPath, [path.join(project, 'scripts/local-app.mjs'), 'start'], {
      env:{...process.env,EXAM_COACH_DATA_DIR:data,EXAM_COACH_PORT:String(preferred),EXAM_COACH_SKIP_BROWSER:'1'}, stdio:['pipe','pipe','pipe'],
    });
    let output = '', sent = false;
    child.stdout.on('data', chunk => {
      output += chunk.toString();
      if (!sent && output.includes('終了するにはEnter')) { sent = true; child.stdin.end('\n'); }
    });
    const [code] = await once(child, 'exit');
    expect(code).toBe(0);
    const attempts = JSON.parse(await readFile(path.join(project,'attempts.json'),'utf8'));
    expect(attempts).toHaveLength(2);
    for (const attempt of attempts) {
      expect(attempt.port).not.toBe(preferred);
      expect(attempt.host).toBe('127.0.0.1');
      expect(attempt.url).toBe(`http://127.0.0.1:${attempt.port}`);
    }
    expect(output).toContain('選び直します');
    expect(output).toContain(`起動しました: ${attempts[1].url}`);
    expect(blocker.listening).toBe(true);
    expect((await readdir(path.join(data, 'backups'))).length).toBe(1);
  } finally {
    if (child && child.exitCode === null && child.signalCode === null) {
      child.kill('SIGTERM'); await once(child, 'exit');
    }
    await new Promise(resolve => blocker.close(resolve));
    await rm(folder, {recursive:true,force:true});
  }
}, 15000);
