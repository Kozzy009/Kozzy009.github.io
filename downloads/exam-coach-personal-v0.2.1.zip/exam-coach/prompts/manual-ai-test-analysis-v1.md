# 学力テスト資料の構造化依頼

あなたは、学力テスト資料を確認し、後で人が検証するための候補JSONを作成します。結果を断定せず、読めない値を推測しないでください。

## 解析依頼情報

- 生徒匿名ID: `{{studentAnonymousId}}`
- 取り込みトークン: `{{importToken}}`
- テスト名: `{{testName}}`
- 実施日: `{{testDate}}`
- 学年: `{{grade}}`
- 教科: `{{subject}}`
- スキーマ版: `{{schemaVersion}}`

## 重要な制約

1. 氏名など、資料に含まれる個人識別情報は出力しないでください。
2. 上記の匿名IDとトークンを一字も変更せず出力してください。
3. JSON以外の説明文やMarkdownコードブロックを付けないでください。
4. 判読できない値は空文字または `null` とし、`needsHumanReview` を `true` にしてください。
5. 記述式、図表、複数解、単位、数式同値判定、判読困難な手書きは自動断定せず `NEEDS_REVIEW` としてください。
6. `confidence` は0から100の整数です。
7. 大問・小問番号の組み合わせは重複させないでください。

## 出力形式

`manual-ai-test-analysis-v1.schema.json` に従う単一のJSONオブジェクトを返してください。主要構造は次の通りです。

```json
{
  "schemaVersion": "manual-ai-test-analysis-v1",
  "studentAnonymousId": "{{studentAnonymousId}}",
  "importToken": "{{importToken}}",
  "test": {
    "name": "{{testName}}",
    "date": "{{testDate}}",
    "grade": "{{grade}}",
    "subject": "{{subject}}"
  },
  "questions": [],
  "unitSummary": [],
  "overallAnalysis": {
    "summary": "",
    "strengths": [],
    "issues": [],
    "recommendedStudy": []
  }
}
```

各問題には、問題番号、ページ、問題文、図表、分野・単元、形式、難易度、配点、本人解答、正答、正誤候補、空欄、ミス、必要知識、解法概要、推奨復習、確信度、要確認フラグ、要確認理由を含めてください。
