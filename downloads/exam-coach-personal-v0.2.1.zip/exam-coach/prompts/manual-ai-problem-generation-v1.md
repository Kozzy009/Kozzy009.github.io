# 個別類似問題の生成依頼

あなたは中学生向け問題の候補を作成します。結果は必ず人が検証します。外部の文章や元問題をそのまま複製せず、学習対象の知識・解法を保ちながら数値、場面、条件、問い方のいずれかを変更してください。

## 依頼情報

- 匿名生徒ID: `{{studentAnonymousId}}`
- generationToken: `{{generationToken}}`
- 教科: `{{subject}}`
- 学年: `{{grade}}`
- 単元: `{{unit}}`
- スキーマ版: `{{schemaVersion}}`
- 学習目的: {{studyPurpose}}
- 生成レベル: {{requestedLevels}}
- レベル別問題数: {{requestedCounts}}
- 1回の学習時間: {{sessionMinutes}}分
- ヒント: {{includeHints}}
- 詳細解説: {{includeDetailedExplanations}}
- 図表: {{includeVisuals}}

## 元問題（必要部分だけ）

{{sourceProblems}}

## 学習上の一般化した条件

- ミス種類: {{mistakeTypes}}
- 学習傾向: {{learningTendencies}}

## 必須ルール

1. 氏名や個人を特定する情報を出力しないでください。
2. 国語・英語の長文は元文章を再利用せず、新しい文章を作ってください。
3. 各問題の `sourceProblemIds` に対応する元問題IDを入れてください。
4. `sourceSimilarity` に共通知識、共通解法、変更条件、難易度差を記録してください。
5. 問題文、正答、解法手順、解説を相互に確認し、断定できない場合は `needsHumanReview=true` にしてください。
6. JSON以外の説明文やMarkdownを付けないでください。
7. 次の構造で、すべての必須項目を出力してください。

```json
{"schemaVersion":"{{schemaVersion}}","studentAnonymousId":"{{studentAnonymousId}}","generationToken":"{{generationToken}}","subject":"{{subject}}","grade":"{{grade}}","unit":"{{unit}}","generationSummary":{"sourceProblemCount":0,"generatedProblemCount":0,"studyPurpose":[],"estimatedTotalMinutes":null,"limitations":[]},"problems":[]}
```
